package com.example.aiserversetup.permissions;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.integrations.IntegrationManager;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import org.bukkit.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * LuckPerms integration helper for programmatic permission management.
 * Falls back gracefully if LuckPerms is not installed.
 */
public class PermissionWizard implements PluginCore.PluginModule {

    private LuckPerms luckPerms;

    @Override
    public String name() { return "PermissionWizard"; }

    @Override
    public void onEnable(PluginCore core) {
        boolean hasLP = PluginCore.get().serviceOpt(IntegrationManager.class)
                .map(IntegrationManager::hasLuckPerms)
                .orElse(false);

        if (hasLP) {
            try {
                luckPerms = LuckPermsProvider.get();
                core.getPlugin().getLogger().info("[Permissions] LuckPerms connected.");
            } catch (Exception e) {
                core.getPlugin().getLogger().warning("[Permissions] LuckPerms not available: " + e.getMessage());
            }
        } else {
            core.getPlugin().getLogger().info("[Permissions] LuckPerms not found — using vanilla permissions.");
        }
    }

    public boolean isAvailable() { return luckPerms != null; }

    /** Add a permission node to a player. */
    public CompletableFuture<Boolean> addPermission(UUID uuid, String permission) {
        if (luckPerms == null) return CompletableFuture.completedFuture(false);
        return luckPerms.getUserManager().loadUser(uuid).thenApply(user -> {
            user.data().add(Node.builder(permission).build());
            luckPerms.getUserManager().saveUser(user);
            return true;
        }).exceptionally(ex -> false);
    }

    /** Remove a permission node from a player. */
    public CompletableFuture<Boolean> removePermission(UUID uuid, String permission) {
        if (luckPerms == null) return CompletableFuture.completedFuture(false);
        return luckPerms.getUserManager().loadUser(uuid).thenApply(user -> {
            user.data().remove(Node.builder(permission).build());
            luckPerms.getUserManager().saveUser(user);
            return true;
        }).exceptionally(ex -> false);
    }

    /** Add a player to a group. */
    public CompletableFuture<Boolean> addGroup(UUID uuid, String group) {
        if (luckPerms == null) return CompletableFuture.completedFuture(false);
        return luckPerms.getUserManager().loadUser(uuid).thenApply(user -> {
            user.data().add(Node.builder("group." + group).build());
            luckPerms.getUserManager().saveUser(user);
            return true;
        }).exceptionally(ex -> false);
    }

    /** Get primary group name for a player. */
    public String getPrimaryGroup(Player player) {
        if (luckPerms == null) return "default";
        User user = luckPerms.getUserManager().getUser(player.getUniqueId());
        return user == null ? "default" : user.getPrimaryGroup();
    }

    /** Check if a player has a permission (uses Bukkit if LP unavailable). */
    public boolean hasPermission(Player player, String permission) {
        return player.hasPermission(permission);
    }
}