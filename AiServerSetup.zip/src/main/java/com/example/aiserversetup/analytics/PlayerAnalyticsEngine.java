package com.example.aiserversetup.analytics;

import com.example.aiserversetup.cache.CacheService;
import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.database.DatabaseService;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;

import java.util.*;
import java.util.concurrent.*;

/**
 * Tracks player statistics asynchronously via the database.
 * Stats are cached per player for fast read access.
 */
public class PlayerAnalyticsEngine implements PluginCore.PluginModule, Listener {

    private static final long CACHE_TTL = CacheService.MINUTES_5;

    // In-memory write buffer to avoid hammering the DB on every event
    private final Map<UUID, StatBuffer> writeBuffer = new ConcurrentHashMap<>();

    private record StatBuffer(
            java.util.concurrent.atomic.AtomicLong playtime,
            java.util.concurrent.atomic.AtomicInteger kills,
            java.util.concurrent.atomic.AtomicInteger deaths,
            java.util.concurrent.atomic.AtomicLong blocksBreak,
            java.util.concurrent.atomic.AtomicLong blocksPlace,
            java.util.concurrent.atomic.AtomicInteger chatMessages
    ) {
        static StatBuffer fresh() {
            return new StatBuffer(
                    new java.util.concurrent.atomic.AtomicLong(0),
                    new java.util.concurrent.atomic.AtomicInteger(0),
                    new java.util.concurrent.atomic.AtomicInteger(0),
                    new java.util.concurrent.atomic.AtomicLong(0),
                    new java.util.concurrent.atomic.AtomicLong(0),
                    new java.util.concurrent.atomic.AtomicInteger(0)
            );
        }
    }

    @Override
    public String name() { return "PlayerAnalyticsEngine"; }

    @Override
    public void onEnable(PluginCore core) {
        Bukkit.getPluginManager().registerEvents(this, core.getPlugin());
        // Flush buffer to DB every 5 minutes
        Bukkit.getScheduler().runTaskTimerAsynchronously(core.getPlugin(),
                this::flushAll, 20L * 300, 20L * 300);
        core.getPlugin().getLogger().info("[Analytics] Player analytics engine started.");
    }

    @Override
    public void onDisable(PluginCore core) {
        flushAll(); // Ensure data is saved on shutdown
    }

    // ── Event tracking ────────────────────────────────────────────────────────

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID uuid = p.getUniqueId();
        writeBuffer.put(uuid, StatBuffer.fresh());
        // Ensure player exists in DB
        PluginCore.get().serviceOpt(DatabaseService.class).ifPresent(db ->
                db.upsert("player_stats",
                        new LinkedHashMap<>() {{
                            put("uuid",       uuid.toString());
                            put("name",       p.getName());
                            put("last_seen",  System.currentTimeMillis() / 1000);
                            put("first_seen", System.currentTimeMillis() / 1000);
                            put("sessions",   1);
                        }}, "uuid")
                .exceptionally(ex -> { return 0; })
        );
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID uuid = e.getPlayer().getUniqueId();
        StatBuffer buf = writeBuffer.remove(uuid);
        if (buf != null) flush(uuid, e.getPlayer().getName(), buf);
    }

    @EventHandler
    public void onKill(EntityDeathEvent e) {
        if (!(e.getEntity().getKiller() instanceof Player killer)) return;
        writeBuffer.computeIfAbsent(killer.getUniqueId(), k -> StatBuffer.fresh())
                .kills().incrementAndGet();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        writeBuffer.computeIfAbsent(e.getEntity().getUniqueId(), k -> StatBuffer.fresh())
                .deaths().incrementAndGet();
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        writeBuffer.computeIfAbsent(e.getPlayer().getUniqueId(), k -> StatBuffer.fresh())
                .chatMessages().incrementAndGet();
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(org.bukkit.event.block.BlockBreakEvent e) {
        writeBuffer.computeIfAbsent(e.getPlayer().getUniqueId(), k -> StatBuffer.fresh())
                .blocksBreak().incrementAndGet();
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(org.bukkit.event.block.BlockPlaceEvent e) {
        writeBuffer.computeIfAbsent(e.getPlayer().getUniqueId(), k -> StatBuffer.fresh())
                .blocksPlace().incrementAndGet();
    }

    // ── Async stat loading ────────────────────────────────────────────────────

    /**
     * Load stats for a player by name. Returns a map of stat name → value.
     * Cached for 5 minutes.
     */
    public CompletableFuture<Map<String, Object>> getPlayerStats(String playerName) {
        String cacheKey = "analytics_" + playerName.toLowerCase();
        return PluginCore.get().service(CacheService.class)
                .getOrLoadAsync(cacheKey, () -> loadFromDB(playerName), CACHE_TTL);
    }

    private CompletableFuture<Map<String, Object>> loadFromDB(String playerName) {
        return PluginCore.get().serviceOpt(DatabaseService.class)
                .map(db -> db.query(
                        "SELECT * FROM player_stats WHERE name=? COLLATE NOCASE",
                        ps -> ps.setString(1, playerName),
                        rs -> {
                            Map<String, Object> stats = new LinkedHashMap<>();
                            if (rs.next()) {
                                stats.put("uuid",          rs.getString("uuid"));
                                stats.put("name",          rs.getString("name"));
                                stats.put("playtime_mins", rs.getLong("total_playtime") / 60);
                                stats.put("sessions",      rs.getInt("sessions"));
                                stats.put("kills",         rs.getInt("kills"));
                                stats.put("deaths",        rs.getInt("deaths"));
                                stats.put("blocks_broken", rs.getLong("blocks_broken"));
                                stats.put("blocks_placed", rs.getLong("blocks_placed"));
                                stats.put("chat_messages", rs.getInt("chat_messages"));
                                long kd = rs.getInt("deaths") == 0 ? rs.getInt("kills") :
                                        rs.getInt("kills") / rs.getInt("deaths");
                                stats.put("kd_ratio",      kd);
                                stats.put("votes",         rs.getInt("votes"));
                                stats.put("last_seen",     rs.getLong("last_seen"));
                            } else {
                                stats.put("error", "Player not found");
                            }
                            return stats;
                        }))
                .orElse(CompletableFuture.completedFuture(Map.of("error", "Database unavailable")));
    }

    // ── Buffer flushing ───────────────────────────────────────────────────────

    private void flushAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            StatBuffer buf = writeBuffer.get(p.getUniqueId());
            if (buf != null) flush(p.getUniqueId(), p.getName(), buf);
        }
    }

    private void flush(UUID uuid, String name, StatBuffer buf) {
        PluginCore.get().serviceOpt(DatabaseService.class).ifPresent(db ->
                db.update("""
                        UPDATE player_stats SET
                            kills         = kills         + ?,
                            deaths        = deaths        + ?,
                            blocks_broken = blocks_broken + ?,
                            blocks_placed = blocks_placed + ?,
                            chat_messages = chat_messages + ?,
                            total_playtime= total_playtime+ ?,
                            last_seen     = ?
                        WHERE uuid = ?
                        """,
                        ps -> {
                            ps.setInt(1,    buf.kills().getAndSet(0));
                            ps.setInt(2,    buf.deaths().getAndSet(0));
                            ps.setLong(3,   buf.blocksBreak().getAndSet(0));
                            ps.setLong(4,   buf.blocksPlace().getAndSet(0));
                            ps.setInt(5,    buf.chatMessages().getAndSet(0));
                            ps.setLong(6,   buf.playtime().getAndSet(0));
                            ps.setLong(7,   System.currentTimeMillis() / 1000);
                            ps.setString(8, uuid.toString());
                        })
                .exceptionally(ex -> { return 0; })
        );
        // Invalidate cache
        PluginCore.get().serviceOpt(CacheService.class)
                .ifPresent(c -> c.invalidate("analytics_" + name.toLowerCase()));
    }
}