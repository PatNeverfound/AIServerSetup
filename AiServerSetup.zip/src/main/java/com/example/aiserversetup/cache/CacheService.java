package com.example.aiserversetup.cache;

import com.example.aiserversetup.core.PluginCore;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

/**
 * Thread-safe TTL cache with write-through, async load, and size eviction.
 *
 * Usage:
 *   CacheService cache = core.service(CacheService.class);
 *   cache.get("player_stats_uuid", () -> db.loadStats(uuid), Duration.ofMinutes(5));
 */
public class CacheService implements PluginCore.PluginModule {

    private record CacheEntry<V>(V value, long expiryMs) {
        boolean isExpired() { return System.currentTimeMillis() > expiryMs; }
    }

    private final ConcurrentHashMap<String, CacheEntry<?>> store = new ConcurrentHashMap<>();
    private final int maxSize;
    private ScheduledFuture<?> cleanupTask;

    public CacheService(int maxSize) { this.maxSize = maxSize; }
    public CacheService() { this(10_000); }

    @Override public String name() { return "CacheService"; }

    @Override
    public void onEnable(PluginCore core) {
        cleanupTask = core.getSchedulerService().scheduleAtFixedRate(
                this::evictExpired, 60, 60, TimeUnit.SECONDS);
    }

    @Override
    public void onDisable(PluginCore core) {
        if (cleanupTask != null) cleanupTask.cancel(false);
        store.clear();
    }

    // ── Core API ──────────────────────────────────────────────────────────────

    public <V> void put(String key, V value, long ttlMs) {
        if (store.size() >= maxSize) evictOldest();
        store.put(key, new CacheEntry<>(value, System.currentTimeMillis() + ttlMs));
    }

    @SuppressWarnings("unchecked")
    public <V> Optional<V> get(String key) {
        CacheEntry<?> entry = store.get(key);
        if (entry == null) return Optional.empty();
        if (entry.isExpired()) { store.remove(key); return Optional.empty(); }
        return Optional.of((V) entry.value());
    }

    /** Get from cache or load synchronously if missing/expired. */
    public <V> V getOrLoad(String key, Supplier<V> loader, long ttlMs) {
        Optional<V> cached = get(key);
        if (cached.isPresent()) return cached.get();
        V value = loader.get();
        if (value != null) put(key, value, ttlMs);
        return value;
    }

    /** Get from cache or load asynchronously if missing/expired. */
    public <V> CompletableFuture<V> getOrLoadAsync(String key,
                                                    Supplier<CompletableFuture<V>> loader,
                                                    long ttlMs) {
        Optional<V> cached = get(key);
        if (cached.isPresent()) return CompletableFuture.completedFuture(cached.get());
        return loader.get().thenApply(v -> { if (v != null) put(key, v, ttlMs); return v; });
    }

    public void invalidate(String key)               { store.remove(key); }
    public void invalidatePattern(String prefix)     { store.keySet().removeIf(k -> k.startsWith(prefix)); }
    public boolean contains(String key)              { return get(key).isPresent(); }
    public int size()                                { return store.size(); }
    public void clear()                              { store.clear(); }

    private void evictExpired() {
        store.entrySet().removeIf(e -> e.getValue().isExpired());
    }

    private void evictOldest() {
        store.entrySet().stream()
                .min(Comparator.comparingLong(e -> e.getValue().expiryMs()))
                .ifPresent(e -> store.remove(e.getKey()));
    }

    // ── Typed helpers ─────────────────────────────────────────────────────────

    public static final long SECONDS_5  =  5_000L;
    public static final long MINUTES_1  = 60_000L;
    public static final long MINUTES_5  = 300_000L;
    public static final long MINUTES_30 = 1_800_000L;
    public static final long HOURS_1    = 3_600_000L;
    public static final long HOURS_24   = 86_400_000L;
}