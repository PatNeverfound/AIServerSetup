package com.example.aiserversetup.database;

import java.sql.*;

/**
 * All schema migrations — v13 adds anticheat violations table.
 */
public class CoreMigrations {

    public static void register(DatabaseService db) {

        // v1–v12 (existing — unchanged) …
        // [existing migrations 1-12 stay here]

        // v13 — AntiCheat violations
        db.addMigration(new DatabaseService.Migration() {
            @Override public int version() { return 13; }
            @Override public String name()  { return "anticheat_violations"; }
            @Override public void up(Connection c) throws SQLException {
                c.createStatement().execute("""
                    CREATE TABLE IF NOT EXISTS ac_violations (
                        id          INTEGER PRIMARY KEY AUTOINCREMENT,
                        uuid        TEXT    NOT NULL,
                        name        TEXT    NOT NULL,
                        check_type  TEXT    NOT NULL,
                        vl          INTEGER NOT NULL,
                        detail      TEXT,
                        timestamp   BIGINT  NOT NULL
                    )""");
                c.createStatement().execute("CREATE INDEX IF NOT EXISTS idx_ac_uuid ON ac_violations(uuid)");
                c.createStatement().execute("CREATE INDEX IF NOT EXISTS idx_ac_type ON ac_violations(check_type)");
                c.createStatement().execute("CREATE INDEX IF NOT EXISTS idx_ac_time ON ac_violations(timestamp)");
            }
        });

        // v14 — Automation rule fire log
        db.addMigration(new DatabaseService.Migration() {
            @Override public int version() { return 14; }
            @Override public String name()  { return "automation_log"; }
            @Override public void up(Connection c) throws SQLException {
                c.createStatement().execute("""
                    CREATE TABLE IF NOT EXISTS automation_log (
                        id          INTEGER PRIMARY KEY AUTOINCREMENT,
                        rule_id     TEXT    NOT NULL,
                        trigger     TEXT    NOT NULL,
                        player      TEXT,
                        fired_at    BIGINT  NOT NULL
                    )""");
                c.createStatement().execute("CREATE INDEX IF NOT EXISTS idx_al_rule ON automation_log(rule_id)");
            }
        });
    }
}