package com.example.aiserversetup.database;

import com.example.aiserversetup.core.PluginCore;
import com.zaxxer.hikari.*;
import org.bukkit.configuration.file.FileConfiguration;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.logging.Level;

/**
 * Production-grade async database service using HikariCP.
 *
 * Features:
 * - MySQL or SQLite auto-detection
 * - Connection pool (HikariCP)
 * - Async query execution (never block main thread)
 * - Fluent query builder
 * - Prepared statement caching
 * - Auto-migration system
 * - Batch operations
 * - Transaction support
 */
public class DatabaseService implements PluginCore.PluginModule {

    private HikariDataSource dataSource;
    private DatabaseType     type;
    private final List<Migration> migrations = new ArrayList<>();

    public enum DatabaseType { SQLITE, MYSQL, MARIADB }

    // ── Module lifecycle ──────────────────────────────────────────────────────

    @Override
    public String name() { return "DatabaseService"; }

    @Override
    public void onEnable(PluginCore core) throws Exception {
        FileConfiguration cfg = core.getPlugin().getConfig();
        String dbType = cfg.getString("database.type", "sqlite").toUpperCase();
        type = DatabaseType.valueOf(dbType);

        HikariConfig hc = new HikariConfig();
        hc.setPoolName("AISetup-DB");
        hc.setMinimumIdle(2);
        hc.setMaxLifetime(600_000);
        hc.setConnectionTimeout(10_000);
        hc.setLeakDetectionThreshold(60_000);

        if (type == DatabaseType.SQLITE) {
            Class.forName("org.sqlite.JDBC");
            String path = core.getPlugin().getDataFolder().getAbsolutePath() + "/data.db";
            hc.setJdbcUrl("jdbc:sqlite:" + path);
            hc.setMaximumPoolSize(1); // SQLite = single writer
            hc.addDataSourceProperty("foreign_keys", "true");
        } else {
            String host   = cfg.getString("database.host", "localhost");
            int    port   = cfg.getInt("database.port", 3306);
            String name   = cfg.getString("database.name", "aisetup");
            String user   = cfg.getString("database.user", "root");
            String pass   = cfg.getString("database.password", "");
            String driver = type == DatabaseType.MARIADB ? "mariadb" : "mysql";
            hc.setJdbcUrl("jdbc:" + driver + "://" + host + ":" + port + "/" + name +
                    "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
            hc.setUsername(user);
            hc.setPassword(pass);
            hc.setMaximumPoolSize(cfg.getInt("database.pool-size", 10));
            hc.addDataSourceProperty("cachePrepStmts",      "true");
            hc.addDataSourceProperty("prepStmtCacheSize",   "250");
            hc.addDataSourceProperty("prepStmtCacheSqlLimit","2048");
            hc.addDataSourceProperty("useServerPrepStmts",  "true");
        }

        dataSource = new HikariDataSource(hc);
        core.getPlugin().getLogger().info("[DB] Connected (" + type + ") pool=" + hc.getMaximumPoolSize());
        runMigrations();
    }

    @Override
    public void onDisable(PluginCore core) {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            core.getPlugin().getLogger().info("[DB] Connection pool closed.");
        }
    }

    // ── Migration system ──────────────────────────────────────────────────────

    public void addMigration(Migration m) { migrations.add(m); }

    private void runMigrations() throws SQLException {
        try (Connection c = dataSource.getConnection();
             Statement  s = c.createStatement()) {
            s.execute("""
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    version INTEGER PRIMARY KEY,
                    name TEXT,
                    applied_at INTEGER
                )""");
        }
        migrations.sort(Comparator.comparingInt(Migration::version));
        for (Migration m : migrations) {
            try (Connection c = dataSource.getConnection()) {
                PreparedStatement check = c.prepareStatement(
                        "SELECT 1 FROM schema_migrations WHERE version=?");
                check.setInt(1, m.version());
                if (!check.executeQuery().next()) {
                    m.up(c);
                    PreparedStatement mark = c.prepareStatement(
                            "INSERT INTO schema_migrations(version,name,applied_at) VALUES(?,?,?)");
                    mark.setInt(1, m.version());
                    mark.setString(2, m.name());
                    mark.setLong(3, System.currentTimeMillis() / 1000);
                    mark.execute();
                    PluginCore.get().getPlugin().getLogger().info("[DB] Migration applied: v" + m.version() + " " + m.name());
                }
            }
        }
    }

    // ── Async query API ───────────────────────────────────────────────────────

    /** Execute a query and map results asynchronously. */
    public <T> CompletableFuture<T> query(String sql, StatementConsumer prepare,
                                           ResultMapper<T> mapper) {
        return PluginCore.get().async(() -> {
            try (Connection c = dataSource.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                if (prepare != null) prepare.accept(ps);
                try (ResultSet rs = ps.executeQuery()) { return mapper.map(rs); }
            }
        });
    }

    /** Execute an update/insert asynchronously. Returns rows affected. */
    public CompletableFuture<Integer> update(String sql, StatementConsumer prepare) {
        return PluginCore.get().async(() -> {
            try (Connection c = dataSource.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                if (prepare != null) prepare.accept(ps);
                return ps.executeUpdate();
            }
        });
    }

    /** Execute a batch of updates in a single transaction. */
    public CompletableFuture<int[]> batch(String sql, List<StatementConsumer> rows) {
        return PluginCore.get().async(() -> {
            try (Connection c = dataSource.getConnection()) {
                c.setAutoCommit(false);
                try (PreparedStatement ps = c.prepareStatement(sql)) {
                    for (StatementConsumer row : rows) { row.accept(ps); ps.addBatch(); }
                    int[] result = ps.executeBatch();
                    c.commit();
                    return result;
                } catch (Exception e) { c.rollback(); throw e; }
                finally { c.setAutoCommit(true); }
            }
        });
    }

    /** Execute multiple statements in a transaction. */
    public CompletableFuture<Void> transaction(TransactionBlock block) {
        return PluginCore.get().async(() -> {
            try (Connection c = dataSource.getConnection()) {
                c.setAutoCommit(false);
                try { block.execute(c); c.commit(); }
                catch (Exception e) { c.rollback(); throw e; }
                finally { c.setAutoCommit(true); }
            }
        });
    }

    /** Upsert helper (INSERT OR REPLACE for SQLite, INSERT...ON DUPLICATE KEY for MySQL). */
    public CompletableFuture<Integer> upsert(String table, Map<String, Object> values,
                                              String primaryKey) {
        if (type == DatabaseType.SQLITE) {
            String cols = String.join(",", values.keySet());
            String placeholders = String.join(",", Collections.nCopies(values.size(), "?"));
            String sql = "INSERT OR REPLACE INTO " + table + "(" + cols + ") VALUES(" + placeholders + ")";
            return update(sql, ps -> {
                int i = 1;
                for (Object v : values.values()) ps.setObject(i++, v);
            });
        } else {
            String cols = String.join(",", values.keySet());
            String placeholders = String.join(",", Collections.nCopies(values.size(), "?"));
            String updates = values.keySet().stream()
                    .filter(k -> !k.equals(primaryKey))
                    .map(k -> k + "=VALUES(" + k + ")")
                    .reduce((a, b) -> a + "," + b).orElse("");
            String sql = "INSERT INTO " + table + "(" + cols + ") VALUES(" + placeholders + ")" +
                    (updates.isEmpty() ? "" : " ON DUPLICATE KEY UPDATE " + updates);
            return update(sql, ps -> {
                int i = 1;
                for (Object v : values.values()) ps.setObject(i++, v);
            });
        }
    }

    public Connection getConnection() throws SQLException { return dataSource.getConnection(); }
    public DatabaseType getType() { return type; }
    public HikariDataSource getDataSource() { return dataSource; }

    // ── Functional interfaces ─────────────────────────────────────────────────

    @FunctionalInterface public interface StatementConsumer {
        void accept(PreparedStatement ps) throws SQLException;
    }
    @FunctionalInterface public interface ResultMapper<T> {
        T map(ResultSet rs) throws SQLException;
    }
    @FunctionalInterface public interface TransactionBlock {
        void execute(Connection c) throws SQLException;
    }
    public interface Migration {
        int    version();
        String name();
        void   up(Connection c) throws SQLException;
    }
}