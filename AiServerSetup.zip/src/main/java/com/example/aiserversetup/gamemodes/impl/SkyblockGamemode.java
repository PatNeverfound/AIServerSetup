package com.example.aiserversetup.gamemodes.impl;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.gamemodes.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

import java.util.*;
import java.util.concurrent.*;

/**
 * SKYBLOCK GAMEMODE
 *
 * - Each player/team gets a void island
 * - Island level calculated from block values
 * - Challenges to unlock upgrades
 * - Island trust / co-op system
 * - Biome upgrades, island expansion
 * - Leaderboard by island level
 */
public class SkyblockGamemode extends AbstractGamemode {

    public record IslandData(
            UUID owner, String name, Location spawn,
            Set<UUID> coopPlayers, int level, int sizeLimit,
            Map<String, Boolean> upgrades, Map<String, Integer> challengeProgress,
            boolean locked
    ) {}

    private final Map<UUID, IslandData> islands = new ConcurrentHashMap<>();
    private final Map<UUID, UUID>       playerIsland = new ConcurrentHashMap<>(); // player → island owner

    public SkyblockGamemode(AIServerSetupPlugin plugin) {
        super(plugin, new GamemodeDefinition()
                .id("skyblock").displayName("Skyblock")
                .description("Start on a floating island. Build, challenge, grow.")
                .icon("GRASS_BLOCK").pvp(false).hunger(true));
        loadData();
    }

    @Override public String getId()          { return "skyblock"; }
    @Override public String getDisplayName() { return "Skyblock"; }
    @Override public String getDescription() { return "Build your island from nothing."; }

    @Override
    public void applyGameRules(Player p) {
        IslandData island = getPlayerIsland(p);
        if (island != null) {
            p.teleport(island.spawn());
        } else {
            createIsland(p);
        }
    }

    @Override public void removeGameRules(Player p) {}

    @Override
    public void sendWelcomeMessage(Player p) {
        IslandData island = getPlayerIsland(p);
        sendTitle(p, "<aqua>🏝 Skyblock",
                island == null ? "<gray>Creating your island..." : "<gray>Level " + island.level(),
                10, 60, 10);
    }

    public boolean createIsland(Player player) {
        if (playerIsland.containsKey(player.getUniqueId())) return false;
        // Paste starter island schematic in a void world
        Location islandSpawn = calculateIslandLocation(player.getUniqueId());
        pasteStarterIsland(islandSpawn);

        IslandData island = new IslandData(
                player.getUniqueId(), player.getName() + "'s Island", islandSpawn,
                new HashSet<>(), 0, 100, new HashMap<>(), new HashMap<>(), false);
        islands.put(player.getUniqueId(), island);
        playerIsland.put(player.getUniqueId(), player.getUniqueId());
        player.teleport(islandSpawn);
        sendTitle(player, "<aqua>🏝 Welcome!", "<gray>Your island was created!", 10, 60, 10);
        saveData();
        return true;
    }

    public boolean addCoopPlayer(Player owner, Player coopPlayer) {
        IslandData island = islands.get(owner.getUniqueId());
        if (island == null) return false;
        island.coopPlayers().add(coopPlayer.getUniqueId());
        playerIsland.put(coopPlayer.getUniqueId(), owner.getUniqueId());
        coopPlayer.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<aqua>You have been added to <white>" + owner.getName() + "'s <aqua>island!"));
        saveData();
        return true;
    }

    public boolean removeCoopPlayer(Player owner, Player coopPlayer) {
        IslandData island = islands.get(owner.getUniqueId());
        if (island == null) return false;
        island.coopPlayers().remove(coopPlayer.getUniqueId());
        playerIsland.remove(coopPlayer.getUniqueId());
        saveData();
        return true;
    }

    public int calculateIslandLevel(Player player) {
        // Level = sum of placed block values on the island
        // Simplified: track via our own counter
        IslandData island = islands.get(player.getUniqueId());
        return island == null ? 0 : island.level();
    }

    public List<Map.Entry<String, Integer>> getLeaderboard(int limit) {
        return islands.values().stream()
                .sorted(Comparator.comparingInt(IslandData::level).reversed())
                .limit(limit)
                .map(i -> Map.entry(i.name(), i.level()))
                .toList();
    }

    private Location calculateIslandLocation(UUID uuid) {
        // Spread islands in a grid pattern
        int index = islands.size();
        int gridX = (index % 20) * 1000;
        int gridZ = (index / 20) * 1000;
        World w = Bukkit.getWorld("skyblock_world");
        if (w == null) w = Bukkit.getWorlds().get(0);
        return new Location(w, gridX, 100, gridZ);
    }

    private void pasteStarterIsland(Location loc) {
        if (plugin.getIntegrations().getWorldEdit() == null) {
            // Fallback: manually place a 7x7 grass platform
            World w = loc.getWorld();
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    w.getBlockAt(loc.getBlockX()+dx, loc.getBlockY()-1, loc.getBlockZ()+dz).setType(Material.GRASS_BLOCK);
                    if (Math.abs(dx) <= 2 && Math.abs(dz) <= 2) {
                        w.getBlockAt(loc.getBlockX()+dx, loc.getBlockY()-2, loc.getBlockZ()+dz).setType(Material.DIRT);
                    }
                }
            }
            // Starter tree
            w.getBlockAt(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()).setType(Material.OAK_SAPLING);
            // Chest
            w.getBlockAt(loc.getBlockX()+1, loc.getBlockY(), loc.getBlockZ()).setType(Material.CHEST);
        } else {
            // Load from schematic
            plugin.getIntegrations().getWorldEdit().runCommand(
                    Bukkit.getConsoleSender() instanceof Player p ? p : null,
                    "schematic load starter_island");
        }
    }

    private IslandData getPlayerIsland(Player p) {
        UUID islandOwner = playerIsland.get(p.getUniqueId());
        return islandOwner == null ? null : islands.get(islandOwner);
    }

    private void loadData()  { /* Load from JSON */ }
    private void saveData()  { /* Save to JSON */ }

    @Override
    public String buildAIContext() {
        return "=== Skyblock ===\nIslands: " + islands.size() +
                " | Players: " + activePlayers.size() + "\n";
    }
}