package com.example.aiserversetup.gamemodes.impl;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.gamemodes.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * UHC (Ultra Hardcore) GAMEMODE
 *
 * - Natural health regeneration DISABLED
 * - Only way to heal: golden apple, potion, gapple
 * - Border shrinks over time
 * - Death = elimination
 * - Teams or solo
 * - Last player/team wins
 * - Configurable game phases (grace period, PvP enabled, final zone)
 */
public class UHCGamemode extends AbstractGamemode {

    public enum Phase { WAITING, GRACE, ACTIVE, FINAL, ENDED }

    private Phase    phase     = Phase.WAITING;
    private BukkitTask phaseTask;
    private int      gracePeriod = 600; // seconds
    private int      gameTimer   = 0;

    private final Set<UUID> eliminated = new HashSet<>();
    private final Map<UUID, Set<UUID>> teams = new HashMap<>();

    public UHCGamemode(AIServerSetupPlugin plugin) {
        super(plugin, new GamemodeDefinition()
                .id("uhc").displayName("Ultra Hardcore")
                .description("No natural regen. Death = elimination. Last one wins.")
                .icon("GOLDEN_APPLE").pvp(true).hunger(true));
    }

    @Override public String getId()          { return "uhc"; }
    @Override public String getDisplayName() { return "Ultra Hardcore"; }
    @Override public String getDescription() { return "Natural regen off. Gold is your only healer."; }

    @Override
    public void applyGameRules(Player p) {
        p.setGameMode(GameMode.SURVIVAL);
        // Disable natural regeneration
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (World w : Bukkit.getWorlds()) {
                w.setGameRule(GameRule.NATURAL_REGENERATION, false);
            }
        }, 1L);
    }

    @Override public void removeGameRules(Player p) {
        for (World w : Bukkit.getWorlds()) w.setGameRule(GameRule.NATURAL_REGENERATION, true);
    }

    @Override
    public void sendWelcomeMessage(Player p) {
        sendTitle(p, "<dark_red>☠ ULTRA HARDCORE",
                "<gray>Natural regen disabled. Phase: <red>" + phase.name(),
                10, 80, 10);
        p.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<dark_red>☠ UHC — <gray>Natural health regeneration is <red>DISABLED</red>. Use golden apples!"));
    }

    public void startGame() {
        phase = Phase.GRACE;
        Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<dark_red>☠ UHC has started! Grace period: " + gracePeriod + " seconds!"));
        phaseTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            gameTimer++;
            if (phase == Phase.GRACE && gameTimer >= gracePeriod) {
                phase = Phase.ACTIVE;
                Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                        .deserialize("<red>⚔ Grace period over! PvP is now ENABLED!"));
            }
            if (phase == Phase.ACTIVE && activePlayers.size() - eliminated.size() <= 3) {
                phase = Phase.FINAL;
                Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                        .deserialize("<dark_red>💀 FINAL PHASE — " + (activePlayers.size()-eliminated.size()) + " players remain!"));
            }
            checkWin();
        }, 20L, 20L);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (!isInMode(p)) return;
        eliminated.add(p.getUniqueId());
        Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<dark_red>💀 <white>" + p.getName() + " <gray>has been eliminated! " +
                        (activePlayers.size()-eliminated.size()) + " players remain."));
        Bukkit.getScheduler().runTaskLater(plugin, () -> p.setGameMode(GameMode.SPECTATOR), 20L);
        checkWin();
    }

    private void checkWin() {
        long alive = activePlayers.stream().filter(u -> !eliminated.contains(u)).count();
        if (alive <= 1) {
            phase = Phase.ENDED;
            activePlayers.stream().filter(u -> !eliminated.contains(u))
                    .map(Bukkit::getPlayer).filter(Objects::nonNull)
                    .forEach(w -> {
                        Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                                .deserialize("<gold>🏆 <white>" + w.getName() + " <gold>wins UHC!"));
                        sendTitle(w, "<gold>🏆 WINNER!", "<white>You survived UHC!", 10, 100, 20);
                        w.playSound(w.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                    });
            if (phaseTask != null) phaseTask.cancel();
        }
    }

    public Phase getPhase()        { return phase; }
    public int   getAliveCount()   { return activePlayers.size() - eliminated.size(); }

    @Override
    public String buildAIContext() {
        return "=== UHC ===\nPhase: " + phase + " | Alive: " + getAliveCount() + "/" + activePlayers.size() + "\n";
    }
}