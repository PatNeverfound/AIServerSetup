package com.example.aiserversetup.gamemodes.impl;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.gamemodes.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

import java.util.*;
import java.util.concurrent.*;

/**
 * TYCOON GAMEMODE
 *
 * - Players own businesses (income generators)
 * - Each business has level, income/tick, upgrade cost
 * - Passive income deposited to Vault economy
 * - Leaderboard: richest player
 * - Buy/sell/upgrade businesses via GUI
 * - Business types: Mine, Farm, Shop, Factory, Bank, Casino, Port
 */
public class TycoonGamemode extends AbstractGamemode {

    public record Business(
            String id, String name, String icon,
            double baseIncome, double incomePerLevel,
            double baseCost, double upgradeCostMultiplier,
            int maxLevel
    ) {}

    public record PlayerBusiness(String businessId, int level, long lastCollected) {}

    private final List<Business> businesses = new ArrayList<>();
    private final Map<UUID, List<PlayerBusiness>> playerBusinesses = new ConcurrentHashMap<>();
    private final Map<UUID, Double> totalEarned = new ConcurrentHashMap<>();

    public TycoonGamemode(AIServerSetupPlugin plugin) {
        super(plugin, new GamemodeDefinition()
                .id("tycoon").displayName("Tycoon")
                .description("Own businesses, collect income, become the richest.")
                .icon("GOLD_INGOT").pvp(false).hunger(false));
        loadDefaultBusinesses();
        loadData();
    }

    @Override public String getId()          { return "tycoon"; }
    @Override public String getDisplayName() { return "Tycoon"; }
    @Override public String getDescription() { return "Build businesses, collect passive income."; }

    private void loadDefaultBusinesses() {
        businesses.add(new Business("mine",    "Coal Mine",   "COAL_ORE",   50,  25,  500,   1.8, 10));
        businesses.add(new Business("farm",    "Wheat Farm",  "WHEAT",      80,  40,  800,   1.8, 10));
        businesses.add(new Business("shop",    "Market Shop", "CHEST",      150, 75,  2000,  1.9, 10));
        businesses.add(new Business("factory", "Factory",     "FURNACE",    300, 150, 5000,  2.0, 10));
        businesses.add(new Business("bank",    "Bank",        "GOLD_BLOCK", 600, 300, 12000, 2.1, 10));
        businesses.add(new Business("casino",  "Casino",      "DIAMOND",    1200,600, 30000, 2.2, 10));
        businesses.add(new Business("port",    "Sea Port",    "BLUE_TERRACOTTA",2500,1200,75000,2.3,10));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        // Income collection every 60s
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::collectAllIncome, 1200L, 1200L);
    }

    public boolean buyBusiness(Player player, String businessId) {
        Business biz = getBusinessById(businessId);
        if (biz == null) return false;
        var eco = plugin.getIntegrations().getVault();
        if (eco == null) return false;
        List<PlayerBusiness> owned = playerBusinesses.computeIfAbsent(player.getUniqueId(), k -> new ArrayList<>());
        if (owned.stream().anyMatch(pb -> pb.businessId().equals(businessId))) return false;
        if (!eco.getEconomy().has(player, biz.baseCost())) {
            player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<red>Not enough money! Need $" + biz.baseCost()));
            return false;
        }
        eco.getEconomy().withdrawPlayer(player, biz.baseCost());
        owned.add(new PlayerBusiness(businessId, 1, System.currentTimeMillis()));
        player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<green>✔ Purchased <gold>" + biz.name() + " <gray>($" + biz.baseCost() + ")"));
        saveData();
        return true;
    }

    public boolean upgradeBusiness(Player player, String businessId) {
        Business biz = getBusinessById(businessId);
        if (biz == null) return false;
        var eco = plugin.getIntegrations().getVault();
        if (eco == null) return false;
        List<PlayerBusiness> owned = playerBusinesses.computeIfAbsent(player.getUniqueId(), k -> new ArrayList<>());
        PlayerBusiness pb = owned.stream().filter(b -> b.businessId().equals(businessId)).findFirst().orElse(null);
        if (pb == null) return false;
        if (pb.level() >= biz.maxLevel()) {
            player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<red>Already at max level!"));
            return false;
        }
        double cost = biz.baseCost() * Math.pow(biz.upgradeCostMultiplier(), pb.level());
        if (!eco.getEconomy().has(player, cost)) {
            player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<red>Need $" + String.format("%.0f", cost)));
            return false;
        }
        eco.getEconomy().withdrawPlayer(player, cost);
        owned.remove(pb);
        owned.add(new PlayerBusiness(businessId, pb.level() + 1, pb.lastCollected()));
        player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<green>⬆ Upgraded <gold>" + biz.name() + " <aqua>to level " + (pb.level()+1)));
        saveData();
        return true;
    }

    public double getIncomePerMinute(Player player) {
        List<PlayerBusiness> owned = playerBusinesses.getOrDefault(player.getUniqueId(), List.of());
        return owned.stream().mapToDouble(pb -> {
            Business biz = getBusinessById(pb.businessId());
            return biz == null ? 0 : biz.baseIncome() + (biz.incomePerLevel() * (pb.level() - 1));
        }).sum();
    }

    private void collectAllIncome() {
        var eco = plugin.getIntegrations().getVault();
        if (eco == null) return;
        for (Map.Entry<UUID, List<PlayerBusiness>> entry : playerBusinesses.entrySet()) {
            double income = entry.getValue().stream().mapToDouble(pb -> {
                Business biz = getBusinessById(pb.businessId());
                return biz == null ? 0 : biz.baseIncome() + (biz.incomePerLevel() * (pb.level() - 1));
            }).sum();
            if (income <= 0) continue;
            totalEarned.merge(entry.getKey(), income, Double::sum);
            Player p = Bukkit.getPlayer(entry.getKey());
            if (p != null) {
                eco.getEconomy().depositPlayer(p, income);
                sendActionBar(p, "<gold>+$" + String.format("%.0f", income) + " <gray>(business income)");
            }
        }
    }

    public List<String> getLeaderboard(int limit) {
        return totalEarned.entrySet().stream()
                .sorted(Map.Entry.<UUID, Double>comparingByValue().reversed())
                .limit(limit)
                .map(e -> {
                    String name = Bukkit.getOfflinePlayer(e.getKey()).getName();
                    return (name == null ? "?" : name) + " — $" + String.format("%.0f", e.getValue());
                }).toList();
    }

    public List<PlayerBusiness> getPlayerBusinesses(Player p) {
        return playerBusinesses.getOrDefault(p.getUniqueId(), List.of());
    }

    private Business getBusinessById(String id) {
        return businesses.stream().filter(b -> b.id().equals(id)).findFirst().orElse(null);
    }

    public List<Business> getAllBusinesses() { return Collections.unmodifiableList(businesses); }

    @Override public void applyGameRules(Player p)  { p.setGameMode(GameMode.SURVIVAL); }
    @Override public void removeGameRules(Player p) {}
    @Override public void sendWelcomeMessage(Player p) {
        sendTitle(p, "<gold>💰 Tycoon", "<gray>Build your empire!", 10, 60, 10);
    }

    private void loadData()  { /* Load from JSON */ }
    private void saveData()  { /* Save to JSON */ }

    @Override
    public String buildAIContext() {
        return "=== Tycoon ===\nPlayers: " + activePlayers.size() +
                " | Businesses: " + businesses.size() + " types\n" +
                "Top earners: " + getLeaderboard(3).stream().reduce((a,b)->a+", "+b).orElse("none") + "\n";
    }
}