package com.example.aiserversetup.gamemodes;

import java.util.*;

/**
 * Stores the config-level definition of a gamemode:
 * world names, settings, display info, rewards, etc.
 */
public class GamemodeDefinition {

    private String  id;
    private String  displayName;
    private String  description;
    private String  icon;              // Material name for GUI
    private String  primaryWorld;
    private List<String> worlds;
    private boolean enabled;
    private boolean pvpEnabled;
    private boolean hungerEnabled;
    private boolean deathBanEnabled;
    private int     maxPlayers;
    private Map<String, Object> settings; // Mode-specific settings

    public GamemodeDefinition() {
        this.worlds   = new ArrayList<>();
        this.settings = new LinkedHashMap<>();
        this.enabled  = true;
        this.maxPlayers = -1; // unlimited
    }

    // Fluent builder
    public GamemodeDefinition id(String id)               { this.id = id; return this; }
    public GamemodeDefinition displayName(String n)        { this.displayName = n; return this; }
    public GamemodeDefinition description(String d)        { this.description = d; return this; }
    public GamemodeDefinition icon(String i)               { this.icon = i; return this; }
    public GamemodeDefinition primaryWorld(String w)       { this.primaryWorld = w; return this; }
    public GamemodeDefinition pvp(boolean v)               { this.pvpEnabled = v; return this; }
    public GamemodeDefinition hunger(boolean v)            { this.hungerEnabled = v; return this; }
    public GamemodeDefinition deathBan(boolean v)          { this.deathBanEnabled = v; return this; }
    public GamemodeDefinition maxPlayers(int n)            { this.maxPlayers = n; return this; }
    public GamemodeDefinition set(String k, Object v)      { this.settings.put(k, v); return this; }

    public String  getId()            { return id; }
    public String  getDisplayName()   { return displayName; }
    public String  getDescription()   { return description; }
    public String  getIcon()          { return icon; }
    public String  getPrimaryWorld()  { return primaryWorld; }
    public List<String> getWorlds()   { return worlds; }
    public boolean isEnabled()        { return enabled; }
    public boolean isPvpEnabled()     { return pvpEnabled; }
    public boolean isHungerEnabled()  { return hungerEnabled; }
    public boolean isDeathBanEnabled(){ return deathBanEnabled; }
    public int     getMaxPlayers()    { return maxPlayers; }
    public Map<String, Object> getSettings() { return settings; }
    public Object  get(String k)      { return settings.get(k); }
    public Object  get(String k, Object def) { return settings.getOrDefault(k, def); }
}