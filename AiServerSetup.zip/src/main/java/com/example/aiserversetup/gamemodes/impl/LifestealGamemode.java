package com.example.aiserversetup.gamemodes.impl;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.gamemodes.*;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;  // FIX: correct import
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * LIFESTEAL GAMEMODE — Fixed for Paper 1.21.4
 * - Attribute.MAX_HEALTH (not GENERIC_MAX_HEALTH)
 * - PlayerProfile-based ban (not BanList.Type.NAME)
 */
public class LifestealGamemode extends AbstractGamemode {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final Map<UUID, Integer> heartData = new ConcurrentHashMap<>();
    private final NamespacedKey heartKey;

    private static final int DEFAULT_HEARTS = 10;
    private static final int MAX_HEARTS     = 20;
    private static final int BAN_HOURS      = 24;

    public LifestealGamemode() {
        super(new GamemodeDefinition()
                .id("lifesteal").displayName("Lifesteal SMP")
                .description("Steal hearts on kills. Reach 0 → banned.")
                .icon("HEART_OF_THE_SEA").pvp(true).hunger(true));
        this.heartKey = new NamespacedKey("aiserversetup", "heart_item");
    }

    @Override public String getId()          { return "lifesteal"; }
    @Override public String getDisplayName() { return "Lifesteal SMP"; }
    @Override public String getDescription() { return "Steal hearts on every kill. Die at 0 hearts."; }

    @Override
    public void onEnable(PluginCore core) {
        super.onEnable(core);
        loadHeartData();
        registerHeartRecipe();
    }

    // ── Player join/leave ─────────────────────────────────────────────────────

    @Override
    public void applyGameRules(Player player) {
        int hearts = heartData.computeIfAbsent(player.getUniqueId(), k -> DEFAULT_HEARTS);
        applyMaxHealth(player, hearts);
    }

    @Override
    public void removeGameRules(Player player) {
        setMaxHealth(player, 20.0);
    }

    @Override
    public void sendWelcomeMessage(Player player) {
        int hearts = getHearts(player);
        sendTitle(player, "<red>❤ Lifesteal SMP", "<gray>You have " + hearts + " hearts", 10, 60, 10);
        player.sendMessage(MM.deserialize(
                "<red>❤ Lifesteal SMP — <gray>Kill players to steal their hearts. " +
                "Reach 0 and you're <red>banned</red>!"));
    }

    // ── Death event ───────────────────────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        if (!isInMode(victim)) return;

        Player killer = victim.getKiller();

        if (killer != null && isInMode(killer)) {
            int killerHearts = Math.min(MAX_HEARTS, getHearts(killer) + 1);
            setHearts(killer, killerHearts);
            applyMaxHealth(killer, killerHearts);
            killer.sendMessage(MM.deserialize(
                    "<red>+1 ❤ <gray>You now have <red>" + killerHearts + " hearts</red>!"));
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        }

        int victimHearts = getHearts(victim);
        int newHearts    = victimHearts - 1;

        if (newHearts <= 0) {
            setHearts(victim, 0);
            Bukkit.getScheduler().runTaskLater(PluginCore.get().getPlugin(),
                    () -> banPlayer(victim), 20L);
        } else {
            setHearts(victim, newHearts);
            spawnHeartItem(victim.getLocation());
        }

        if (killer != null) {
            Bukkit.broadcast(MM.deserialize(
                    "<red>💔 <white>" + killer.getName() +
                    " <gray>stole a heart from <white>" + victim.getName() +
                    " <gray>(" + newHearts + " ❤ remaining)"));
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        if (!isInMode(p)) return;
        Bukkit.getScheduler().runTaskLater(PluginCore.get().getPlugin(), () -> {
            int hearts = getHearts(p);
            applyMaxHealth(p, hearts);
            if (p.getHealth() > hearts * 2.0) p.setHealth(hearts * 2.0);
        }, 2L);
    }

    // ── Heart item consumption ────────────────────────────────────────────────

    @EventHandler
    public void onHeartConsume(PlayerInteractEvent event) {
        if (!isInMode(event.getPlayer())) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR &&
            event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null) return;

        // FIX: use direct PDC access (Paper 1.21.4)
        if (!item.getPersistentDataContainer().has(heartKey, PersistentDataType.BYTE)) return;

        Player p = event.getPlayer();
        int hearts = getHearts(p);
        if (hearts >= MAX_HEARTS) {
            p.sendMessage(MM.deserialize("<red>You are already at maximum hearts!"));
            return;
        }

        int newHearts = Math.min(MAX_HEARTS, hearts + 1);
        setHearts(p, newHearts);
        applyMaxHealth(p, newHearts);
        item.setAmount(item.getAmount() - 1);
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1, 0), 10, 0.3, 0.3, 0.3, 0);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
        p.sendMessage(MM.deserialize("<red>❤ +1 heart! You now have <white>" + newHearts + " hearts</white>!"));
        event.setCancelled(true);
    }

    // ── Heart item builder ────────────────────────────────────────────────────

    public ItemStack buildHeartItem() {
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        // FIX: use editMeta()
        item.editMeta(meta -> {
            meta.displayName(MM.deserialize("<red>❤ Heart"));
            meta.lore(List.of(
                    MM.deserialize("<gray>Right-click to add 1 heart."),
                    MM.deserialize("<dark_gray>Max: " + MAX_HEARTS + " hearts")));
            meta.addEnchant(org.bukkit.enchantments.Enchantment.LUCK_OF_THE_SEA, 1, true);
            meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
            meta.getPersistentDataContainer().set(heartKey, PersistentDataType.BYTE, (byte) 1);
        });
        return item;
    }

    private void spawnHeartItem(Location loc) {
        if (loc.getWorld() != null) loc.getWorld().dropItemNaturally(loc, buildHeartItem());
    }

    private void registerHeartRecipe() {
        NamespacedKey recipeKey = new NamespacedKey("aiserversetup", "heart_crafting");
        // Remove old recipe to avoid duplicate on reload
        Bukkit.removeRecipe(recipeKey);
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, buildHeartItem());
        recipe.shape("GGG", "GGG", "GGG");
        recipe.setIngredient('G', Material.GLISTERING_MELON_SLICE);
        Bukkit.addRecipe(recipe);
    }

    // ── Ban player (FIX: use PlayerProfile) ──────────────────────────────────

    private void banPlayer(Player player) {
        java.util.Date expiry = java.util.Date.from(
                java.time.Instant.now().plusSeconds(BAN_HOURS * 3600L));

        // FIX: BanList.Type.PROFILE instead of deprecated NAME-based ban
        Bukkit.getBanList(BanList.Type.PROFILE)
                .addBan(player.getPlayerProfile(),
                        "§c0 hearts — Lifesteal elimination",
                        expiry,
                        "Lifesteal");

        player.kickPlayer("§c❤ You have 0 hearts!\n§7You are banned for " + BAN_HOURS + " hours.");
        Bukkit.broadcast(MM.deserialize(
                "<red>💀 <white>" + player.getName() +
                " <gray>has been eliminated! (0 hearts)"));
    }

    // ── HP helpers (FIX: Attribute.MAX_HEALTH) ───────────────────────────────

    public void applyMaxHealth(Player p, int hearts) {
        double hp = hearts * 2.0;
        setMaxHealth(p, hp);
        if (p.getHealth() > hp) p.setHealth(hp);
    }

    private void setMaxHealth(Player p, double hp) {
        // FIX: use Attribute.MAX_HEALTH (not GENERIC_MAX_HEALTH)
        var attr = p.getAttribute(Attribute.MAX_HEALTH);
        if (attr != null) attr.setBaseValue(hp);
    }

    // ── Data ──────────────────────────────────────────────────────────────────

    public int getHearts(Player p) {
        return heartData.getOrDefault(p.getUniqueId(), DEFAULT_HEARTS);
    }

    public void setHearts(Player p, int hearts) {
        heartData.put(p.getUniqueId(), hearts);
        saveHeartData();
    }

    public List<Map.Entry<String, Integer>> getLeaderboard(int limit) {
        return heartData.entrySet().stream()
                .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
                .limit(limit)
                .map(e -> {
                    OfflinePlayer op = Bukkit.getOfflinePlayer(e.getKey());
                    String name = op.getName() != null ? op.getName() : e.getKey().toString();
                    return Map.entry(name, e.getValue());
                })
                .toList();
    }

    private void loadHeartData() {
        java.io.File f = new java.io.File(PluginCore.get().getPlugin().getDataFolder(), "lifesteal_hearts.json");
        if (!f.exists()) return;
        try {
            String json = java.nio.file.Files.readString(f.toPath());
            Map<String, Integer> map = new com.google.gson.Gson().fromJson(json,
                    new com.google.gson.reflect.TypeToken<Map<String, Integer>>(){}.getType());
            if (map != null) map.forEach((k, v) -> heartData.put(UUID.fromString(k), v));
        } catch (Exception ignored) {}
    }

    private void saveHeartData() {
        java.io.File f = new java.io.File(PluginCore.get().getPlugin().getDataFolder(), "lifesteal_hearts.json");
        try {
            Map<String, Integer> out = new LinkedHashMap<>();
            heartData.forEach((k, v) -> out.put(k.toString(), v));
            java.nio.file.Files.writeString(f.toPath(),
                    new com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(out));
        } catch (Exception ignored) {}
    }

    @Override
    public String buildAIContext() {
        return "=== Lifesteal ===\nPlayers: " + activePlayers.size() +
                " | Top: " + getLeaderboard(3).stream()
                .map(e -> e.getKey() + "(" + e.getValue() + "❤)")
                .reduce((a, b) -> a + ", " + b).orElse("none") + "\n";
    }
}