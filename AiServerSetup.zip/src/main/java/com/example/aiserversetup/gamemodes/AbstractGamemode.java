package com.example.aiserversetup.gamemodes;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import java.util.*;

/**
 * Base class for all gamemodes.
 * Each gamemode manages its own world(s), player data, and event listeners.
 */
public abstract class AbstractGamemode implements Listener {

    protected final AIServerSetupPlugin plugin;
    protected final GamemodeDefinition  definition;

    // Active players in this gamemode
    protected final Set<UUID> activePlayers = new HashSet<>();

    public AbstractGamemode(AIServerSetupPlugin plugin, GamemodeDefinition definition) {
        this.plugin     = plugin;
        this.definition = definition;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /** Called once when the gamemode is first loaded. */
    public void onEnable() {
        org.bukkit.Bukkit.getPluginManager().registerEvents(this, plugin);
        plugin.getLogger().info("[Gamemodes] Enabled: " + definition.getId());
    }

    /** Called when the gamemode is disabled. */
    public void onDisable() {
        org.bukkit.event.HandlerList.unregisterAll(this);
    }

    /** Called when a player joins this gamemode. */
    public void onPlayerJoin(Player player) {
        activePlayers.add(player.getUniqueId());
        applyGameRules(player);
        sendWelcomeMessage(player);
    }

    /** Called when a player leaves this gamemode. */
    public void onPlayerLeave(Player player) {
        activePlayers.remove(player.getUniqueId());
        removeGameRules(player);
    }

    // ── Subclass API ─────────────────────────────────────────────────────────

    public abstract String getId();
    public abstract String getDisplayName();
    public abstract String getDescription();
    public abstract void   applyGameRules(Player player);
    public abstract void   removeGameRules(Player player);
    public abstract void   sendWelcomeMessage(Player player);

    /** Build AI context string — info about the current state of this gamemode. */
    public abstract String buildAIContext();

    // ── Shared helpers ────────────────────────────────────────────────────────

    protected void sendActionBar(Player p, String mm) {
        p.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(mm));
    }

    protected void sendTitle(Player p, String title, String sub, int in, int stay, int out) {
        p.showTitle(net.kyori.adventure.text.title.Title.title(
                net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(title),
                net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(sub),
                net.kyori.adventure.text.title.Title.Times.times(
                        java.time.Duration.ofMillis(in * 50L),
                        java.time.Duration.ofMillis(stay * 50L),
                        java.time.Duration.ofMillis(out * 50L))));
    }

    protected boolean isInMode(Player p) {
        return activePlayers.contains(p.getUniqueId());
    }

    public GamemodeDefinition getDefinition() { return definition; }
    public Set<UUID> getActivePlayers()       { return Collections.unmodifiableSet(activePlayers); }
    public int getPlayerCount()               { return activePlayers.size(); }
}