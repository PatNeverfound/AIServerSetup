package com.example.aiserversetup.gamemodes;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.gamemodes.impl.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

import java.util.*;
import java.util.concurrent.*;

/**
 * Master registry for all gamemodes.
 * Routes players to gamemodes based on world or explicit assignment.
 * Handles cross-gamemode teleportation, GUI selector, per-player tracking.
 */
public class GamemodeManager implements Listener {

    private final AIServerSetupPlugin plugin;
    private final Map<String, AbstractGamemode> gamemodes = new LinkedHashMap<>();
    private final Map<UUID, String> playerMode = new ConcurrentHashMap<>();

    // World → gamemode mapping
    private final Map<String, String> worldModeMap = new ConcurrentHashMap<>();

    public GamemodeManager(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        registerAll();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    private void registerAll() {
        register(new SurvivalGamemode(plugin));
        register(new HardcoreGamemode(plugin));
        register(new LifestealGamemode(plugin));
        register(new FactionsGamemode(plugin));
        register(new TycoonGamemode(plugin));
        register(new PrisonGamemode(plugin));
        register(new SkyblockGamemode(plugin));
        register(new OneBlockGamemode(plugin));
        register(new KitPvPGamemode(plugin));
        register(new BedWarsGamemode(plugin));
        register(new SkyWarsGamemode(plugin));
        register(new RPGGamemode(plugin));
        register(new CreativePlotsGamemode(plugin));
        register(new EarthGamemode(plugin));
        register(new UHCGamemode(plugin));
    }

    public void register(AbstractGamemode gm) {
        gamemodes.put(gm.getId(), gm);
        gm.onEnable();
        // Auto-map world if it exists
        World w = Bukkit.getWorld(gm.getId() + "_world");
        if (w != null) worldModeMap.put(w.getName(), gm.getId());
    }

    public boolean setPlayerMode(Player player, String modeId) {
        AbstractGamemode gm = gamemodes.get(modeId.toLowerCase());
        if (gm == null || !gm.getDefinition().isEnabled()) return false;

        // Leave current mode
        String current = playerMode.get(player.getUniqueId());
        if (current != null && gamemodes.containsKey(current)) {
            gamemodes.get(current).onPlayerLeave(player);
        }

        // Join new mode
        playerMode.put(player.getUniqueId(), modeId);
        gm.onPlayerJoin(player);
        return true;
    }

    public String getPlayerMode(Player player) {
        return playerMode.getOrDefault(player.getUniqueId(), "survival");
    }

    public AbstractGamemode getMode(String id) { return gamemodes.get(id.toLowerCase()); }

    public <T extends AbstractGamemode> T getMode(Class<T> type) {
        return gamemodes.values().stream()
                .filter(type::isInstance).map(type::cast).findFirst().orElse(null);
    }

    // ── Auto-route on world change ────────────────────────────────────────────

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        String modeId = worldModeMap.get(e.getPlayer().getWorld().getName());
        if (modeId != null) setPlayerMode(e.getPlayer(), modeId);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        String savedMode = loadPlayerMode(e.getPlayer().getUniqueId());
        setPlayerMode(e.getPlayer(), savedMode != null ? savedMode : "survival");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        String mode = playerMode.get(e.getPlayer().getUniqueId());
        if (mode != null && gamemodes.containsKey(mode)) {
            gamemodes.get(mode).onPlayerLeave(e.getPlayer());
        }
        savePlayerMode(e.getPlayer().getUniqueId(), mode);
    }

    // ── GUI selector ─────────────────────────────────────────────────────────

    public void openSelectorGUI(Player player) {
        var inv = Bukkit.createInventory(null, 54,
                net.kyori.adventure.text.Component.text("✦ Select Gamemode"));
        int slot = 10;
        for (AbstractGamemode gm : gamemodes.values()) {
            if (!gm.getDefinition().isEnabled()) continue;
            if (slot >= 44) break;

            var icon = new org.bukkit.inventory.ItemStack(
                    parseMat(gm.getDefinition().getIcon()));
            var meta = icon.getItemMeta();
            String active = getPlayerMode(player).equals(gm.getId()) ? " <green>✔ ACTIVE" : "";
            meta.displayName(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<gold>" + gm.getDisplayName() + active));
            meta.lore(List.of(
                    net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize("<gray>" + gm.getDescription()),
                    net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize("<dark_gray>Players: <white>" + gm.getPlayerCount()),
                    net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize("<dark_gray>PvP: <white>" + (gm.getDefinition().isPvpEnabled() ? "§cON" : "§aOFF")),
                    net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize(""),
                    net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize("<yellow>Click to join!")));
            meta.getPersistentDataContainer().set(
                    new NamespacedKey(plugin, "gamemode_id"),
                    org.bukkit.persistence.PersistentDataType.STRING, gm.getId());
            icon.setItemMeta(meta);
            inv.setItem(slot++, icon);
            if ((slot - 10) % 7 == 7) slot += 2;
        }
        player.openInventory(inv);
    }

    @EventHandler
    public void onGUIClick(org.bukkit.event.inventory.InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!e.getView().title().toString().contains("Select Gamemode")) return;
        e.setCancelled(true);
        if (e.getCurrentItem() == null) return;
        var pdc = e.getCurrentItem().getItemMeta().getPersistentDataContainer();
        NamespacedKey key = new NamespacedKey(plugin, "gamemode_id");
        if (!pdc.has(key, org.bukkit.persistence.PersistentDataType.STRING)) return;
        String modeId = pdc.get(key, org.bukkit.persistence.PersistentDataType.STRING);
        p.closeInventory();
        boolean ok = setPlayerMode(p, modeId);
        if (!ok) plugin.getChatUtil().error(p, "Failed to switch to gamemode: " + modeId);
    }

    public Map<String, AbstractGamemode> getGamemodes()    { return gamemodes; }
    public String buildAIContext() {
        StringBuilder sb = new StringBuilder("=== Gamemodes ===\n");
        for (AbstractGamemode gm : gamemodes.values()) {
            if (gm.getDefinition().isEnabled()) {
                sb.append(gm.getDisplayName()).append(": ").append(gm.getPlayerCount()).append(" players\n");
            }
        }
        sb.append(gamemodes.values().stream().mapToString(AbstractGamemode::buildAIContext, "\n"));
        return sb.toString();
    }

    private Material parseMat(String s) {
        if (s == null) return Material.NETHER_STAR;
        try { return Material.valueOf(s); } catch (Exception e) { return Material.NETHER_STAR; }
    }

    private String loadPlayerMode(UUID uuid) { return null; }
    private void savePlayerMode(UUID uuid, String mode) { /* Save to config/db */ }
}