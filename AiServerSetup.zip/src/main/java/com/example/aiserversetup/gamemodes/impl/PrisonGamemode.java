package com.example.aiserversetup.gamemodes.impl;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.gamemodes.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;

import java.util.*;
import java.util.concurrent.*;

/**
 * PRISON GAMEMODE
 *
 * - Ranks A-Z then Prestige 1-10
 * - Each rank has a mine (auto-resets)
 * - Mine blocks → sell → rankup with /rankup
 * - Custom enchants scale with rank
 * - Gang system (mini-factions)
 * - Multiplier tokens, mine boosters
 * - Competitive: leaderboard by blocks mined / prestige
 */
public class PrisonGamemode extends AbstractGamemode {

    public record PrisonRank(String id, char letter, long rankupCost, String mineName, String color) {}
    public record PrisonPlayer(UUID uuid, char rank, int prestige, long blocksMined, double multiplier) {}

    private static final List<PrisonRank> RANKS = new ArrayList<>();
    private final Map<UUID, PrisonPlayer> players = new ConcurrentHashMap<>();

    static {
        String[] colors = {"§7","§7","§a","§a","§b","§b","§e","§e","§6","§6",
                           "§c","§c","§d","§d","§5","§5","§9","§9","§3","§3",
                           "§1","§1","§4","§4","§f","§f"};
        long baseCost = 5000;
        for (int i = 0; i < 26; i++) {
            char letter = (char)('A' + i);
            RANKS.add(new PrisonRank("rank_" + letter, letter, (long)(baseCost * Math.pow(1.6, i)),
                    "mine_" + letter, colors[i]));
        }
    }

    public PrisonGamemode(AIServerSetupPlugin plugin) {
        super(plugin, new GamemodeDefinition()
                .id("prison").displayName("Prison")
                .description("Mine, rank up A→Z, prestige, and dominate.")
                .icon("IRON_PICKAXE").pvp(false).hunger(false));
        loadData();
    }

    @Override public String getId()          { return "prison"; }
    @Override public String getDisplayName() { return "Prison"; }
    @Override public String getDescription() { return "Mine your way from A to Z — then prestige!"; }

    @Override
    public void applyGameRules(Player p) {
        p.setGameMode(GameMode.SURVIVAL);
        PrisonPlayer pp = players.computeIfAbsent(p.getUniqueId(),
                k -> new PrisonPlayer(k, 'A', 0, 0, 1.0));
        teleportToMine(p, pp.rank());
        showRankBar(p, pp);
    }

    @Override public void removeGameRules(Player p) {}

    @Override
    public void sendWelcomeMessage(Player p) {
        PrisonPlayer pp = players.get(p.getUniqueId());
        char rank    = pp == null ? 'A' : pp.rank();
        int prestige = pp == null ? 0   : pp.prestige();
        sendTitle(p, "<gold>⛏ Prison",
                "<gray>Rank <gold>" + rank + (prestige > 0 ? " <red>P" + prestige : "") + " — /rankup",
                10, 60, 10);
    }

    // ── Block break tracking ─────────────────────────────────────────────────

    @EventHandler(ignoreCancelled = true)
    public void onMine(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!isInMode(p)) return;
        PrisonPlayer pp = players.get(p.getUniqueId());
        if (pp == null) return;

        // Track blocks
        players.put(p.getUniqueId(), new PrisonPlayer(pp.uuid(), pp.rank(),
                pp.prestige(), pp.blocksMined() + 1, pp.multiplier()));

        // Sell on break
        double value = getBlockValue(e.getBlock().getType(), pp.rank(), pp.multiplier());
        if (value > 0 && plugin.getIntegrations().getVault() != null) {
            plugin.getIntegrations().getVault().getEconomy().depositPlayer(p, value);
        }
    }

    // ── Rankup ───────────────────────────────────────────────────────────────

    public boolean rankup(Player player) {
        PrisonPlayer pp = players.get(player.getUniqueId());
        if (pp == null) return false;

        PrisonRank currentRank = getRank(pp.rank());
        PrisonRank nextRank    = getNextRank(pp.rank());

        if (nextRank == null) {
            // Offer prestige
            player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<gold>You are at max rank! Use <aqua>/prestige</aqua> to prestige."));
            return false;
        }

        var eco = plugin.getIntegrations().getVault();
        if (eco == null || !eco.getEconomy().has(player, currentRank.rankupCost())) {
            player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<red>Need $" + String.format("%,d", currentRank.rankupCost()) +
                            " to rankup to " + nextRank.letter()));
            return false;
        }

        eco.getEconomy().withdrawPlayer(player, currentRank.rankupCost());
        players.put(player.getUniqueId(), new PrisonPlayer(pp.uuid(), nextRank.letter(),
                pp.prestige(), pp.blocksMined(), pp.multiplier()));

        teleportToMine(player, nextRank.letter());
        showRankBar(player, players.get(player.getUniqueId()));
        sendTitle(player, "<gold>⬆ Ranked Up!", "<white>Rank <gold>" + nextRank.letter(), 5, 40, 10);
        Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<gold>[Prison] <white>" + player.getName() +
                        " <gray>ranked up to <gold>" + nextRank.letter() + "!"));
        saveData();
        return true;
    }

    public boolean prestige(Player player) {
        PrisonPlayer pp = players.get(player.getUniqueId());
        if (pp == null || pp.rank() != 'Z') return false;

        int newPrestige = pp.prestige() + 1;
        if (newPrestige > 10) {
            player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize("<red>Max prestige reached!"));
            return false;
        }

        players.put(player.getUniqueId(), new PrisonPlayer(pp.uuid(), 'A',
                newPrestige, pp.blocksMined(), pp.multiplier() + 0.5));

        sendTitle(player, "<red>✦ PRESTIGE " + newPrestige, "<gray>You've reset with +0.5x multiplier!", 10, 80, 10);
        Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<red>✦ <white>" + player.getName() + " <gray>reached <red>Prestige " + newPrestige + "!"));
        saveData();
        return true;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private double getBlockValue(Material m, char rank, double multiplier) {
        double base = switch (m) {
            case STONE, COBBLESTONE -> 1;
            case COAL_ORE           -> 3;
            case IRON_ORE           -> 8;
            case GOLD_ORE           -> 15;
            case DIAMOND_ORE        -> 50;
            case EMERALD_ORE        -> 80;
            case ANCIENT_DEBRIS     -> 200;
            default                 -> 0;
        };
        int rankBonus = (rank - 'A') + 1;
        return base * rankBonus * multiplier;
    }

    private void teleportToMine(Player p, char rank) {
        String worldName = "prison_mine_" + rank;
        World w = Bukkit.getWorld(worldName);
        if (w != null) p.teleport(w.getSpawnLocation());
    }

    private void showRankBar(Player p, PrisonPlayer pp) {
        sendActionBar(p, "<gold>Rank <white>" + pp.rank() +
                (pp.prestige() > 0 ? " <red>P" + pp.prestige() : "") +
                " <gray>| <yellow>x" + String.format("%.1f", pp.multiplier()) +
                " <gray>| <green>" + String.format("%,d", pp.blocksMined()) + " blocks");
    }

    private PrisonRank getRank(char letter) {
        return RANKS.stream().filter(r -> r.letter() == letter).findFirst().orElse(RANKS.get(0));
    }

    private PrisonRank getNextRank(char letter) {
        if (letter >= 'Z') return null;
        return getRank((char)(letter + 1));
    }

    public List<PrisonPlayer> getLeaderboard(int limit) {
        return players.values().stream()
                .sorted(Comparator.comparingInt(PrisonPlayer::prestige)
                        .thenComparingLong(PrisonPlayer::blocksMined).reversed())
                .limit(limit).toList();
    }

    private void loadData()  { /* Load from JSON */ }
    private void saveData()  { /* Save to JSON */ }

    @Override
    public String buildAIContext() {
        return "=== Prison ===\nPlayers: " + activePlayers.size() + " | Ranks: A-Z + 10 Prestiges\n";
    }
}