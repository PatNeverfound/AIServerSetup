package com.example.aiserversetup.gamemodes.impl;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.gamemodes.*;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.*;

/**
 * HARDCORE GAMEMODE — Fixed for Paper 1.21.4
 * - PlayerProfile-based ban
 */
public class HardcoreGamemode extends AbstractGamemode {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final Set<UUID>          dead = new HashSet<>();
    private final Map<UUID, Long>    diedAt = new HashMap<>();

    public enum DeathAction { PERMANENT_BAN, TEMP_BAN, SPECTATOR, ELIMINATION }

    private final DeathAction deathAction;
    private final long        banHours;
    private final boolean     reviveEnabled;

    public HardcoreGamemode() {
        super(new GamemodeDefinition()
                .id("hardcore").displayName("Hardcore")
                .description("One life. Die and you're out.")
                .icon("WITHER_SKELETON_SKULL").pvp(true).hunger(true).deathBan(true));
        this.deathAction   = DeathAction.TEMP_BAN;
        this.banHours      = 24;
        this.reviveEnabled = true;
    }

    @Override public String getId()          { return "hardcore"; }
    @Override public String getDisplayName() { return "Hardcore"; }
    @Override public String getDescription() { return "One life — die and face the consequences."; }

    @Override
    public void onEnable(PluginCore core) {
        super.onEnable(core);
        loadDead();
    }

    @Override
    public void applyGameRules(Player p) {
        p.setGameMode(GameMode.SURVIVAL);
        if (p.getWorld() != null) p.getWorld().setDifficulty(Difficulty.HARD);
    }

    @Override public void removeGameRules(Player p) {}

    @Override
    public void sendWelcomeMessage(Player p) {
        sendTitle(p, "<dark_red>☠ HARDCORE",
                "<gray>One life. Make it count.", 10, 80, 10);
        p.sendMessage(MM.deserialize(
                "<dark_red>☠ <red>HARDCORE — <gray>You have ONE life. " +
                "Die and you are banned for <red>" + banHours + " hours</red>."));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        Player p = event.getEntity();
        if (!isInMode(p)) return;

        dead.add(p.getUniqueId());
        diedAt.put(p.getUniqueId(), System.currentTimeMillis());

        Bukkit.broadcast(MM.deserialize(
                "<dark_red>☠ <white>" + p.getName() + " <gray>has been eliminated from Hardcore!"));

        switch (deathAction) {
            case PERMANENT_BAN -> Bukkit.getScheduler().runTaskLater(PluginCore.get().getPlugin(), () -> {
                // FIX: BanList.Type.PROFILE
                Bukkit.getBanList(BanList.Type.PROFILE)
                        .addBan(p.getPlayerProfile(), "§cHardcore — Permanent elimination", null, "Hardcore");
                p.kickPlayer("§c☠ You have died in Hardcore.\n§7This ban is permanent.");
            }, 20L);

            case TEMP_BAN -> Bukkit.getScheduler().runTaskLater(PluginCore.get().getPlugin(), () -> {
                java.util.Date expiry = java.util.Date.from(
                        java.time.Instant.now().plusSeconds(banHours * 3600L));
                // FIX: BanList.Type.PROFILE
                Bukkit.getBanList(BanList.Type.PROFILE)
                        .addBan(p.getPlayerProfile(), "§cHardcore death — " + banHours + "h ban", expiry, "Hardcore");
                p.kickPlayer("§c☠ Hardcore Death!\n§7Banned for " + banHours + " hours.");
            }, 20L);

            case SPECTATOR -> Bukkit.getScheduler().runTaskLater(PluginCore.get().getPlugin(), () -> {
                p.setGameMode(GameMode.SPECTATOR);
                p.sendMessage(MM.deserialize("<gray>You are now a spectator."));
            }, 20L);

            case ELIMINATION -> Bukkit.getScheduler().runTaskLater(PluginCore.get().getPlugin(), () ->
                    p.kickPlayer("§c☠ You have been eliminated from Hardcore!"), 20L);
        }
        saveDead();
    }

    public boolean revivePlayer(String playerName) {
        if (!reviveEnabled) return false;
        UUID target = null;
        for (UUID u : dead) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(u);
            if (playerName.equalsIgnoreCase(op.getName())) { target = u; break; }
        }
        if (target == null) return false;
        dead.remove(target);
        // FIX: pardon by player name still works here
        Bukkit.getBanList(BanList.Type.PROFILE).pardon(Bukkit.getOfflinePlayer(target).getPlayerProfile());
        Bukkit.broadcast(MM.deserialize(
                "<green>✦ <white>" + playerName + " <green>has been revived on Hardcore!"));
        saveDead();
        return true;
    }

    public List<String> getDeadPlayers() {
        return dead.stream()
                .map(u -> {
                    String n = Bukkit.getOfflinePlayer(u).getName();
                    return n != null ? n : u.toString();
                })
                .toList();
    }

    private void loadDead() {
        java.io.File f = new java.io.File(PluginCore.get().getPlugin().getDataFolder(), "hardcore_dead.json");
        if (!f.exists()) return;
        try {
            String[] arr = new com.google.gson.Gson().fromJson(
                    java.nio.file.Files.readString(f.toPath()), String[].class);
            if (arr != null) for (String s : arr) {
                try { dead.add(UUID.fromString(s)); } catch (IllegalArgumentException ignored) {}
            }
        } catch (Exception ignored) {}
    }

    private void saveDead() {
        java.io.File f = new java.io.File(PluginCore.get().getPlugin().getDataFolder(), "hardcore_dead.json");
        try {
            java.nio.file.Files.writeString(f.toPath(),
                    new com.google.gson.Gson().toJson(
                            dead.stream().map(UUID::toString).toArray(String[]::new)));
        } catch (Exception ignored) {}
    }

    @Override
    public String buildAIContext() {
        return "=== Hardcore ===\nDead: " + dead.size() +
                " | Action: " + deathAction + " | Revive: " + reviveEnabled + "\n";
    }
}