package com.example.aiserversetup.gamemodes.impl;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.gamemodes.*;
import org.bukkit.*;
import org.bukkit.entity.Player;

public class SurvivalGamemode extends AbstractGamemode {
    public SurvivalGamemode(AIServerSetupPlugin plugin) {
        super(plugin, new GamemodeDefinition().id("survival").displayName("Survival")
                .description("Classic vanilla survival with plugins.").icon("GRASS_BLOCK").pvp(true).hunger(true));
    }
    @Override public String getId()          { return "survival"; }
    @Override public String getDisplayName() { return "Survival"; }
    @Override public String getDescription() { return "Classic survival SMP."; }
    @Override public void applyGameRules(Player p)  { p.setGameMode(GameMode.SURVIVAL); }
    @Override public void removeGameRules(Player p) {}
    @Override public void sendWelcomeMessage(Player p) {
        sendTitle(p, "<green>🌍 Survival", "<gray>Good luck!", 10, 40, 10);
    }
    @Override public String buildAIContext() {
        return "=== Survival ===\nPlayers: " + activePlayers.size() + "\n";
    }
}