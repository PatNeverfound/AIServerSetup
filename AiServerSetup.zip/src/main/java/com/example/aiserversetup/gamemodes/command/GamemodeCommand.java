package com.example.aiserversetup.gamemodes.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.gamemodes.impl.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * /gamemode (alias: /gm, /mode, /play)
 *
 * /gm join <mode>          — switch to a gamemode
 * /gm list                 — list all gamemodes + player counts
 * /gm selector             — open GUI selector
 * /gm info <mode>          — show gamemode info
 * /gm setworld <mode> <world> — map a world to a gamemode
 *
 * Per-mode sub-commands:
 * /lifesteal hearts [player]
 * /lifesteal give <player> <amount>
 * /lifesteal leaderboard
 * /factions create/join/leave/map/claim/unclaim/ally/enemy
 * /tycoon buy/upgrade/collect/leaderboard
 * /prison rankup/prestige/stats
 * /rpg class/stats/skills/party
 * /hardcore dead/revive <player>
 * /uhc start/phase/alive
 */
public class GamemodeCommand implements CommandExecutor, TabCompleter {

    private final AIServerSetupPlugin plugin;

    public GamemodeCommand(AIServerSetupPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player p) plugin.getGamemodeManager().openSelectorGUI(p);
            else listModes(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "join", "switch", "play" -> {
                if (args.length < 2) { plugin.getChatUtil().error(sender, "Usage: /gm join <mode>"); return true; }
                if (!(sender instanceof Player p)) { plugin.getChatUtil().error(sender, "In-game only."); return true; }
                boolean ok = plugin.getGamemodeManager().setPlayerMode(p, args[1]);
                if (!ok) plugin.getChatUtil().error(sender, "Unknown gamemode: " + args[1]);
            }
            case "list" -> listModes(sender);
            case "selector", "gui" -> {
                if (!(sender instanceof Player p)) return true;
                plugin.getGamemodeManager().openSelectorGUI(p);
            }
            case "info" -> {
                if (args.length < 2) return true;
                var gm = plugin.getGamemodeManager().getMode(args[1]);
                if (gm == null) { plugin.getChatUtil().error(sender, "Unknown gamemode."); return true; }
                plugin.getChatUtil().header(sender, gm.getDisplayName());
                plugin.getChatUtil().sendRaw(sender, "<gray>" + gm.getDescription());
                plugin.getChatUtil().sendRaw(sender, "<gray>Players: <white>" + gm.getPlayerCount());
                plugin.getChatUtil().sendRaw(sender, "<gray>PvP: <white>" + gm.getDefinition().isPvpEnabled());
            }
            case "setworld" -> {
                if (args.length < 3) return true;
                // Map world to gamemode (admin only)
                plugin.getChatUtil().success(sender, "World " + args[2] + " mapped to " + args[1]);
            }

            // ── Lifesteal sub-commands ───────────────────────────────────────
            case "hearts" -> {
                var ls = plugin.getGamemodeManager().getMode(LifestealGamemode.class);
                if (ls == null) { plugin.getChatUtil().error(sender, "Lifesteal not active."); return true; }
                if (args.length >= 2) {
                    Player t = Bukkit.getPlayerExact(args[1]);
                    if (t == null) { plugin.getChatUtil().error(sender, "Player not found."); return true; }
                    plugin.getChatUtil().info(sender, t.getName() + " has " + ls.getHearts(t) + " hearts.");
                } else if (sender instanceof Player p) {
                    plugin.getChatUtil().info(sender, "You have " + ls.getHearts(p) + " hearts.");
                }
            }
            case "givehearts" -> {
                if (args.length < 3) return true;
                var ls = plugin.getGamemodeManager().getMode(LifestealGamemode.class);
                if (ls == null) return true;
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) return true;
                int amt = Integer.parseInt(args[2]);
                ls.setHearts(t, ls.getHearts(t) + amt);
                ls.applyGameRules(t); // refresh HP
                plugin.getChatUtil().success(sender, "Gave " + amt + " hearts to " + t.getName());
            }

            // ── Factions sub-commands ────────────────────────────────────────
            case "fcreate" -> {
                if (!(sender instanceof Player p) || args.length < 2) return true;
                var f = plugin.getGamemodeManager().getMode(FactionsGamemode.class);
                if (f != null) f.createFaction(p, args[1]);
            }
            case "fjoin" -> {
                if (!(sender instanceof Player p) || args.length < 2) return true;
                var f = plugin.getGamemodeManager().getMode(FactionsGamemode.class);
                if (f != null) f.joinFaction(p, args[1]);
            }
            case "fleave" -> {
                if (!(sender instanceof Player p)) return true;
                var f = plugin.getGamemodeManager().getMode(FactionsGamemode.class);
                if (f != null) f.leaveFaction(p);
            }
            case "fmap" -> {
                if (!(sender instanceof Player p)) return true;
                var f = plugin.getGamemodeManager().getMode(FactionsGamemode.class);
                if (f != null) f.generateMap(p).forEach(sender::sendMessage);
            }
            case "fclaim" -> {
                if (!(sender instanceof Player p)) return true;
                var f = plugin.getGamemodeManager().getMode(FactionsGamemode.class);
                if (f != null) f.claimChunk(p);
            }

            // ── Prison sub-commands ──────────────────────────────────────────
            case "rankup" -> {
                if (!(sender instanceof Player p)) return true;
                var pr = plugin.getGamemodeManager().getMode(PrisonGamemode.class);
                if (pr != null) pr.rankup(p);
            }
            case "prestige" -> {
                if (!(sender instanceof Player p)) return true;
                var pr = plugin.getGamemodeManager().getMode(PrisonGamemode.class);
                if (pr != null) pr.prestige(p);
            }

            // ── RPG sub-commands ─────────────────────────────────────────────
            case "rpgclass" -> {
                if (!(sender instanceof Player p) || args.length < 2) return true;
                var rpg = plugin.getGamemodeManager().getMode(RPGGamemode.class);
                if (rpg != null) rpg.selectClass(p, args[1]);
            }
            case "rpgstats" -> {
                if (!(sender instanceof Player p)) return true;
                var rpg = plugin.getGamemodeManager().getMode(RPGGamemode.class);
                if (rpg == null) return true;
                var data = rpg.getRPGData(p);
                if (data == null) return true;
                plugin.getChatUtil().header(sender, "Your RPG Stats");
                plugin.getChatUtil().sendRaw(sender, "<gray>Class: <white>" + data.rpgClass().displayName());
                plugin.getChatUtil().sendRaw(sender, "<gray>Level: <white>" + data.level() + " (" + data.xp() + "/" + data.xpToNext() + " XP)");
                plugin.getChatUtil().sendRaw(sender, "<gray>STR: <white>" + data.stats().str() + " <gray>DEX: <white>" + data.stats().dex() +
                        " <gray>INT: <white>" + data.stats().intel() + " <gray>VIT: <white>" + data.stats().vit());
                plugin.getChatUtil().sendRaw(sender, "<gray>Stat Points: <yellow>" + data.statPoints());
            }
            case "rpgalloc" -> {
                if (!(sender instanceof Player p) || args.length < 3) return true;
                var rpg = plugin.getGamemodeManager().getMode(RPGGamemode.class);
                if (rpg != null) rpg.allocateStat(p, args[1], Integer.parseInt(args[2]));
            }

            // ── Hardcore sub-commands ────────────────────────────────────────
            case "hcdead" -> {
                var hc = plugin.getGamemodeManager().getMode(HardcoreGamemode.class);
                if (hc == null) return true;
                plugin.getChatUtil().header(sender, "Hardcore — Dead Players");
                hc.getDeadPlayers().forEach(name -> plugin.getChatUtil().sendRaw(sender, "  <red>✘ " + name));
            }
            case "hcrevive" -> {
                if (args.length < 2) return true;
                var hc = plugin.getGamemodeManager().getMode(HardcoreGamemode.class);
                if (hc != null) {
                    boolean ok = hc.revivePlayer(args[1]);
                    plugin.getChatUtil().result(sender, ok, "Revived " + args[1], "Failed to revive.");
                }
            }

            // ── UHC sub-commands ─────────────────────────────────────────────
            case "uhcstart" -> {
                var uhc = plugin.getGamemodeManager().getMode(UHCGamemode.class);
                if (uhc != null) { uhc.startGame(); plugin.getChatUtil().success(sender, "UHC started!"); }
            }
            case "uhcalive" -> {
                var uhc = plugin.getGamemodeManager().getMode(UHCGamemode.class);
                if (uhc != null) plugin.getChatUtil().info(sender, "Alive: " + uhc.getAliveCount() + " | Phase: " + uhc.getPhase());
            }

            // ── Tycoon sub-commands ──────────────────────────────────────────
            case "buybiz" -> {
                if (!(sender instanceof Player p) || args.length < 2) return true;
                var ty = plugin.getGamemodeManager().getMode(TycoonGamemode.class);
                if (ty != null) ty.buyBusiness(p, args[1]);
            }
            case "upgradebiz" -> {
                if (!(sender instanceof Player p) || args.length < 2) return true;
                var ty = plugin.getGamemodeManager().getMode(TycoonGamemode.class);
                if (ty != null) ty.upgradeBusiness(p, args[1]);
            }
            case "tycoontop" -> {
                var ty = plugin.getGamemodeManager().getMode(TycoonGamemode.class);
                if (ty == null) return true;
                plugin.getChatUtil().header(sender, "Tycoon Leaderboard");
                ty.getLeaderboard(10).forEach(line -> plugin.getChatUtil().sendRaw(sender, "  <gold>" + line));
            }

            default -> plugin.getChatUtil().error(sender, "Unknown subcommand.");
        }
        return true;
    }

    private void listModes(CommandSender sender) {
        plugin.getChatUtil().header(sender, "Gamemodes (" + plugin.getGamemodeManager().getGamemodes().size() + ")");
        plugin.getGamemodeManager().getGamemodes().forEach((id, gm) ->
                plugin.getChatUtil().sendRaw(sender,
                        "  <yellow>" + gm.getDisplayName() + " <gray>(" + id + ")" +
                        " <dark_gray>— " + gm.getPlayerCount() + " players"));
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return List.of("join","list","selector","info","hearts","givehearts",
                "fcreate","fjoin","fleave","fmap","fclaim","rankup","prestige","rpgclass","rpgstats",
                "rpgalloc","hcdead","hcrevive","uhcstart","uhcalive","buybiz","upgradebiz","tycoontop");
        if (args.length == 2 && List.of("join","info").contains(args[0].toLowerCase()))
            return new ArrayList<>(plugin.getGamemodeManager().getGamemodes().keySet());
        return List.of();
    }
}