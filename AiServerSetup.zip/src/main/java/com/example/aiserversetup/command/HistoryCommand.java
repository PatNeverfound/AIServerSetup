package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.util.ActionHistory;
import org.bukkit.command.*;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** /aihistory [undo] — shows the full action audit trail. */
public class HistoryCommand implements CommandExecutor {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private final AIServerSetupPlugin plugin;

    public HistoryCommand(AIServerSetupPlugin p) { this.plugin = p; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        var chat = plugin.getChatUtil();

        if (args.length > 0 && args[0].equalsIgnoreCase("undo")) {
            var opt = plugin.getActionHistory().popLast();
            if (opt.isEmpty()) { chat.warn(sender, "Nothing to undo."); return true; }
            var a = opt.get();
            boolean ok = switch (a.type()) {
                case SERVER_PROPERTY -> plugin.getFileEditor().setServerProperty(a.key(), a.oldValue());
                case YAML -> {
                    String[] parts = a.key().split(":", 2);
                    yield parts.length == 2 && plugin.getFileEditor().setYamlValue(parts[0], parts[1], a.oldValue());
                }
                default -> false;
            };
            if (ok) chat.success(sender, "Undone: <aqua>" + a.key() + "</aqua> → <green>" + a.oldValue() + "</green>");
            else    chat.error(sender, "Could not undo: " + a.key());
            return true;
        }

        chat.header(sender, "AI Action History");
        List<ActionHistory.Action> all = plugin.getActionHistory().getAll();
        if (all.isEmpty()) { chat.warn(sender, "No actions recorded yet."); return true; }

        for (int i = all.size() - 1; i >= 0; i--) {
            var a    = all.get(i);
            String t = Instant.ofEpochMilli(a.timestamp()).atZone(ZoneId.systemDefault()).toLocalTime().format(FMT);
            chat.sendRaw(sender, "  <dark_gray>[" + t + "]</dark_gray> "
                    + "<yellow>" + a.type().name() + "</yellow> "
                    + "<aqua>" + a.key() + "</aqua> "
                    + "<gray>" + a.oldValue() + " → <green>" + a.newValue() + "</green></gray>");
        }
        chat.sendRaw(sender, "<gray>Use <yellow>/aihistory undo</yellow> to revert the last action.</gray>");
        return true;
    }
}