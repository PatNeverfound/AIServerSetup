            // Delegate to integration processor if not matched above
            default -> {
                if (!IntegrationApplyProcessor.handle(sender, obj, plugin)) {
                    chat.warn(sender, "Unknown action type: " + type);
                }
            }