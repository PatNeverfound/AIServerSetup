package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.command.*;

/** /aiupdate [check|install <name>|all|backup] */
public class UpdateCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;

    public UpdateCommand(AIServerSetupPlugin p) { this.plugin = p; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        var chat   = plugin.getChatUtil();
        var market = plugin.getMarketplace();

        String sub = args.length > 0 ? args[0].toLowerCase() : "check";

        switch (sub) {
            case "check" -> market.getUpdater().checkAll(sender);
            case "install" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aiupdate install <plugin-name>"); return true; }
                market.getUpdater().updatePlugin(args[1], sender);
            }
            case "all" -> {
                chat.header(sender, "Updating All Plugins");
                market.getUpdater().checkAll(sender).thenAccept(updates -> {
                    if (updates.isEmpty()) return;
                    chat.sendRaw(sender, "<yellow>Downloading " + updates.size() + " updates...</yellow>");
                    updates.forEach(u -> market.getInstaller().install(u.entry(), sender));
                });
            }
            case "backup" -> {
                plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                    try { market.getBackup().backupJars(sender); }
                    catch (Exception e) { chat.error(sender, "Backup failed: " + e.getMessage()); }
                });
            }
            default -> {
                chat.info(sender, "Usage: /aiupdate [check|install <name>|all|backup]");
            }
        }
        return true;
    }
}