            // ── CMI ────────────────────────────────────────────────────────
            case "cmi-set-balance" -> {
                if (integ.getCmi() == null) { chat.error(sender, "CMI not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) { chat.error(sender, "Player not online."); return true; }
                boolean ok = integ.getCmi().setBalance(p, obj.get("amount").getAsDouble());
                chat.result(sender, ok, "CMI balance set for " + p.getName(), "Failed.");
            }
            case "cmi-deposit" -> {
                if (integ.getCmi() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                chat.result(sender, integ.getCmi().deposit(p, obj.get("amount").getAsDouble()), "CMI deposit done.", "Failed.");
            }
            case "cmi-freeze" -> {
                if (integ.getCmi() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                boolean freeze = !obj.has("freeze") || obj.get("freeze").getAsBoolean();
                chat.result(sender, integ.getCmi().freezePlayer(p, freeze),
                        (freeze?"Froze ":"Unfroze ") + p.getName(), "Failed.");
            }
            case "cmi-nick" -> {
                if (integ.getCmi() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                chat.result(sender, integ.getCmi().setNick(p, obj.get("nick").getAsString()),
                        "Set CMI nick for " + p.getName(), "Failed.");
            }
            case "cmi-jail" -> {
                if (integ.getCmi() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                String jail = obj.has("jail") ? obj.get("jail").getAsString() : "default";
                String dur  = obj.has("duration") ? obj.get("duration").getAsString() : "1h";
                chat.result(sender, integ.getCmi().jailPlayer(p, jail, dur), "Jailed " + p.getName(), "Failed.");
            }
            case "cmi-fly" -> {
                if (integ.getCmi() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                boolean fly = !obj.has("fly") || obj.get("fly").getAsBoolean();
                chat.result(sender, integ.getCmi().setFly(p, fly), "CMI fly set for " + p.getName(), "Failed.");
            }

            // ── LiteBans ──────────────────────────────────────────────────
            case "liteban-ban" -> {
                if (integ.getLiteBan() == null) { chat.error(sender, "LiteBans not loaded."); return true; }
                String player = obj.get("player").getAsString();
                String reason = obj.has("reason") ? obj.get("reason").getAsString() : "Banned by AI";
                String dur    = obj.has("duration") ? obj.get("duration").getAsString() : "-1";
                chat.result(sender, integ.getLiteBan().banPlayer(player, reason, dur), "Banned " + player, "Failed.");
            }
            case "liteban-unban" -> {
                if (integ.getLiteBan() == null) return true;
                chat.result(sender, integ.getLiteBan().unbanPlayer(obj.get("player").getAsString()),
                        "Unbanned " + obj.get("player").getAsString(), "Failed.");
            }
            case "liteban-mute" -> {
                if (integ.getLiteBan() == null) return true;
                chat.result(sender, integ.getLiteBan().mutePlayer(obj.get("player").getAsString(),
                        obj.has("reason") ? obj.get("reason").getAsString() : "Muted by AI",
                        obj.has("duration") ? obj.get("duration").getAsString() : "1h"),
                        "Muted player.", "Failed.");
            }
            case "liteban-kick" -> {
                if (integ.getLiteBan() == null) return true;
                chat.result(sender, integ.getLiteBan().kickPlayer(obj.get("player").getAsString(),
                        obj.has("reason") ? obj.get("reason").getAsString() : "Kicked by AI"),
                        "Kicked player.", "Failed.");
            }
            case "liteban-warn" -> {
                if (integ.getLiteBan() == null) return true;
                chat.result(sender, integ.getLiteBan().warnPlayer(obj.get("player").getAsString(),
                        obj.has("reason") ? obj.get("reason").getAsString() : "Warning"),
                        "Warned player.", "Failed.");
            }

            // ── Disguises ─────────────────────────────────────────────────
            case "disguise-mob" -> {
                if (integ.getLibsDisguises() == null) { chat.error(sender, "LibsDisguises not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                boolean ok = integ.getLibsDisguises().disguiseAsMob(p,
                        org.bukkit.entity.EntityType.valueOf(obj.get("mob").getAsString().toUpperCase()));
                chat.result(sender, ok, "Disguised " + p.getName() + " as " + obj.get("mob").getAsString(), "Failed.");
            }
            case "disguise-player" -> {
                if (integ.getLibsDisguises() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                chat.result(sender, integ.getLibsDisguises().disguiseAsPlayer(p, obj.get("as").getAsString()),
                        "Disguised " + p.getName(), "Failed.");
            }
            case "undisguise" -> {
                if (integ.getLibsDisguises() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                chat.result(sender, integ.getLibsDisguises().undisguise(p), "Undisguised " + p.getName(), "Failed.");
            }

            // ── Oraxen / ItemsAdder ───────────────────────────────────────
            case "oraxen-give" -> {
                if (integ.getOraxen() == null) { chat.error(sender, "Oraxen not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                int amt = obj.has("amount") ? obj.get("amount").getAsInt() : 1;
                chat.result(sender, integ.getOraxen().giveItem(p, obj.get("item").getAsString(), amt),
                        "Gave Oraxen item to " + p.getName(), "Failed — item ID not found?");
            }
            case "itemsadder-give" -> {
                if (integ.getItemsAdder() == null) { chat.error(sender, "ItemsAdder not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                int amt = obj.has("amount") ? obj.get("amount").getAsInt() : 1;
                chat.result(sender, integ.getItemsAdder().giveItem(p, obj.get("item").getAsString(), amt),
                        "Gave ItemsAdder item to " + p.getName(), "Failed — namespace:id not found?");
            }

            // ── Maintenance ────────────────────────────────────────────────
            case "maintenance-on" -> {
                if (integ.getMaintenance() == null) { chat.error(sender, "Maintenance not loaded."); return true; }
                String reason = obj.has("reason") ? obj.get("reason").getAsString() : "";
                chat.result(sender, integ.getMaintenance().enableMaintenance(reason),
                        "Maintenance mode ENABLED.", "Failed.");
            }
            case "maintenance-off" -> {
                if (integ.getMaintenance() == null) return true;
                chat.result(sender, integ.getMaintenance().disableMaintenance(), "Maintenance mode DISABLED.", "Failed.");
            }
            case "maintenance-motd" -> {
                if (integ.getMaintenance() == null) return true;
                chat.result(sender, integ.getMaintenance().setMotd(obj.get("motd").getAsString()),
                        "Maintenance MOTD set.", "Failed.");
            }

            // ── Auto-Restart ───────────────────────────────────────────────
            case "autorestart-schedule" -> {
                if (integ.getAutoRestart() == null) { chat.error(sender, "UltimateAutoRestart not loaded."); return true; }
                int secs = obj.has("seconds") ? obj.get("seconds").getAsInt() : 300;
                chat.result(sender, integ.getAutoRestart().scheduleRestart(secs),
                        "Restart scheduled in " + secs + "s.", "Failed.");
            }
            case "autorestart-cancel" -> {
                if (integ.getAutoRestart() == null) return true;
                chat.result(sender, integ.getAutoRestart().cancelRestart(), "Restart cancelled.", "Failed.");
            }

            // ── TempFly ────────────────────────────────────────────────────
            case "tempfly-grant" -> {
                if (integ.getTempFly() == null) { chat.error(sender, "Tempfly not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                int secs = obj.has("seconds") ? obj.get("seconds").getAsInt() : 3600;
                chat.result(sender, integ.getTempFly().grantFly(p, secs),
                        "Granted fly to " + p.getName() + " for " + secs + "s.", "Failed.");
            }
            case "tempfly-revoke" -> {
                if (integ.getTempFly() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                chat.result(sender, integ.getTempFly().revokeFly(p), "Revoked fly from " + p.getName(), "Failed.");
            }

            // ── Holograms ─────────────────────────────────────────────────
            case "hologram-create" -> {
                if (integ.getDecentHolograms() == null) { chat.error(sender, "DecentHolograms not loaded."); return true; }
                String name = obj.get("name").getAsString();
                List<String> lines = new java.util.ArrayList<>();
                obj.get("lines").getAsJsonArray().forEach(e -> lines.add(e.getAsString()));
                // Use sender's location if player, else console needs a world position
                org.bukkit.Location loc = null;
                if (sender instanceof Player p) loc = p.getLocation();
                else if (obj.has("world")) {
                    org.bukkit.World w = Bukkit.getWorld(obj.get("world").getAsString());
                    if (w != null) loc = new org.bukkit.Location(w,
                            obj.get("x").getAsDouble(), obj.get("y").getAsDouble(), obj.get("z").getAsDouble());
                }
                if (loc == null) { chat.error(sender, "Location required for hologram."); return true; }
                chat.result(sender, integ.getDecentHolograms().createHologram(name, loc, lines),
                        "Created hologram: " + name, "Failed.");
            }
            case "hologram-delete" -> {
                if (integ.getDecentHolograms() == null) return true;
                chat.result(sender, integ.getDecentHolograms().deleteHologram(obj.get("name").getAsString()),
                        "Deleted hologram: " + obj.get("name").getAsString(), "Failed.");
            }

            // ── Crates ────────────────────────────────────────────────────
            case "crate-give-key" -> {
                if (integ.getPhoenixCrates() == null) { chat.error(sender, "PhoenixCrates not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                int amt = obj.has("amount") ? obj.get("amount").getAsInt() : 1;
                chat.result(sender, integ.getPhoenixCrates().giveKey(p, obj.get("crate").getAsString(), amt),
                        "Gave crate key to " + p.getName(), "Failed.");
            }

            // ── Kits ──────────────────────────────────────────────────────
            case "kit-give" -> {
                if (integ.getPlayerKits2() == null) { chat.error(sender, "PlayerKits2 not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                chat.result(sender, integ.getPlayerKits2().giveKit(p, obj.get("kit").getAsString()),
                        "Gave kit " + obj.get("kit").getAsString() + " to " + p.getName(), "Failed.");
            }
            case "kit-reset-cooldown" -> {
                if (integ.getPlayerKits2() == null) return true;
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                chat.result(sender, integ.getPlayerKits2().resetKitCooldown(p, obj.get("kit").getAsString()),
                        "Reset kit cooldown for " + p.getName(), "Failed.");
            }

            // ── Boosters ──────────────────────────────────────────────────
            case "booster-add" -> {
                if (integ.getAxBooster() == null) { chat.error(sender, "AxBooster not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                chat.result(sender, integ.getAxBooster().addBooster(p,
                        obj.get("type").getAsString(),
                        obj.has("multiplier") ? obj.get("multiplier").getAsDouble() : 2.0,
                        obj.has("seconds") ? obj.get("seconds").getAsInt() : 3600),
                        "Added booster to " + p.getName(), "Failed.");
            }

            // ── Generators ────────────────────────────────────────────────
            case "gens-give" -> {
                if (integ.getAxGens() == null) { chat.error(sender, "AxGens not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                int amt = obj.has("amount") ? obj.get("amount").getAsInt() : 1;
                chat.result(sender, integ.getAxGens().giveGenerator(p, obj.get("gen").getAsString(), amt),
                        "Gave generator to " + p.getName(), "Failed.");
            }

            // ── Auction House ──────────────────────────────────────────────
            case "ah-clear-expired" -> {
                if (integ.getAuctionHouse() == null) { chat.error(sender, "zAuctionHouse not loaded."); return true; }
                chat.result(sender, integ.getAuctionHouse().clearExpired(), "Cleared expired AH listings.", "Failed.");
            }

            // ── GriefPrevention ────────────────────────────────────────────
            case "gp-give-blocks" -> {
                if (integ.getGriefPrevention() == null) { chat.error(sender, "GriefPrevention not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                int amt = obj.has("amount") ? obj.get("amount").getAsInt() : 100;
                chat.result(sender, integ.getGriefPrevention().giveClaimBlocks(p, amt),
                        "Gave " + amt + " claim blocks to " + p.getName(), "Failed.");
            }

            // ── Skript ─────────────────────────────────────────────────────
            case "skript-create" -> {
                if (integ.getSkript() == null) { chat.error(sender, "Skript not loaded."); return true; }
                String filename = obj.get("filename").getAsString();
                String content  = obj.get("content").getAsString();
                chat.result(sender, integ.getSkript().createScript(filename, content),
                        "Created & loaded script: " + filename + ".sk", "Failed.");
            }
            case "skript-delete" -> {
                if (integ.getSkript() == null) return true;
                chat.result(sender, integ.getSkript().deleteScript(obj.get("filename").getAsString()),
                        "Deleted script.", "Failed.");
            }
            case "skript-reload" -> {
                if (integ.getSkript() == null) return true;
                chat.result(sender, integ.getSkript().reloadScript(obj.get("filename").getAsString()),
                        "Reloaded script.", "Failed.");
            }

            // ── Troll ─────────────────────────────────────────────────────
            case "troll" -> {
                if (integ.getTrollBoss() == null) { chat.error(sender, "TrollBoss not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                String type = obj.has("type") ? obj.get("type").getAsString() : "lightning";
                chat.result(sender, integ.getTrollBoss().trollPlayer(p, type),
                        "Trolled " + p.getName() + " with " + type, "Failed.");
            }

            // ── AdvancedEnchantments ───────────────────────────────────────
            case "ae-add-enchant" -> {
                if (integ.getAdvEnchants() == null) { chat.error(sender, "AdvancedEnchantments not loaded."); return true; }
                Player p = Bukkit.getPlayerExact(obj.get("player").getAsString());
                if (p == null) return true;
                int lvl = obj.has("level") ? obj.get("level").getAsInt() : 1;
                chat.result(sender, integ.getAdvEnchants().addEnchant(p, obj.get("enchant").getAsString(), lvl),
                        "Added enchant " + obj.get("enchant").getAsString() + " to " + p.getName(), "Failed.");
            }

            // ── Tebex ─────────────────────────────────────────────────────
            case "tebex-check" -> {
                if (integ.getTebex() == null) { chat.error(sender, "Tebex not loaded."); return true; }
                integ.getTebex().forceCheck();
                chat.success(sender, "Forced Tebex queue check.");
            }
            case "tebex-info" -> {
                if (integ.getTebex() == null) return true;
                integ.getTebex().getStoreInfo().thenAccept(info ->
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                chat.sendMultiline(sender, "Tebex Store Info:\n" + info)));
            }