package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.*;
import org.bukkit.command.*;

import java.util.List;

/** /aiwl <add|remove|list|op|deop> [player] */
public class WhitelistCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;

    public WhitelistCommand(AIServerSetupPlugin p) { this.plugin = p; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        var chat = plugin.getChatUtil();
        var fe   = plugin.getFileEditor();

        if (args.length == 0) { chat.info(sender, "Usage: /aiwl <add|remove|list|op|deop> [player]"); return true; }

        switch (args[0].toLowerCase()) {
            case "list" -> {
                chat.header(sender, "Whitelist");
                List<String> wl = fe.getWhitelist();
                if (wl.isEmpty()) { chat.warn(sender, "Whitelist is empty."); return true; }
                wl.forEach(p -> chat.sendRaw(sender, "  <white>• " + p + "</white>"));
                chat.info(sender, "Total: <yellow>" + wl.size() + "</yellow>");
            }
            case "add" -> {
                if (args.length < 2) { chat.warn(sender, "Specify a player name."); return true; }
                fe.addToWhitelist(args[1]);
                Bukkit.reloadWhitelist();
                chat.success(sender, "Added <yellow>" + args[1] + "</yellow> to whitelist.");
            }
            case "remove" -> {
                if (args.length < 2) { chat.warn(sender, "Specify a player name."); return true; }
                fe.removeFromWhitelist(args[1]);
                Bukkit.reloadWhitelist();
                chat.success(sender, "Removed <yellow>" + args[1] + "</yellow> from whitelist.");
            }
            case "op" -> {
                if (args.length < 2) { chat.warn(sender, "Specify a player name."); return true; }
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "op " + args[1]);
                chat.success(sender, "Opped <yellow>" + args[1] + "</yellow>.");
            }
            case "deop" -> {
                if (args.length < 2) { chat.warn(sender, "Specify a player name."); return true; }
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "deop " + args[1]);
                chat.success(sender, "De-opped <yellow>" + args[1] + "</yellow>.");
            }
            default -> chat.warn(sender, "Unknown sub-command.");
        }
        return true;
    }
}