package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.config.ScheduledTaskManager;
import org.bukkit.command.*;

/** /aischedule <list|add|remove|run> */
public class ScheduleCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;

    public ScheduleCommand(AIServerSetupPlugin p) { this.plugin = p; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        var chat = plugin.getChatUtil();
        var tm   = plugin.getTaskManager();

        if (args.length == 0) { chat.info(sender, "Usage: /aischedule <list|add|remove|run> [args]"); return true; }

        switch (args[0].toLowerCase()) {
            case "list" -> {
                chat.header(sender, "Scheduled AI Tasks");
                var tasks = tm.getTasks();
                if (tasks.isEmpty()) { chat.warn(sender, "No scheduled tasks."); return true; }
                tasks.forEach(t -> chat.sendRaw(sender,
                        "  <aqua>" + t.id() + "</aqua> <gray>[" + t.cron() + "]</gray> "
                        + "<white>" + t.prompt().substring(0, Math.min(50, t.prompt().length())) + "…</white>"));
            }
            case "add" -> {
                if (args.length < 4) {
                    chat.warn(sender, "Usage: /aischedule add <id> <HH:MM> <prompt...>");
                    return true;
                }
                String id     = args[1];
                String time   = args[2];
                String prompt = String.join(" ", java.util.Arrays.copyOfRange(args, 3, args.length));
                tm.addTask(id, time, prompt);
                chat.success(sender, "Scheduled task <yellow>" + id + "</yellow> at " + time + ".");
            }
            case "remove" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aischedule remove <id>"); return true; }
                boolean ok = tm.removeTask(args[1]);
                if (ok) chat.success(sender, "Removed task <yellow>" + args[1] + "</yellow>.");
                else    chat.error(sender, "Task not found: " + args[1]);
            }
            case "run" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aischedule run <id>"); return true; }
                boolean ok = tm.runNow(args[1], sender);
                if (!ok) chat.error(sender, "Task not found: " + args[1]);
            }
            default -> chat.warn(sender, "Unknown sub-command.");
        }
        return true;
    }
}