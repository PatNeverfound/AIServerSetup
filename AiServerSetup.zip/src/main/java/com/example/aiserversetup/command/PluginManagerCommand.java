package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.plugin.Plugin;

/**
 * /aiplugin <list | enable <name> | disable <name> | reload <name>>
 */
public class PluginManagerCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;
    private final ChatUtil chat;

    public PluginManagerCommand(AIServerSetupPlugin plugin, ChatUtil chat) {
        this.plugin = plugin;
        this.chat   = chat;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            chat.info(sender, "Usage: <aqua>/aiplugin <list|enable|disable|reload> [name]</aqua>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "list" -> {
                chat.header(sender, "Loaded Plugins");
                for (Plugin p : Bukkit.getPluginManager().getPlugins()) {
                    String color  = p.isEnabled() ? "<green>" : "<red>";
                    String status = p.isEnabled() ? "✔" : "✘";
                    chat.sendRaw(sender, "  " + color + status + " " + p.getName()
                            + " v" + p.getDescription().getVersion() + "</" + color.substring(1));
                }
            }
            case "enable" -> {
                if (args.length < 2) { chat.warn(sender, "Specify a plugin name."); return true; }
                Plugin p = Bukkit.getPluginManager().getPlugin(args[1]);
                if (p == null) { chat.error(sender, "Plugin '" + args[1] + "' not found."); return true; }
                if (p.isEnabled()) { chat.warn(sender, p.getName() + " is already enabled."); return true; }
                Bukkit.getPluginManager().enablePlugin(p);
                chat.success(sender, "Enabled <yellow>" + p.getName() + "</yellow>.");
            }
            case "disable" -> {
                if (args.length < 2) { chat.warn(sender, "Specify a plugin name."); return true; }
                Plugin p = Bukkit.getPluginManager().getPlugin(args[1]);
                if (p == null) { chat.error(sender, "Plugin '" + args[1] + "' not found."); return true; }
                if (!p.isEnabled()) { chat.warn(sender, p.getName() + " is already disabled."); return true; }
                if (p.getName().equals("AIServerSetup")) { chat.error(sender, "Cannot disable self!"); return true; }
                Bukkit.getPluginManager().disablePlugin(p);
                chat.success(sender, "Disabled <yellow>" + p.getName() + "</yellow>.");
            }
            case "reload" -> {
                if (args.length < 2) { chat.warn(sender, "Specify a plugin name."); return true; }
                Plugin p = Bukkit.getPluginManager().getPlugin(args[1]);
                if (p == null) { chat.error(sender, "Plugin '" + args[1] + "' not found."); return true; }
                if (p.getName().equals("AIServerSetup")) { chat.error(sender, "Use /reload or restart instead."); return true; }
                Bukkit.getPluginManager().disablePlugin(p);
                Bukkit.getPluginManager().enablePlugin(p);
                chat.success(sender, "Reloaded <yellow>" + p.getName() + "</yellow>.");
            }
            default -> chat.warn(sender, "Unknown sub-command. Use list, enable, disable, or reload.");
        }

        return true;
    }
}