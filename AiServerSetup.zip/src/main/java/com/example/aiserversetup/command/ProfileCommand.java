package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.config.FileEditor;
import com.example.aiserversetup.config.ProfileManager;
import com.example.aiserversetup.util.ChatUtil;
import org.bukkit.command.*;

import java.util.List;
import java.util.Map;

/**
 * /aiprofile <list | save <name> | load <name> | delete <name>>
 */
public class ProfileCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;
    private final ProfileManager profiles;
    private final FileEditor fileEditor;
    private final ChatUtil chat;

    public ProfileCommand(AIServerSetupPlugin plugin, ProfileManager pm, FileEditor fe, ChatUtil chat) {
        this.plugin      = plugin;
        this.profiles    = pm;
        this.fileEditor  = fe;
        this.chat        = chat;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            chat.info(sender, "Usage: <aqua>/aiprofile <list|save|load|delete> [name]</aqua>");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "list" -> {
                List<String> list = profiles.listProfiles();
                chat.header(sender, "Saved Profiles");
                if (list.isEmpty()) {
                    chat.warn(sender, "No profiles saved yet. Use /aiprofile save <name>.");
                } else {
                    list.forEach(p -> chat.sendRaw(sender,
                            "  <aqua>• " + p + "</aqua> <dark_gray>— /aiprofile load " + p + "</dark_gray>"));
                }
            }
            case "save" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aiprofile save <name>"); return true; }
                try {
                    Map<String, String> props = profiles.captureCurrentProperties();
                    profiles.saveProfile(args[1], props);
                    chat.success(sender, "Profile <yellow>" + args[1] + "</yellow> saved ("
                            + props.size() + " properties).");
                } catch (Exception e) {
                    chat.error(sender, "Failed to save profile: " + e.getMessage());
                }
            }
            case "load" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aiprofile load <name>"); return true; }
                try {
                    Map<String, String> props = profiles.loadProfile(args[1]);
                    int applied = 0;
                    for (Map.Entry<String, String> e : props.entrySet()) {
                        if (fileEditor.setServerProperty(e.getKey(), e.getValue())) applied++;
                    }
                    chat.success(sender, "Profile <yellow>" + args[1] + "</yellow> loaded: "
                            + applied + "/" + props.size() + " properties applied.");
                    chat.warn(sender, "Restart required for changes to take effect.");
                } catch (Exception e) {
                    chat.error(sender, "Failed to load profile: " + e.getMessage());
                }
            }
            case "delete" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aiprofile delete <name>"); return true; }
                boolean ok = profiles.deleteProfile(args[1]);
                if (ok) chat.success(sender, "Profile <yellow>" + args[1] + "</yellow> deleted.");
                else    chat.error(sender, "Profile '" + args[1] + "' not found.");
            }
            default -> chat.warn(sender, "Unknown sub-command. Use list, save, load, or delete.");
        }

        return true;
    }
}