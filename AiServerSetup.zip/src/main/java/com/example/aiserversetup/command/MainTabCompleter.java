package com.example.aiserversetup.command;

import org.bukkit.command.*;

import java.util.List;
import java.util.stream.Collectors;

public class MainTabCompleter implements TabCompleter {

    private static final List<String> SUB = List.of("gui", "reset", "history", "model");
    private static final List<String> MODELS = List.of("gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo", "gpt-4o-mini");

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return SUB.stream().filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("model")) {
            return MODELS.stream().filter(m -> m.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}