package com.example.aiserversetup.command;

import com.example.aiserversetup.core.PluginCore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.function.*;

/**
 * Lightweight command framework.
 * Supports sub-commands, permissions, player-only, tab-complete, help auto-gen.
 *
 * Usage:
 *   new CommandFramework.Builder("mycommand")
 *       .permission("myplugin.cmd")
 *       .sub("give", "Give item", (s,a) -> giveItem(s,a))
 *       .register(plugin);
 */
public class CommandFramework implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final String name;
    private final Map<String, SubCommand> subs = new LinkedHashMap<>();
    private String defaultPermission;
    private BiConsumer<CommandSender, String[]> defaultHandler;

    public CommandFramework(String name) { this.name = name; }

    // ── Builder API ───────────────────────────────────────────────────────────

    public CommandFramework sub(String sub, SubCommand cmd) {
        subs.put(sub.toLowerCase(), cmd);
        return this;
    }

    public CommandFramework sub(String sub, String desc, BiConsumer<CommandSender, String[]> handler) {
        return sub(sub, new SubCommand(desc, null, handler, null, false));
    }

    public CommandFramework sub(String sub, String desc, String perm,
                                BiConsumer<CommandSender, String[]> handler,
                                Supplier<List<String>> tabComplete,
                                boolean playerOnly) {
        return sub(sub, new SubCommand(desc, perm, handler, tabComplete, playerOnly));
    }

    public CommandFramework defaultHandler(BiConsumer<CommandSender, String[]> h) {
        this.defaultHandler = h; return this;
    }

    public CommandFramework permission(String perm) {
        this.defaultPermission = perm; return this;
    }

    public void register(PluginCore core) {
        PluginCommand cmd = core.getPlugin().getCommand(name);
        if (cmd == null) {
            core.getPlugin().getLogger().warning("[Commands] Command not found in plugin.yml: " + name);
            return;
        }
        cmd.setExecutor(this);
        cmd.setTabCompleter(this);
    }

    // ── Execution ─────────────────────────────────────────────────────────────

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (defaultPermission != null && !sender.hasPermission(defaultPermission)) {
            sender.sendMessage(MM.deserialize("<red>You don't have permission to use this command."));
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendHelp(sender);
            return true;
        }

        String subName = args[0].toLowerCase();
        SubCommand sub = subs.get(subName);

        if (sub == null) {
            if (defaultHandler != null) { defaultHandler.accept(sender, args); return true; }
            sender.sendMessage(MM.deserialize("<red>Unknown subcommand. Use <yellow>/" + name + " help</yellow>"));
            return true;
        }

        if (sub.permission() != null && !sender.hasPermission(sub.permission())) {
            sender.sendMessage(MM.deserialize("<red>You don't have permission for this subcommand."));
            return true;
        }

        if (sub.playerOnly() && !(sender instanceof Player)) {
            sender.sendMessage(MM.deserialize("<red>This command can only be used in-game."));
            return true;
        }

        sub.handler().accept(sender, Arrays.copyOfRange(args, 1, args.length));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            return subs.keySet().stream()
                    .filter(s -> {
                        SubCommand sub = subs.get(s);
                        return sub.permission() == null || sender.hasPermission(sub.permission());
                    })
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .toList();
        }
        if (args.length >= 2) {
            SubCommand sub = subs.get(args[0].toLowerCase());
            if (sub != null && sub.tabComplete() != null) {
                return sub.tabComplete().get().stream()
                        .filter(s -> s.toLowerCase().startsWith(args[args.length-1].toLowerCase()))
                        .toList();
            }
        }
        return List.of();
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        sender.sendMessage(MM.deserialize("<gold>/" + name + " <gray>commands:"));
        subs.forEach((k, v) -> {
            if (v.permission() == null || sender.hasPermission(v.permission())) {
                sender.sendMessage(MM.deserialize("  <yellow>/" + name + " " + k +
                        " <gray>— " + v.description()));
            }
        });
        sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    // ── Records ───────────────────────────────────────────────────────────────

    public record SubCommand(
            String description,
            String permission,
            BiConsumer<CommandSender, String[]> handler,
            Supplier<List<String>> tabComplete,
            boolean playerOnly
    ) {}
}