package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

/**
 * /aistats [tps|mem|players|chunks|world]
 */
public class StatsCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;

    public StatsCommand(AIServerSetupPlugin p) { this.plugin = p; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        var chat = plugin.getChatUtil();
        String sub = args.length > 0 ? args[0].toLowerCase() : "all";

        chat.header(sender, "Server Performance Stats");

        if (sub.equals("tps") || sub.equals("all")) {
            double[] tps = Bukkit.getTPS();
            String c1 = tpsColor(tps[0]), c2 = tpsColor(tps[1]), c3 = tpsColor(tps[2]);
            chat.sendRaw(sender, "  <white>TPS:</white> <" + c1 + ">" + String.format("%.2f", tps[0]) + "</" + c1 + "> "
                    + "<gray>(5m: <" + c2 + ">" + String.format("%.2f", tps[1]) + "</" + c2 + "> "
                    + "15m: <" + c3 + ">" + String.format("%.2f", tps[2]) + "</" + c3 + ">)</gray>");
        }

        if (sub.equals("mem") || sub.equals("all")) {
            Runtime rt = Runtime.getRuntime();
            long used  = (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024;
            long total = rt.totalMemory() / 1024 / 1024;
            long max   = rt.maxMemory() / 1024 / 1024;
            double pct = (double) used / max * 100;
            String col = pct > 85 ? "red" : pct > 65 ? "yellow" : "green";
            chat.sendRaw(sender, "  <white>Memory:</white> <" + col + ">" + used + "MB</" + col + ">"
                    + " / <gray>" + total + "MB allocated, " + max + "MB max</gray>"
                    + " <dark_gray>(" + String.format("%.1f", pct) + "%)</dark_gray>");
        }

        if (sub.equals("players") || sub.equals("all")) {
            int online = Bukkit.getOnlinePlayers().size();
            int max    = Bukkit.getMaxPlayers();
            chat.sendRaw(sender, "  <white>Players:</white> <aqua>" + online + "</aqua><gray>/" + max + "</gray>");
            if (sub.equals("players")) {
                Bukkit.getOnlinePlayers().forEach(p -> {
                    long ping = p.getPing();
                    String pc = ping > 200 ? "red" : ping > 100 ? "yellow" : "green";
                    chat.sendRaw(sender, "    <gray>• </gray><white>" + p.getName()
                            + "</white> <dark_gray>ping: <" + pc + ">" + ping + "ms</" + pc + "></dark_gray>");
                });
            }
        }

        if (sub.equals("chunks") || sub.equals("all")) {
            int total = 0;
            for (World w : Bukkit.getWorlds()) total += w.getLoadedChunks().length;
            chat.sendRaw(sender, "  <white>Loaded Chunks:</white> <yellow>" + total + "</yellow>");
            if (sub.equals("chunks")) {
                for (World w : Bukkit.getWorlds()) {
                    chat.sendRaw(sender, "    <gray>• " + w.getName() + ": <white>"
                            + w.getLoadedChunks().length + "</white> chunks</gray>");
                }
            }
        }

        if (sub.equals("world") || sub.equals("all")) {
            for (World w : Bukkit.getWorlds()) {
                chat.sendRaw(sender, "  <white>" + w.getName() + "</white> "
                        + "<gray>[" + w.getEnvironment().name() + "] "
                        + "entities: <white>" + w.getEntityCount() + "</white>"
                        + " time: <white>" + w.getTime() + "</white></gray>");
            }
        }

        // AI token stats
        if (sub.equals("ai") || sub.equals("all")) {
            chat.sendRaw(sender, "  <white>AI Usage:</white> <gray>" + plugin.getTokenTracker().summary() + "</gray>");
        }

        return true;
    }

    private String tpsColor(double tps) {
        return tps >= 19 ? "green" : tps >= 15 ? "yellow" : "red";
    }
}