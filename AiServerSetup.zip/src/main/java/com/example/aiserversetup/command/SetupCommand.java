package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.ai.AIResponse;
import com.example.aiserversetup.util.BossBarManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.stream.Collectors;

/**
 * /aisetup [gui|wizard|reset|history|model|cost|undo|confirm|cancel] [args...]
 */
public class SetupCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;

    public SetupCommand(AIServerSetupPlugin p) { this.plugin = p; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        var chat = plugin.getChatUtil();

        if (args.length == 0) {
            printHelp(sender);
            return true;
        }

        String senderName = (sender instanceof Player p) ? p.getName() : "CONSOLE";

        switch (args[0].toLowerCase()) {
            case "gui" -> {
                if (!(sender instanceof Player p)) { chat.error(sender, "GUI is in-game only."); return true; }
                plugin.getSetupGUI().open(p);
            }
            case "wizard" -> {
                if (!(sender instanceof Player p)) { chat.error(sender, "Wizard is in-game only."); return true; }
                plugin.getWizard().start(p);
            }
            case "reset" -> {
                plugin.getConversations().clearHistory(senderName);
                chat.success(sender, "Conversation history cleared.");
            }
            case "history" -> {
                int size = plugin.getConversations().historySize(senderName);
                chat.info(sender, "You have <yellow>" + size + "</yellow> messages in history.");
            }
            case "model" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aisetup model <name>"); return true; }
                plugin.getAiClient().setModel(args[1]);
                plugin.getStreamingClient().setModel(args[1]);
                chat.success(sender, "Model set to <aqua>" + args[1] + "</aqua>.");
            }
            case "cost" -> {
                chat.header(sender, "Token Usage & Cost");
                chat.info(sender, plugin.getTokenTracker().summary());
            }
            case "undo" -> handleUndo(sender);
            case "confirm" -> {
                boolean ok = plugin.getConfirmations().confirm(senderName);
                if (ok) chat.success(sender, "Action confirmed and executed.");
                else    chat.warn(sender, "No pending action to confirm (or it expired).");
            }
            case "cancel" -> {
                boolean ok = plugin.getConfirmations().cancel(senderName);
                if (ok) chat.success(sender, "Action cancelled.");
                else    chat.warn(sender, "No pending action to cancel.");
            }
            default -> {
                // Free-form chat
                String message = String.join(" ", args);
                sendToAI(sender, senderName, message);
            }
        }

        return true;
    }

    private void sendToAI(CommandSender sender, String senderName, String message) {
        var chat     = plugin.getChatUtil();
        var conv     = plugin.getConversations();
        var context  = buildContext();
        boolean streaming = plugin.getConfig().getBoolean("streaming", true);

        conv.addUserMessage(senderName, message);
        plugin.getSessionLogger().log(senderName, "user", message);

        if (sender instanceof Player player) {
            BossBarManager.showThinking(player);
            player.sendActionBar(MiniMessage.miniMessage().deserialize(
                    "<gradient:#00c6ff:#0072ff>⟳ AI is processing your request...</gradient>"));
        }

        var messages = conv.buildMessages(senderName, context);

        if (streaming && sender instanceof Player player) {
            StringBuilder buffer = new StringBuilder();
            plugin.getStreamingClient().streamChat(messages,
                    token -> buffer.append(token),
                    response -> plugin.getServer().getScheduler().runTask(plugin, () -> {
                        BossBarManager.hide(player);
                        BossBarManager.showSuccess(player);
                        finishResponse(sender, senderName, response);
                    })
            );
        } else {
            plugin.getAiClient().chat(messages).thenAccept(response ->
                    plugin.getServer().getScheduler().runTask(plugin, () -> {
                        if (sender instanceof Player p) {
                            BossBarManager.hide(p);
                            BossBarManager.showSuccess(p);
                        }
                        finishResponse(sender, senderName, response);
                    })
            );
        }
    }

    private void finishResponse(CommandSender sender, String senderName, AIResponse response) {
        var chat = plugin.getChatUtil();
        plugin.getConversations().addAssistantMessage(senderName, response.content());
        plugin.getSessionLogger().log(senderName, "assistant", response.content());
        plugin.getTokenTracker().record(response.promptTokens(), response.completionTokens());

        ApplyProcessor.process(sender, response.content(), plugin);

        String display = ApplyProcessor.stripBlocks(response.content());
        chat.header(sender, "AI Response");
        chat.sendMultiline(sender, display);

        // Token usage footer
        if (plugin.getConfig().getBoolean("show-token-usage", true) && response.totalTokens() > 0) {
            chat.sendRaw(sender, "<dark_gray>Tokens: " + response.totalTokens()
                    + " | Model: " + response.modelUsed()
                    + (plugin.getConfig().getBoolean("show-cost-estimate", true)
                       ? " | ~$" + String.format("%.5f", response.estimatedCostUSD()) : "")
                    + "</dark_gray>");
        }

        // Discord notification
        plugin.getDiscordWebhook().sendIfEnabled(
                "**[AI Response]** `" + senderName + "` → " + display.substring(0, Math.min(display.length(), 200)));
    }

    private void handleUndo(CommandSender sender) {
        var chat = plugin.getChatUtil();
        var opt  = plugin.getActionHistory().popLast();
        if (opt.isEmpty()) { chat.warn(sender, "Nothing to undo."); return; }

        var action = opt.get();
        boolean ok = switch (action.type()) {
            case SERVER_PROPERTY -> plugin.getFileEditor().setServerProperty(action.key(), action.oldValue());
            case YAML -> {
                String[] parts = action.key().split(":", 2);
                yield parts.length == 2 && plugin.getFileEditor().setYamlValue(parts[0], parts[1], action.oldValue());
            }
            default -> false;
        };

        if (ok) chat.success(sender, "Undone: <aqua>" + action.key() + "</aqua> restored to <green>"
                + action.oldValue() + "</green>.");
        else    chat.error(sender, "Failed to undo last action.");
    }

    private String buildContext() {
        var fe = plugin.getFileEditor();
        var sb = new StringBuilder();
        sb.append("Server Version: ").append(org.bukkit.Bukkit.getVersion()).append("\n");
        sb.append("Online: ").append(org.bukkit.Bukkit.getOnlinePlayers().size())
          .append("/").append(org.bukkit.Bukkit.getMaxPlayers()).append("\n");
        sb.append("TPS: ").append(String.format("%.2f", org.bukkit.Bukkit.getTPS()[0])).append("\n");
        sb.append("Memory: ").append((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1024 / 1024)
          .append("MB used / ").append(Runtime.getRuntime().maxMemory() / 1024 / 1024).append("MB max\n");
        sb.append("Plugins: ").append(
                java.util.Arrays.stream(org.bukkit.Bukkit.getPluginManager().getPlugins())
                        .map(p -> p.getName() + (p.isEnabled() ? "" : "[off]"))
                        .collect(java.util.stream.Collectors.joining(", "))).append("\n");
        sb.append("server.properties (key settings):\n");
        var props = fe.getAllServerProperties();
        for (String key : new String[]{"gamemode","max-players","difficulty","pvp","spawn-protection",
                "motd","online-mode","hardcore","level-name","level-type","white-list"}) {
            if (props.containsKey(key)) sb.append("  ").append(key).append("=").append(props.get(key)).append("\n");
        }
        return sb.toString();
    }

    private void printHelp(CommandSender sender) {
        plugin.getChatUtil().header(sender, "AIServerSetup v3.0 Help");
        for (String line : new String[]{
                "<aqua>/aisetup <msg></aqua>     Chat with AI",
                "<aqua>/aisetup gui</aqua>        Open setup GUI",
                "<aqua>/aisetup wizard</aqua>     Launch setup wizard",
                "<aqua>/aisetup reset</aqua>      Clear history",
                "<aqua>/aisetup history</aqua>    Show history size",
                "<aqua>/aisetup model <m></aqua>  Switch AI model",
                "<aqua>/aisetup cost</aqua>       Show token usage & cost",
                "<aqua>/aisetup undo</aqua>       Undo last AI action",
                "<aqua>/aisetup confirm</aqua>    Confirm pending action",
                "<aqua>/aisetup cancel</aqua>     Cancel pending action",
                "<aqua>/aiaudit</aqua>            Full server audit",
                "<aqua>/aiprofile list</aqua>     Manage profiles",
                "<aqua>/aistats</aqua>            Live performance stats",
                "<aqua>/aischedule</aqua>         Scheduled tasks",
                "<aqua>/aiwl</aqua>              Whitelist/op management",
                "<aqua>/aihistory</aqua>          Action audit trail",
                "<aqua>/aidashboard start</aqua>  Web dashboard"
        }) plugin.getChatUtil().sendRaw(sender, "  " + line);
    }
}