package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.command.*;

/** /aidashboard <start|stop|status> */
public class DashboardCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;

    public DashboardCommand(AIServerSetupPlugin p) { this.plugin = p; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        var chat = plugin.getChatUtil();
        var dash = plugin.getWebDashboard();

        if (args.length == 0) { chat.info(sender, "Usage: /aidashboard <start|stop|status>"); return true; }

        switch (args[0].toLowerCase()) {
            case "start" -> {
                if (dash.isRunning()) { chat.warn(sender, "Dashboard already running."); return true; }
                dash.start();
                chat.success(sender, "Web dashboard started on port <aqua>"
                        + plugin.getConfig().getInt("dashboard.port", 8080) + "</aqua>.");
            }
            case "stop" -> {
                if (!dash.isRunning()) { chat.warn(sender, "Dashboard is not running."); return true; }
                dash.stop();
                chat.success(sender, "Web dashboard stopped.");
            }
            case "status" -> {
                if (dash.isRunning()) {
                    chat.sendRaw(sender, "<green>Dashboard is <bold>RUNNING</bold></green> on port "
                            + plugin.getConfig().getInt("dashboard.port", 8080));
                } else {
                    chat.sendRaw(sender, "<red>Dashboard is <bold>STOPPED</bold></red>");
                }
            }
            default -> chat.warn(sender, "Usage: /aidashboard <start|stop|status>");
        }
        return true;
    }
}