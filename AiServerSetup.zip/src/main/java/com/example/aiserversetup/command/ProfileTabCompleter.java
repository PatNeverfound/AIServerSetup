package com.example.aiserversetup.command;

import com.example.aiserversetup.config.ProfileManager;
import org.bukkit.command.*;

import java.util.List;
import java.util.stream.Collectors;

public class ProfileTabCompleter implements TabCompleter {

    private final ProfileManager profiles;
    private static final List<String> SUBS = List.of("list", "save", "load", "delete");

    public ProfileTabCompleter(ProfileManager profiles) {
        this.profiles = profiles;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1)
            return SUBS.stream().filter(s -> s.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
        if (args.length == 2 && (args[0].equalsIgnoreCase("load") || args[0].equalsIgnoreCase("delete")))
            return profiles.listProfiles().stream()
                    .filter(p -> p.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        return List.of();
    }
}