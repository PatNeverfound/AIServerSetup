package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.ai.AIClient;
import com.example.aiserversetup.config.ConversationManager;
import com.example.aiserversetup.config.FileEditor;
import com.example.aiserversetup.util.ChatUtil;
import com.example.aiserversetup.util.SessionLogger;
import org.bukkit.Bukkit;
import org.bukkit.command.*;

import java.util.List;
import java.util.Map;

/**
 * /aiaudit — AI scans current server config and gives improvement suggestions.
 */
public class AuditCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;
    private final AIClient aiClient;
    private final ConversationManager conversations;
    private final FileEditor fileEditor;
    private final SessionLogger logger;
    private final ChatUtil chat;

    public AuditCommand(AIServerSetupPlugin plugin, AIClient ai, ConversationManager conv,
                        FileEditor fe, SessionLogger log, ChatUtil chat) {
        this.plugin        = plugin;
        this.aiClient      = ai;
        this.conversations = conv;
        this.fileEditor    = fe;
        this.logger        = log;
        this.chat          = chat;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        chat.header(sender, "Server Audit");
        chat.sendRaw(sender, "<gray>Sending your config to the AI for analysis... please wait.</gray>");

        String serverProps = fileEditor.dumpServerProperties();
        String bukkitYml   = fileEditor.dumpYaml("bukkit.yml");

        String prompt = """
                Please perform a full audit of this Minecraft Paper server configuration.
                Identify: security issues, performance issues, bad defaults, and missing optimizations.
                For each issue, rate it as [CRITICAL], [WARNING], or [INFO].
                If you find settings to fix, emit APPLY blocks.
                
                === server.properties ===
                """ + serverProps + """
                
                === bukkit.yml ===
                """ + bukkitYml;

        String senderName = sender.getName();
        conversations.addUserMessage(senderName, "[AUDIT REQUEST]");
        logger.log(senderName, "user", "[AUDIT]");

        List<Map<String, String>> messages = conversations.buildMessages(senderName, null);
        // Replace last user message with full audit prompt
        messages.get(messages.size() - 1).put("content", prompt);

        aiClient.chat(messages).thenAccept(response ->
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    conversations.addAssistantMessage(senderName, response);
                    logger.log(senderName, "assistant", "[AUDIT RESULT] " + response);
                    ApplyProcessor.process(sender, response, fileEditor, chat, plugin);
                    chat.header(sender, "Audit Results");
                    chat.sendMultiline(sender, ApplyProcessor.stripBlocks(response));
                })
        );

        return true;
    }
}