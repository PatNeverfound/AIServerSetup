package com.example.aiserversetup.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.marketplace.*;
import com.example.aiserversetup.marketplace.PluginCatalog.Category;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * /aimarket [browse|search|install|info|categories|featured|backup|check]
 */
public class MarketplaceCommand implements CommandExecutor {

    private final AIServerSetupPlugin plugin;

    public MarketplaceCommand(AIServerSetupPlugin p) { this.plugin = p; }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        var chat   = plugin.getChatUtil();
        var market = plugin.getMarketplace();

        if (args.length == 0 || args[0].equalsIgnoreCase("browse")) {
            if (!(sender instanceof Player player)) { chat.error(sender, "GUI is in-game only."); return true; }
            market.getGui().openCategories(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "search" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aimarket search <query>"); return true; }
                String query = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));

                if (sender instanceof Player player) {
                    chat.sendRaw(sender, "<gradient:#00c6ff:#0072ff>🔍 Searching for \"" + query + "\"...</gradient>");
                }

                // Search both catalog and live APIs
                List<PluginCatalog.PluginEntry> catalogResults = PluginCatalog.search(query);

                if (sender instanceof Player player) {
                    if (!catalogResults.isEmpty()) {
                        market.getGui().openSearchResults(player, catalogResults, query);
                    } else {
                        // Live search Modrinth
                        market.getModrinth().search(query, 20).thenAccept(results -> {
                            plugin.getServer().getScheduler().runTask(plugin, () -> {
                                if (results.isEmpty()) { chat.warn(player, "No results found for \"" + query + "\"."); return; }
                                chat.header(player, "Live Modrinth Results for \"" + query + "\"");
                                results.forEach(r -> chat.sendRaw(player,
                                        "  <aqua>" + r.get("name") + "</aqua> "
                                        + "<gray>— " + r.get("description") + "</gray> "
                                        + "<yellow><click:run_command:'/aimarket install-live modrinth "
                                        + r.get("slug") + " " + r.get("name").replace(" ", "_")
                                        + "'>[Install]</click></yellow>"));
                            });
                        });
                    }
                } else {
                    // Console output
                    chat.header(sender, "Search Results: " + query);
                    catalogResults.forEach(p -> chat.sendRaw(sender,
                            "  <aqua>" + p.name() + "</aqua> — <gray>" + p.description() + "</gray>"));
                }
            }

            case "install" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aimarket install <plugin-id>"); return true; }
                chat.sendRaw(sender, "<yellow>⏳ Resolving dependencies...</yellow>");
                market.getInstaller().install(args[1], sender);
            }

            case "install-live" -> {
                // /aimarket install-live <source> <slug> <name>
                if (args.length < 4) return true;
                PluginCatalog.Source src = args[1].equalsIgnoreCase("modrinth")
                        ? PluginCatalog.Source.MODRINTH : PluginCatalog.Source.HANGAR;
                market.getInstaller().installLiveResult(args[3].replace("_", " "), args[2], src, sender);
            }

            case "info" -> {
                if (args.length < 2) { chat.warn(sender, "Usage: /aimarket info <plugin-id>"); return true; }
                PluginCatalog.findById(args[1]).ifPresentOrElse(p -> {
                    chat.header(sender, p.name());
                    chat.sendRaw(sender, "  <gray>" + p.description() + "</gray>");
                    chat.sendRaw(sender, "  <white>Category:</white> <aqua>" + p.category().name() + "</aqua>");
                    chat.sendRaw(sender, "  <white>Source:</white>   <aqua>" + p.source().name() + "</aqua>");
                    chat.sendRaw(sender, "  <white>Free:</white>     <aqua>" + p.free() + "</aqua>");
                    if (!p.dependencies().isEmpty())
                        chat.sendRaw(sender, "  <white>Deps:</white>     <yellow>" + String.join(", ", p.dependencies()) + "</yellow>");
                    chat.sendRaw(sender, "  <yellow><click:run_command:'/aimarket install " + p.id() + "'>[Install]</click></yellow>");
                }, () -> chat.error(sender, "Plugin '" + args[1] + "' not found in catalog."));
            }

            case "categories" -> {
                chat.header(sender, "Plugin Categories");
                for (Category cat : Category.values()) {
                    int count = PluginCatalog.byCategory(cat).size();
                    chat.sendRaw(sender, "  <aqua>" + cat.name() + "</aqua> <gray>(" + count + " plugins)</gray>");
                }
            }

            case "featured" -> {
                if (!(sender instanceof Player player)) {
                    chat.header(sender, "Featured Plugins");
                    PluginCatalog.getAll().stream().limit(15).forEach(p ->
                            chat.sendRaw(sender, "  <aqua>" + p.name() + "</aqua> — <gray>" + p.description() + "</gray>"));
                    return true;
                }
                market.getGui().openFeatured((Player) sender);
            }

            case "backup" -> {
                plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                    try {
                        market.getBackup().backupAll(sender);
                    } catch (Exception e) {
                        plugin.getServer().getScheduler().runTask(plugin, () ->
                                chat.error(sender, "Backup failed: " + e.getMessage()));
                    }
                });
            }

            case "check" -> {
                // Check installed plugins against catalog
                market.getUpdater().checkAll(sender);
            }

            case "list" -> {
                chat.header(sender, "Installed Plugins vs Catalog");
                for (org.bukkit.plugin.Plugin p : plugin.getServer().getPluginManager().getPlugins()) {
                    boolean inCatalog = PluginCatalog.findByName(p.getName()).isPresent();
                    String tag = inCatalog ? "<green>[catalog]</green>" : "<gray>[unknown]</gray>";
                    chat.sendRaw(sender, "  " + tag + " <white>" + p.getName()
                            + " v" + p.getDescription().getVersion() + "</white>");
                }
            }

            default -> {
                chat.header(sender, "Plugin Marketplace Help");
                for (String line : new String[]{
                        "<aqua>/aimarket</aqua>                — Open marketplace GUI",
                        "<aqua>/aimarket search <q></aqua>    — Search plugins",
                        "<aqua>/aimarket install <id></aqua>  — Install from catalog",
                        "<aqua>/aimarket info <id></aqua>     — Plugin details",
                        "<aqua>/aimarket categories</aqua>    — List categories",
                        "<aqua>/aimarket featured</aqua>      — Featured plugins",
                        "<aqua>/aimarket backup</aqua>        — Backup all plugins",
                        "<aqua>/aimarket check</aqua>         — Check for updates",
                        "<aqua>/aimarket list</aqua>          — List installed plugins"
                }) chat.sendRaw(sender, "  " + line);
            }
        }
        return true;
    }
}