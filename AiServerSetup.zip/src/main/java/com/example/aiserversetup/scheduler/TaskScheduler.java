package com.example.aiserversetup.scheduler;

import com.example.aiserversetup.core.PluginCore;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

/**
 * Wrapper around Bukkit's scheduler with task tracking and named tasks.
 */
public class TaskScheduler implements PluginCore.PluginModule {

    private final Map<String, BukkitTask> namedTasks = new ConcurrentHashMap<>();

    @Override
    public String name() { return "TaskScheduler"; }

    @Override
    public void onEnable(PluginCore core) {}

    @Override
    public void onDisable(PluginCore core) {
        namedTasks.values().forEach(BukkitTask::cancel);
        namedTasks.clear();
    }

    /** Run a task synchronously on the main thread. */
    public BukkitTask sync(Runnable r) {
        return Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), r);
    }

    /** Run a task asynchronously. */
    public BukkitTask async(Runnable r) {
        return Bukkit.getScheduler().runTaskAsynchronously(PluginCore.get().getPlugin(), r);
    }

    /** Run a delayed task (ticks). */
    public BukkitTask delay(Runnable r, long ticks) {
        return Bukkit.getScheduler().runTaskLater(PluginCore.get().getPlugin(), r, ticks);
    }

    /** Run a repeating task (ticks). */
    public BukkitTask repeat(Runnable r, long delayTicks, long periodTicks) {
        return Bukkit.getScheduler().runTaskTimer(PluginCore.get().getPlugin(), r, delayTicks, periodTicks);
    }

    /** Run a repeating async task. */
    public BukkitTask repeatAsync(Runnable r, long delayTicks, long periodTicks) {
        return Bukkit.getScheduler().runTaskTimerAsynchronously(
                PluginCore.get().getPlugin(), r, delayTicks, periodTicks);
    }

    /** Register a named repeating task (cancels previous one with same name). */
    public void register(String name, Runnable r, long delayTicks, long periodTicks) {
        cancel(name);
        namedTasks.put(name, repeat(r, delayTicks, periodTicks));
    }

    /** Cancel a named task. */
    public void cancel(String name) {
        BukkitTask t = namedTasks.remove(name);
        if (t != null) t.cancel();
    }

    public boolean isRunning(String name) {
        BukkitTask t = namedTasks.get(name);
        return t != null && !t.isCancelled();
    }

    public int activeCount() { return namedTasks.size(); }
}