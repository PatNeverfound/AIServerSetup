package com.example.aiserversetup;

import com.google.gson.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.io.*;
import java.nio.file.*;
import java.util.Properties;
import java.util.regex.*;

/**
 * Handles /aisetup <message> — sends the user's message to the AI and processes the response.
 */
public class SetupCommand implements CommandExecutor {

    private static final Pattern APPLY_PATTERN =
            Pattern.compile("===APPLY===\\s*(\\{.*?\\})\\s*===END===", Pattern.DOTALL);

    private final AIServerSetupPlugin plugin;
    private final AIClient aiClient;
    private final ConversationManager conversations;
    private final Gson gson = new Gson();

    public SetupCommand(AIServerSetupPlugin plugin, AIClient aiClient, ConversationManager conversations) {
        this.plugin = plugin;
        this.aiClient = aiClient;
        this.conversations = conversations;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§e[AISetup] §fUsage: /aisetup <your message or question>");
            return true;
        }

        String senderName = (sender instanceof Player p) ? p.getName() : "CONSOLE";
        String userMessage = String.join(" ", args);

        sender.sendMessage("§b[AISetup] §7Thinking... please wait.");

        conversations.addUserMessage(senderName, userMessage);

        aiClient.chat(conversations.buildMessages(senderName)).thenAccept(response -> {
            // Schedule back on the main thread for Bukkit API safety
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                conversations.addAssistantMessage(senderName, response);

                // Strip APPLY blocks from display text
                String displayText = response.replaceAll("===APPLY===.*?===END===", "").trim();

                sender.sendMessage("§a[AI] §f" + displayText.replace("\n", "\n§f"));

                // Process any APPLY blocks
                Matcher matcher = APPLY_PATTERN.matcher(response);
                while (matcher.find()) {
                    String json = matcher.group(1).trim();
                    processApply(sender, json);
                }
            });
        });

        return true;
    }

    /**
     * Parses and applies an AI-generated action block.
     */
    private void processApply(CommandSender sender, String json) {
        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            String type = obj.get("type").getAsString();

            switch (type) {
                case "server-property" -> {
                    String key = obj.get("key").getAsString();
                    String value = obj.get("value").getAsString();
                    applyServerProperty(sender, key, value);
                }
                case "plugin-recommendation" -> {
                    String name = obj.get("name").getAsString();
                    String url = obj.has("url") ? obj.get("url").getAsString() : "N/A";
                    String reason = obj.has("reason") ? obj.get("reason").getAsString() : "";
                    sender.sendMessage("§e[AISetup] §6Plugin Recommendation: §f" + name);
                    sender.sendMessage("§e[AISetup] §7Reason: §f" + reason);
                    sender.sendMessage("§e[AISetup] §7Download: §b" + url);
                }
                default -> sender.sendMessage("§c[AISetup] Unknown action type: " + type);
            }
        } catch (Exception e) {
            sender.sendMessage("§c[AISetup] Failed to parse AI action: " + e.getMessage());
        }
    }

    /**
     * Applies a key=value change to server.properties and notifies the sender.
     */
    private void applyServerProperty(CommandSender sender, String key, String value) {
        try {
            File serverPropertiesFile = new File("server.properties");
            if (!serverPropertiesFile.exists()) {
                sender.sendMessage("§c[AISetup] server.properties not found!");
                return;
            }

            Properties props = new Properties();
            try (InputStream in = new FileInputStream(serverPropertiesFile)) {
                props.load(in);
            }

            String oldValue = props.getProperty(key, "(not set)");
            props.setProperty(key, value);

            try (OutputStream out = new FileOutputStream(serverPropertiesFile)) {
                props.store(out, "Modified by AIServerSetup plugin");
            }

            sender.sendMessage("§a[AISetup] §fApplied: §e" + key + " §7= §a" + value
                    + " §7(was: §c" + oldValue + "§7)");
            sender.sendMessage("§7[AISetup] Restart your server for this change to take effect.");

        } catch (IOException e) {
            sender.sendMessage("§c[AISetup] Failed to update server.properties: " + e.getMessage());
        }
    }
}