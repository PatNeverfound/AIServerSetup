package com.example.aiserversetup.anticheat;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.util.StructuredLogger;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║           AIServerSetup AntiCheat Engine v1.0           ║
 * ╠══════════════════════════════════════════════════════════╣
 * ║  Checks:                                                 ║
 * ║  • FLY      — unsupported vertical movement             ║
 * ║  • SPEED    — horizontal movement exceeds physics cap   ║
 * ║  • REACH    — attack distance beyond hitbox + ping comp ║
 * ║  • KILLAURA — attacking while not facing target          ║
 * ║  • NOKNOCKBACK — ignoring server velocity               ║
 * ║  • PHASE    — moving through solid blocks               ║
 * ║  • SCAFFOLD — placing blocks under feet impossibly fast  ║
 * ║  • AUTOCLICK — CPS exceeds human maximum                ║
 * ║  • JESUS    — walking on water                          ║
 * ╚══════════════════════════════════════════════════════════╝
 */
public class AntiCheatEngine implements PluginCore.PluginModule, Listener {

    // ── Per-player state ──────────────────────────────────────────────────────

    private final Map<UUID, PlayerCheckData>          playerData  = new ConcurrentHashMap<>();
    private final Map<UUID, Map<CheckType, Violation>> violations  = new ConcurrentHashMap<>();

    private BukkitTask decayTask;
    private BukkitTask alertTask;

    // ── Config ────────────────────────────────────────────────────────────────

    private boolean enabled;
    private boolean flyEnabled;
    private boolean speedEnabled;
    private boolean reachEnabled;
    private boolean killAuraEnabled;
    private boolean noKbEnabled;
    private boolean phaseEnabled;
    private boolean scaffoldEnabled;
    private boolean autoClickEnabled;
    private boolean jesusEnabled;
    private boolean silentMode; // Flag only — don't cancel events
    private double  reachLimit;  // blocks
    private int     maxCPS;

    // ── Module lifecycle ──────────────────────────────────────────────────────

    @Override
    public String name() { return "AntiCheatEngine"; }

    @Override
    public void onEnable(PluginCore core) {
        var cfg = core.getPlugin().getConfig();
        enabled          = cfg.getBoolean("anticheat.enabled", true);
        if (!enabled) { core.getPlugin().getLogger().info("[AntiCheat] Disabled in config."); return; }

        flyEnabled        = cfg.getBoolean("anticheat.checks.fly",        true);
        speedEnabled      = cfg.getBoolean("anticheat.checks.speed",      true);
        reachEnabled      = cfg.getBoolean("anticheat.checks.reach",      true);
        killAuraEnabled   = cfg.getBoolean("anticheat.checks.killaura",   true);
        noKbEnabled       = cfg.getBoolean("anticheat.checks.noknockback",true);
        phaseEnabled      = cfg.getBoolean("anticheat.checks.phase",      true);
        scaffoldEnabled   = cfg.getBoolean("anticheat.checks.scaffold",   true);
        autoClickEnabled  = cfg.getBoolean("anticheat.checks.autoclick",  true);
        jesusEnabled      = cfg.getBoolean("anticheat.checks.jesus",      true);
        silentMode        = cfg.getBoolean("anticheat.silent-mode",       false);
        reachLimit        = cfg.getDouble("anticheat.reach-limit",        3.6);
        maxCPS            = cfg.getInt("anticheat.max-cps",              16);

        Bukkit.getPluginManager().registerEvents(this, core.getPlugin());

        // Violation decay every 10 seconds
        decayTask = Bukkit.getScheduler().runTaskTimerAsynchronously(
                core.getPlugin(), this::decayViolations, 200L, 200L);

        // Alert staff every 5 seconds about high-violation players
        alertTask = Bukkit.getScheduler().runTaskTimer(
                core.getPlugin(), this::alertStaff, 100L, 100L);

        core.getPlugin().getLogger().info("[AntiCheat] Enabled — " +
                (silentMode ? "SILENT MODE" : "ACTIVE MODE"));
    }

    @Override
    public void onDisable(PluginCore core) {
        if (decayTask != null) decayTask.cancel();
        if (alertTask != null) alertTask.cancel();
        playerData.clear();
        violations.clear();
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  CHECK 1 — FLY DETECTION
    // ══════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player p = event.getPlayer();
        if (!enabled || !isCheckable(p)) return;

        PlayerCheckData data = getOrCreate(p);
        Location from = event.getFrom();
        Location to   = event.getTo();
        if (to == null) return;

        double dx = to.getX() - from.getX();
        double dy = to.getY() - from.getY();
        double dz = to.getZ() - from.getZ();

        // ── FLY CHECK ────────────────────────────────────────────────────────
        if (flyEnabled && !p.isFlying() && !p.isGliding() &&
            !p.getAllowFlight() && !hasLevitation(p)) {

            if (dy > 0.42 + 0.001) { // Max jump height without jump boost is ~0.42
                int boost = getPotionLevel(p, org.bukkit.potion.PotionEffectType.JUMP_BOOST);
                double maxJump = 0.42 + (boost * 0.3);
                if (dy > maxJump + 0.05) {
                    int vl = flag(p, CheckType.FLY, "Vertical gain: " +
                            String.format("%.2f", dy) + " max=" + String.format("%.2f", maxJump));
                    if (vl >= 3 && !silentMode) {
                        snapBack(p, from);
                        event.setTo(from);
                    }
                }
            }

            // Sustained airtime (no ground contact, no effects, not near a ladder/vine)
            if (!p.isOnGround() && !isNearClimbable(p)) {
                data.airTicks++;
                if (data.airTicks > 40 && dy >= -0.001) { // Sustained flight, not falling
                    int vl = flag(p, CheckType.FLY, "Air ticks: " + data.airTicks);
                    if (vl >= 5 && !silentMode) snapBack(p, from);
                }
            } else {
                data.airTicks = 0;
            }
        }

        // ── SPEED CHECK ──────────────────────────────────────────────────────
        if (speedEnabled) {
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            double maxSpeed   = getMaxLegitSpeed(p);
            if (horizontal > maxSpeed + 0.05) {
                int vl = flag(p, CheckType.SPEED, "H-speed: " +
                        String.format("%.3f", horizontal) + " max=" + String.format("%.3f", maxSpeed));
                if (vl >= 4 && !silentMode) {
                    p.setVelocity(new Vector(0, 0, 0));
                    event.setTo(from);
                }
            }
        }

        // ── PHASE CHECK ──────────────────────────────────────────────────────
        if (phaseEnabled) {
            Location midpoint = from.clone().add(dx / 2, 0, dz / 2);
            if (midpoint.getBlock().getType().isSolid() && !midpoint.getBlock().isPassable()) {
                if (horizontal(dx, dz) > 0.3) {
                    flag(p, CheckType.PHASE, "Moved through solid block: " +
                            midpoint.getBlock().getType());
                }
            }
        }

        // ── JESUS CHECK ──────────────────────────────────────────────────────
        if (jesusEnabled) {
            org.bukkit.block.Block below = p.getLocation().getBlock()
                    .getRelative(org.bukkit.block.BlockFace.DOWN);
            if (below.isLiquid() && !p.isOnGround() && dy >= 0 &&
                !hasWaterWalking(p)) {
                flag(p, CheckType.JESUS, "Walking on " + below.getType());
            }
        }

        data.lastLocation = to;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  CHECK 2 — REACH + KILLAURA
    // ══════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player p)) return;
        if (!enabled || !isCheckable(p)) return;

        PlayerCheckData data = getOrCreate(p);
        long now = System.currentTimeMillis();

        // ── AUTOCLICK CHECK ──────────────────────────────────────────────────
        if (autoClickEnabled) {
            data.clickTimes.add(now);
            // Trim clicks older than 1 second
            data.clickTimes.removeIf(t -> now - t > 1000);
            int cps = data.clickTimes.size();
            if (cps > maxCPS) {
                int vl = flag(p, CheckType.AUTOCLICK, "CPS: " + cps + " max=" + maxCPS);
                if (vl >= 10 && !silentMode) event.setCancelled(true);
            }
        }

        // ── REACH CHECK ─────────────────────────────────────────────────────
        if (reachEnabled && event.getEntity() instanceof org.bukkit.entity.LivingEntity target) {
            double dist = p.getEyeLocation().distance(target.getLocation());
            // Add ping compensation (up to 200ms worth of movement ~0.5 blocks)
            double pingComp = Math.min(0.5, p.getPing() / 1000.0 * 5.0);
            double effectiveLimit = reachLimit + pingComp;

            if (dist > effectiveLimit) {
                int vl = flag(p, CheckType.REACH,
                        "Distance: " + String.format("%.2f", dist) +
                        " limit=" + String.format("%.2f", effectiveLimit));
                if (vl >= 3 && !silentMode) event.setCancelled(true);
            }

            // Ray-trace verification for hit legitimacy
            if (reachEnabled) {
                RayTraceResult rt = p.rayTraceEntities(effectiveLimit,
                        org.bukkit.FluidCollisionMode.NEVER);
                if (rt == null || !target.equals(rt.getHitEntity())) {
                    // Hit entity not in player's line of sight
                    int vl = flag(p, CheckType.KILLAURA, "Ray-trace failed — hit through wall or behind");
                    if (vl >= 3 && !silentMode) event.setCancelled(true);
                }
            }
        }

        // ── KILLAURA — angle check ────────────────────────────────────────────
        if (killAuraEnabled && event.getEntity() instanceof org.bukkit.entity.LivingEntity target) {
            Vector toTarget = target.getLocation().toVector()
                    .subtract(p.getEyeLocation().toVector()).normalize();
            Vector playerDir = p.getEyeLocation().getDirection().normalize();
            double dot = toTarget.dot(playerDir);
            double angle = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, dot))));

            if (angle > 75.0) { // More than 75° off — not looking at target
                int vl = flag(p, CheckType.KILLAURA,
                        "Attack angle: " + String.format("%.1f", angle) + "°");
                if (vl >= 2 && !silentMode) event.setCancelled(true);
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  CHECK 3 — NO KNOCKBACK
    // ════════════��═════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onVelocity(PlayerVelocityEvent event) {
        if (!enabled || !noKbEnabled) return;
        Player p = event.getPlayer();
        if (!isCheckable(p)) return;

        Vector vel = event.getVelocity();
        if (vel.lengthSquared() < 0.1) return; // Ignore tiny velocity changes

        PlayerCheckData data = getOrCreate(p);
        data.expectedVelocity   = vel.clone();
        data.velocitySetAt      = System.currentTimeMillis();
        data.locationBeforeVelocity = p.getLocation().clone();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMoveAfterVelocity(PlayerMoveEvent event) {
        if (!enabled || !noKbEnabled) return;
        Player p = event.getPlayer();
        PlayerCheckData data = playerData.get(p.getUniqueId());
        if (data == null || data.expectedVelocity == null) return;
        if (System.currentTimeMillis() - data.velocitySetAt > 400) {
            data.expectedVelocity = null;
            return;
        }

        // Player should have moved in the direction of the velocity
        double xzMoved = horizontal(
                event.getTo().getX() - data.locationBeforeVelocity.getX(),
                event.getTo().getZ() - data.locationBeforeVelocity.getZ()
        );
        double expectedXZ = horizontal(data.expectedVelocity.getX(), data.expectedVelocity.getZ());

        if (expectedXZ > 0.2 && xzMoved < 0.05) {
            flag(p, CheckType.NOKNOCKBACK, "Velocity ignored — expected xz=" +
                    String.format("%.2f", expectedXZ) + " moved=" + String.format("%.2f", xzMoved));
        }
        data.expectedVelocity = null;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  CHECK 4 — SCAFFOLD
    // ══════════════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockPlace(org.bukkit.event.block.BlockPlaceEvent event) {
        if (!enabled || !scaffoldEnabled) return;
        Player p = event.getPlayer();
        if (!isCheckable(p)) return;

        PlayerCheckData data = getOrCreate(p);
        long now = System.currentTimeMillis();

        // Check if placing blocks directly below their feet while moving
        org.bukkit.block.Block placed = event.getBlockPlaced();
        Location pLoc = p.getLocation();
        if (placed.getX() == pLoc.getBlockX() &&
            placed.getY() == pLoc.getBlockY() - 1 &&
            placed.getZ() == pLoc.getBlockZ()) {

            data.scaffoldPlacements.add(now);
            data.scaffoldPlacements.removeIf(t -> now - t > 1000);

            if (data.scaffoldPlacements.size() > 8) {
                // More than 8 below-feet placements per second
                int vl = flag(p, CheckType.SCAFFOLD,
                        "Scaffold rate: " + data.scaffoldPlacements.size() + "/s");
                if (vl >= 5 && !silentMode) event.setCancelled(true);
            }

            // Check: is the player looking down more than -70°? Legitimate scaffold requires this
            if (p.getEyeLocation().getPitch() < -70) {
                // Very steep downward look while scaffolding = suspicious
                flag(p, CheckType.SCAFFOLD, "Suspicious pitch during scaffold: " +
                        String.format("%.1f", p.getEyeLocation().getPitch()) + "°");
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  VIOLATION SYSTEM
    // ══════════════════════════════════════════════════════════════════════════

    private int flag(Player p, CheckType type, String detail) {
        Map<CheckType, Violation> playerViolations =
                violations.computeIfAbsent(p.getUniqueId(), k -> new ConcurrentHashMap<>());
        Violation v = playerViolations.computeIfAbsent(type, k -> new Violation());
        v.level.incrementAndGet();
        v.lastDetail = detail;
        v.lastTriggered = System.currentTimeMillis();

        int vl = v.level.get();

        // Log to structured logger
        PluginCore.get().serviceOpt(StructuredLogger.class).ifPresent(log ->
                log.warn("AntiCheat", "[" + p.getName() + "] " + type + " VL:" + vl + " — " + detail));

        // Alert staff at VL 3+
        if (vl == 3 || vl == 10 || vl == 20) {
            final int finalVl = vl;
            Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () ->
                    Bukkit.getOnlinePlayers().stream()
                            .filter(op -> op.hasPermission("aiserversetup.anticheat.alerts"))
                            .forEach(op -> op.sendMessage(net.kyori.adventure.text.minimessage
                                    .MiniMessage.miniMessage().deserialize(
                                    "<red>[AC] <white>" + p.getName() +
                                    " <gray>flagged: <yellow>" + type +
                                    " <gray>VL:<red>" + finalVl +
                                    " <dark_gray>(" + detail + ")"))));

            // Auto-punish at high VL
            if (vl >= 30) autoPunish(p, type, vl);
        }

        // Record to DB
        saveViolation(p, type, vl, detail);
        return vl;
    }

    private void autoPunish(Player p, CheckType type, int vl) {
        PluginCore.get().serviceOpt(StructuredLogger.class).ifPresent(log ->
                log.warn("AntiCheat", "Auto-punishing " + p.getName() +
                        " for " + type + " VL:" + vl));

        if (vl >= 50) {
            // Temp ban 24h
            java.util.Date expiry = java.util.Date.from(
                    java.time.Instant.now().plusSeconds(86400));
            Bukkit.getBanList(BanList.Type.PROFILE)
                    .addBan(p.getPlayerProfile(),
                            "§cAuto-banned: " + type + " (VL " + vl + ")",
                            expiry, "AntiCheat");
            p.kickPlayer("§cYou have been banned for suspected cheating.\n§7Appeal at our Discord.");
            Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(
                    "<red>[AntiCheat] <white>" + p.getName() +
                    " <gray>has been auto-banned for <red>" + type));
        } else if (vl >= 35) {
            p.kickPlayer("§c[AntiCheat] You have been kicked for suspicious behaviour.");
        }
    }

    private void decayViolations() {
        long now = System.currentTimeMillis();
        violations.forEach((uuid, checks) ->
                checks.forEach((type, viol) -> {
                    // Decay 1 VL every 10 seconds if no recent trigger
                    if (now - viol.lastTriggered > 10_000) {
                        viol.level.updateAndGet(v -> Math.max(0, v - 1));
                    }
                }));
    }

    private void alertStaff() {
        // Alert for players with multiple active high-VL checks
        violations.forEach((uuid, checks) -> {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) return;
            checks.forEach((type, v) -> {
                if (v.level.get() >= 15) {
                    Bukkit.getOnlinePlayers().stream()
                            .filter(op -> op.hasPermission("aiserversetup.anticheat.alerts"))
                            .forEach(op -> op.sendMessage(net.kyori.adventure.text.minimessage
                                    .MiniMessage.miniMessage().deserialize(
                                    "<gold>[AC-Alert] <white>" + p.getName() +
                                    " <yellow>" + type +
                                    " VL:<red>" + v.level.get())));
                }
            });
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Get all violations for a player. */
    public Map<CheckType, Violation> getViolations(Player p) {
        return Collections.unmodifiableMap(
                violations.getOrDefault(p.getUniqueId(), Collections.emptyMap()));
    }

    /** Get total violation score for a player. */
    public int getTotalVL(Player p) {
        return violations.getOrDefault(p.getUniqueId(), Collections.emptyMap())
                .values().stream().mapToInt(v -> v.level.get()).sum();
    }

    /** Reset all violations for a player. */
    public void clearViolations(Player p) {
        violations.remove(p.getUniqueId());
    }

    /** Exempt a player from all checks for N seconds. */
    public void exempt(Player p, int seconds) {
        PlayerCheckData data = getOrCreate(p);
        data.exemptUntil = System.currentTimeMillis() + (seconds * 1000L);
    }

    private boolean isCheckable(Player p) {
        if (p.hasPermission("aiserversetup.anticheat.bypass")) return false;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return false;
        PlayerCheckData data = playerData.get(p.getUniqueId());
        if (data != null && System.currentTimeMillis() < data.exemptUntil) return false;
        return true;
    }

    private PlayerCheckData getOrCreate(Player p) {
        return playerData.computeIfAbsent(p.getUniqueId(), k -> new PlayerCheckData());
    }

    private void snapBack(Player p, Location loc) {
        Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(),
                () -> p.teleport(loc));
    }

    private double getMaxLegitSpeed(Player p) {
        double base = 0.2873; // Default walk speed
        int speed   = getPotionLevel(p, org.bukkit.potion.PotionEffectType.SPEED);
        int slow    = getPotionLevel(p, org.bukkit.potion.PotionEffectType.SLOWNESS);
        double factor = 1.0 + (speed * 0.2) - (slow * 0.15);
        double max  = base * factor * 1.5; // 1.5× tolerance
        // Sprinting adds ~30%
        if (p.isSprinting()) max *= 1.3;
        // Soul sand, honey, etc. reduce speed — hard to check perfectly so we add tolerance
        return Math.max(0.1, max);
    }

    private int getPotionLevel(Player p, org.bukkit.potion.PotionEffectType type) {
        org.bukkit.potion.PotionEffect eff = p.getPotionEffect(type);
        return eff == null ? 0 : eff.getAmplifier() + 1;
    }

    private boolean hasLevitation(Player p) {
        return p.hasPotionEffect(org.bukkit.potion.PotionEffectType.LEVITATION);
    }

    private boolean hasWaterWalking(Player p) {
        // Depth strider or frost walker indirectly — we just check if they're sprinting on water
        return p.hasPotionEffect(org.bukkit.potion.PotionEffectType.SLOW_FALLING);
    }

    private boolean isNearClimbable(Player p) {
        Location loc = p.getLocation();
        for (int y = 0; y <= 1; y++) {
            Material m = loc.clone().add(0, y, 0).getBlock().getType();
            if (m == Material.LADDER || m == Material.VINE || m == Material.SCAFFOLDING ||
                m == Material.TWISTING_VINES || m == Material.WEEPING_VINES) return true;
        }
        return false;
    }

    private double horizontal(double dx, double dz) {
        return Math.sqrt(dx * dx + dz * dz);
    }

    private void saveViolation(Player p, CheckType type, int vl, String detail) {
        PluginCore.get().serviceOpt(com.example.aiserversetup.database.DatabaseService.class)
                .ifPresent(db -> db.update(
                        "INSERT INTO ac_violations(uuid,name,check_type,vl,detail,timestamp) VALUES(?,?,?,?,?,?)",
                        ps -> {
                            ps.setString(1, p.getUniqueId().toString());
                            ps.setString(2, p.getName());
                            ps.setString(3, type.name());
                            ps.setInt(4,    vl);
                            ps.setString(5, detail);
                            ps.setLong(6,   System.currentTimeMillis() / 1000);
                        })
                .exceptionally(ex -> { return 0; }));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        playerData.put(e.getPlayer().getUniqueId(), new PlayerCheckData());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        playerData.remove(e.getPlayer().getUniqueId());
    }

    // ── Data classes ──────────────────────────────────────────────────────────

    /** Mutable runtime state per player. */
    static class PlayerCheckData {
        Location lastLocation;
        int      airTicks       = 0;
        long     exemptUntil    = 0L;
        Vector   expectedVelocity;
        long     velocitySetAt  = 0L;
        Location locationBeforeVelocity;
        final List<Long> clickTimes          = new ArrayList<>();
        final List<Long> scaffoldPlacements  = new ArrayList<>();
    }

    /** A single check's violation record. */
    public static class Violation {
        public final AtomicInteger level      = new AtomicInteger(0);
        public       String        lastDetail = "";
        public       long          lastTriggered = 0L;
    }
}