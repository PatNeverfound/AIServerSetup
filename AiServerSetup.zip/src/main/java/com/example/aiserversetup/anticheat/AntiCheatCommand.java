package com.example.aiserversetup.anticheat;

import com.example.aiserversetup.core.PluginCore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * /anticheat — staff command for AntiCheat management.
 *
 * Subcommands:
 *   /ac inspect <player>   — show violation breakdown
 *   /ac clear <player>     — reset all violations
 *   /ac exempt <player> <seconds> — temp exempt a player
 *   /ac status             — show all flagged players
 *   /ac ban <player>       — manually ban for cheating
 */
public class AntiCheatCommand implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("aiserversetup.anticheat.manage")) {
            sender.sendMessage(MM.deserialize("<red>No permission."));
            return true;
        }
        AntiCheatEngine ac = PluginCore.get().serviceOpt(AntiCheatEngine.class).orElse(null);
        if (ac == null) { sender.sendMessage(MM.deserialize("<red>AntiCheat not loaded.")); return true; }

        if (args.length == 0) { sendHelp(sender); return true; }

        return switch (args[0].toLowerCase()) {
            case "inspect" -> {
                if (args.length < 2) { sender.sendMessage(MM.deserialize("<red>Usage: /ac inspect <player>")); yield true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(MM.deserialize("<red>Player not online.")); yield true; }
                inspectPlayer(sender, target, ac);
                yield true;
            }
            case "clear" -> {
                if (args.length < 2) { sender.sendMessage(MM.deserialize("<red>Usage: /ac clear <player>")); yield true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(MM.deserialize("<red>Player not online.")); yield true; }
                ac.clearViolations(target);
                sender.sendMessage(MM.deserialize("<green>Cleared violations for <white>" + target.getName()));
                yield true;
            }
            case "exempt" -> {
                if (args.length < 3) { sender.sendMessage(MM.deserialize("<red>Usage: /ac exempt <player> <seconds>")); yield true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(MM.deserialize("<red>Player not online.")); yield true; }
                try {
                    int secs = Integer.parseInt(args[2]);
                    ac.exempt(target, secs);
                    sender.sendMessage(MM.deserialize("<green>Exempted <white>" + target.getName() +
                            " <green>for <yellow>" + secs + "s"));
                } catch (NumberFormatException e) {
                    sender.sendMessage(MM.deserialize("<red>Invalid number: " + args[2]));
                }
                yield true;
            }
            case "status" -> {
                showStatus(sender, ac);
                yield true;
            }
            case "ban" -> {
                if (args.length < 2) { sender.sendMessage(MM.deserialize("<red>Usage: /ac ban <player>")); yield true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { sender.sendMessage(MM.deserialize("<red>Player not online.")); yield true; }
                Bukkit.getBanList(BanList.Type.PROFILE).addBan(
                        target.getPlayerProfile(), "§cManual AC ban by " + sender.getName(), null, "AntiCheat");
                target.kickPlayer("§cYou have been banned for cheating.\n§7Appeal at our Discord.");
                Bukkit.broadcast(MM.deserialize("<red>[AntiCheat] <white>" + target.getName() +
                        " <gray>was manually banned by <white>" + sender.getName()));
                yield true;
            }
            default -> { sendHelp(sender); yield true; }
        };
    }

    private void inspectPlayer(CommandSender sender, Player target, AntiCheatEngine ac) {
        sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        sender.sendMessage(MM.deserialize("<red>⚔ AntiCheat: <white>" + target.getName()));
        sender.sendMessage(MM.deserialize("<gray>Total VL: <yellow>" + ac.getTotalVL(target)));
        sender.sendMessage(MM.deserialize(""));
        var violations = ac.getViolations(target);
        if (violations.isEmpty()) {
            sender.sendMessage(MM.deserialize("<green>No active violations."));
        } else {
            violations.forEach((type, v) -> {
                if (v.level.get() > 0) {
                    sender.sendMessage(MM.deserialize(
                            "<yellow>" + type.displayName + ": <red>VL " + v.level.get() +
                            " <dark_gray>— " + v.lastDetail));
                }
            });
        }
        sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    private void showStatus(CommandSender sender, AntiCheatEngine ac) {
        sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬���▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        sender.sendMessage(MM.deserialize("<red>⚔ AntiCheat Status"));
        List<Player> flagged = Bukkit.getOnlinePlayers().stream()
                .filter(p -> ac.getTotalVL(p) > 0)
                .sorted(Comparator.comparingInt(p -> -ac.getTotalVL((Player) p)))
                .limit(15)
                .collect(Collectors.toList());
        if (flagged.isEmpty()) {
            sender.sendMessage(MM.deserialize("<green>No flagged players."));
        } else {
            for (Player p : flagged) {
                sender.sendMessage(MM.deserialize(
                        "<white>" + p.getName() + " <gray>— Total VL: <yellow>" + ac.getTotalVL(p)));
            }
        }
        sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        sender.sendMessage(MM.deserialize("<red>⚔ AntiCheat Commands:"));
        sender.sendMessage(MM.deserialize("  <yellow>/ac inspect <player> <gray>— View violations"));
        sender.sendMessage(MM.deserialize("  <yellow>/ac clear <player> <gray>— Reset violations"));
        sender.sendMessage(MM.deserialize("  <yellow>/ac exempt <player> <s> <gray>— Temp exempt"));
        sender.sendMessage(MM.deserialize("  <yellow>/ac status <gray>— Show all flagged players"));
        sender.sendMessage(MM.deserialize("  <yellow>/ac ban <player> <gray>— Manual AC ban"));
        sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1)
            return List.of("inspect", "clear", "exempt", "status", "ban").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase())).toList();
        if (args.length == 2 && !args[0].equalsIgnoreCase("status"))
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .toList();
        return List.of();
    }
}