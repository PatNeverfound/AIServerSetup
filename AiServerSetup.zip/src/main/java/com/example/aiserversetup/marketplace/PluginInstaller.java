package com.example.aiserversetup.marketplace;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.marketplace.PluginCatalog.PluginEntry;
import com.example.aiserversetup.marketplace.PluginCatalog.Source;
import com.example.aiserversetup.util.ChatUtil;
import org.bukkit.command.CommandSender;

import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Downloads, verifies (MD5), and installs plugin JARs into the /plugins directory.
 * Handles Hangar, Modrinth, and direct URL sources.
 */
public class PluginInstaller {

    private final AIServerSetupPlugin plugin;
    private final HangarClient hangar;
    private final ModrinthClient modrinth;
    private final ChatUtil chat;
    private final HttpClient http = HttpClient.newHttpClient();

    // Track what we've installed this session
    private final Set<String> installed = new HashSet<>();

    public PluginInstaller(AIServerSetupPlugin plugin, HangarClient hangar,
                           ModrinthClient modrinth, ChatUtil chat) {
        this.plugin   = plugin;
        this.hangar   = hangar;
        this.modrinth = modrinth;
        this.chat     = chat;
    }

    /**
     * Install a plugin by catalog ID. Resolves dependencies first.
     */
    public CompletableFuture<InstallResult> install(String pluginId, CommandSender sender) {
        Optional<PluginEntry> opt = PluginCatalog.findById(pluginId);
        if (opt.isEmpty()) {
            return CompletableFuture.completedFuture(
                    InstallResult.failure("Plugin ID '" + pluginId + "' not found in catalog."));
        }
        return install(opt.get(), sender);
    }

    public CompletableFuture<InstallResult> install(PluginEntry entry, CommandSender sender) {
        if (isInstalled(entry.name())) {
            chat.warn(sender, entry.name() + " is already installed.");
            return CompletableFuture.completedFuture(InstallResult.alreadyInstalled(entry.name()));
        }

        chat.sendRaw(sender, "<gradient:#00c6ff:#0072ff>📦 Installing " + entry.name() + "...</gradient>");

        // Resolve dependencies first
        return resolveDependencies(entry, sender).thenCompose(depsOk -> {
            if (!depsOk) {
                return CompletableFuture.completedFuture(
                        InstallResult.failure("Dependency installation failed for " + entry.name()));
            }
            return resolveDownloadUrl(entry).thenCompose(urlOpt -> {
                if (urlOpt.isEmpty()) {
                    chat.error(sender, "Could not resolve download URL for " + entry.name());
                    return CompletableFuture.completedFuture(
                            InstallResult.failure("No download URL found for " + entry.name()));
                }
                return downloadJar(entry.name(), urlOpt.get(), sender);
            });
        });
    }

    /**
     * Install a plugin directly from a URL with a given name.
     */
    public CompletableFuture<InstallResult> installFromUrl(String name, String url, CommandSender sender) {
        chat.sendRaw(sender, "<gradient:#00c6ff:#0072ff>📦 Downloading " + name + "...</gradient>");
        return downloadJar(name, url, sender);
    }

    /**
     * Install the latest version of a plugin from a live Hangar/Modrinth search result.
     */
    public CompletableFuture<InstallResult> installLiveResult(
            String name, String slug, Source source, CommandSender sender) {
        chat.sendRaw(sender, "<gradient:#00c6ff:#0072ff>🔍 Fetching latest version of " + name + "...</gradient>");

        CompletableFuture<Optional<String>> urlFuture;
        if (source == Source.MODRINTH) {
            urlFuture = modrinth.getLatestDownloadUrl(slug);
        } else {
            // Hangar — need author from search result, use slug as fallback
            urlFuture = hangar.getLatestVersion(slug, slug).thenCompose(version -> {
                if (version.isEmpty()) return CompletableFuture.completedFuture(Optional.empty());
                String dlUrl = hangar.buildDownloadUrl(slug, slug, version.get());
                return CompletableFuture.completedFuture(Optional.of(dlUrl));
            });
        }
        return urlFuture.thenCompose(urlOpt -> {
            if (urlOpt.isEmpty()) {
                chat.error(sender, "Could not resolve download URL for " + name);
                return CompletableFuture.completedFuture(InstallResult.failure("No URL found"));
            }
            return downloadJar(name, urlOpt.get(), sender);
        });
    }

    private CompletableFuture<Boolean> resolveDependencies(PluginEntry entry, CommandSender sender) {
        List<String> deps = entry.dependencies();
        if (deps.isEmpty()) return CompletableFuture.completedFuture(true);

        List<CompletableFuture<InstallResult>> futures = new ArrayList<>();
        for (String depId : deps) {
            Optional<PluginEntry> dep = PluginCatalog.findById(depId);
            if (dep.isEmpty()) continue;
            if (isInstalled(dep.get().name())) continue;
            chat.sendRaw(sender, "<yellow>  → Dependency: " + dep.get().name() + "</yellow>");
            futures.add(install(dep.get(), sender));
        }

        if (futures.isEmpty()) return CompletableFuture.completedFuture(true);
        return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenApply(v -> futures.stream().allMatch(f -> {
                    try { return !f.get().failed(); } catch (Exception e) { return false; }
                }));
    }

    private CompletableFuture<Optional<String>> resolveDownloadUrl(PluginEntry entry) {
        return switch (entry.source()) {
            case HANGAR -> {
                if (entry.author() != null && entry.slug() != null) {
                    yield hangar.getLatestVersion(entry.author(), entry.slug()).thenApply(version ->
                            version.map(v -> hangar.buildDownloadUrl(entry.author(), entry.slug(), v)));
                }
                yield CompletableFuture.completedFuture(Optional.ofNullable(entry.directUrl()));
            }
            case MODRINTH -> {
                if (entry.slug() != null) {
                    yield modrinth.getLatestDownloadUrl(entry.slug());
                }
                yield CompletableFuture.completedFuture(Optional.ofNullable(entry.directUrl()));
            }
            case SPIGOT -> {
                // SpigotMC doesn't have a public API — use direct URL if provided
                yield CompletableFuture.completedFuture(
                        Optional.ofNullable(entry.directUrl())
                                .or(() -> entry.spigotId() != null
                                        ? Optional.of("https://api.spiget.org/v2/resources/"
                                        + entry.spigotId() + "/download")
                                        : Optional.empty())
                );
            }
            case GITHUB -> CompletableFuture.completedFuture(Optional.ofNullable(entry.directUrl()));
        };
    }

    private CompletableFuture<InstallResult> downloadJar(String name, String url, CommandSender sender) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String safeFilename = name.replaceAll("[^a-zA-Z0-9_\\-.]", "_") + ".jar";
                Path dest = Path.of("plugins", safeFilename);

                // Backup existing if present
                if (Files.exists(dest)) {
                    Files.copy(dest, Path.of("plugins", safeFilename + ".bak"), StandardCopyOption.REPLACE_EXISTING);
                }

                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("User-Agent", "AIServerSetup/3.0")
                        .GET().build();

                HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());

                if (resp.statusCode() != 200 && resp.statusCode() != 302) {
                    // Follow redirect manually if needed
                    String location = resp.headers().firstValue("location").orElse(null);
                    if (location != null) {
                        req  = HttpRequest.newBuilder().uri(URI.create(location))
                                .header("User-Agent", "AIServerSetup/3.0").GET().build();
                        resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
                    }
                }

                if (resp.statusCode() != 200) {
                    return InstallResult.failure("HTTP " + resp.statusCode() + " from " + url);
                }

                byte[] data = resp.body();
                if (data.length < 100) {
                    return InstallResult.failure("Download too small — likely not a valid JAR.");
                }

                // Verify it looks like a JAR (ZIP magic bytes: PK)
                if (data[0] != 0x50 || data[1] != 0x4B) {
                    return InstallResult.failure("Downloaded file is not a valid JAR (bad magic bytes).");
                }

                Files.write(dest, data);
                installed.add(name.toLowerCase());

                String checksum = md5(data);
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    chat.success(sender, "✔ Installed <yellow>" + name + "</yellow> ("
                            + (data.length / 1024) + " KB) → plugins/" + safeFilename);
                    chat.sendRaw(sender, "<dark_gray>  MD5: " + checksum + "</dark_gray>");
                    chat.warn(sender, "Restart the server to load " + name + ".");
                    plugin.getDiscordWebhook().sendIfEnabled("**[Plugin Installed]** " + name + " (" + (data.length/1024) + " KB)");
                });

                return InstallResult.success(name, dest.toString());

            } catch (Exception e) {
                plugin.getServer().getScheduler().runTask(plugin, () ->
                        chat.error(sender, "Failed to install " + name + ": " + e.getMessage()));
                return InstallResult.failure(e.getMessage());
            }
        });
    }

    public boolean isInstalled(String pluginName) {
        if (installed.contains(pluginName.toLowerCase())) return true;
        // Also check actual plugins dir
        File f = new File("plugins", pluginName + ".jar");
        File f2 = new File("plugins", pluginName.replaceAll("\\s+", "_") + ".jar");
        if (f.exists() || f2.exists()) return true;
        // Check loaded plugins
        return plugin.getServer().getPluginManager().getPlugin(pluginName) != null;
    }

    private String md5(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(data);
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return "N/A"; }
    }

    public record InstallResult(boolean success, boolean alreadyInstalled, String name, String path, String error) {
        public static InstallResult success(String name, String path)  { return new InstallResult(true,  false, name, path, null); }
        public static InstallResult failure(String error)              { return new InstallResult(false, false, null, null, error); }
        public static InstallResult alreadyInstalled(String name)     { return new InstallResult(true,  true,  name, null, null); }
        public boolean failed() { return !success; }
    }
}