package com.example.aiserversetup.marketplace;

import com.example.aiserversetup.util.ChatUtil;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.zip.*;

/**
 * Backs up all plugin JARs and configs to a zip file before updates or changes.
 */
public class PluginBackup {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
    private final JavaPlugin plugin;
    private final ChatUtil chat;
    private final File backupDir;

    public PluginBackup(JavaPlugin plugin, ChatUtil chat) {
        this.plugin    = plugin;
        this.chat      = chat;
        this.backupDir = new File(plugin.getDataFolder(), "backups");
        backupDir.mkdirs();
    }

    /** Create a full backup of /plugins (JARs + configs). */
    public File backupAll(CommandSender sender) throws IOException {
        String timestamp = LocalDateTime.now().format(FMT);
        File zipFile = new File(backupDir, "plugins-backup-" + timestamp + ".zip");
        chat.sendRaw(sender, "<yellow>⏳ Creating plugin backup...</yellow>");

        Path pluginsDir = Path.of("plugins");
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            Files.walkFileTree(pluginsDir, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    // Skip our own backups folder
                    if (file.toString().contains("AIServerSetup" + File.separator + "backups")) return FileVisitResult.CONTINUE;
                    ZipEntry entry = new ZipEntry(pluginsDir.relativize(file).toString());
                    zos.putNextEntry(entry);
                    Files.copy(file, zos);
                    zos.closeEntry();
                    return FileVisitResult.CONTINUE;
                }
            });
        }

        long sizeMB = zipFile.length() / 1024 / 1024;
        chat.success(sender, "✔ Backup created: <aqua>" + zipFile.getName() + "</aqua> (" + sizeMB + " MB)");
        return zipFile;
    }

    /** Backup only plugin JARs (faster). */
    public File backupJars(CommandSender sender) throws IOException {
        String timestamp = LocalDateTime.now().format(FMT);
        File zipFile = new File(backupDir, "jars-backup-" + timestamp + ".zip");

        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            File pluginsDir = new File("plugins");
            File[] jars = pluginsDir.listFiles((d, n) -> n.endsWith(".jar"));
            if (jars != null) {
                for (File jar : jars) {
                    zos.putNextEntry(new ZipEntry(jar.getName()));
                    Files.copy(jar.toPath(), zos);
                    zos.closeEntry();
                }
            }
        }

        chat.success(sender, "✔ JAR backup: <aqua>" + zipFile.getName() + "</aqua>");
        return zipFile;
    }

    public File[] listBackups() {
        File[] files = backupDir.listFiles((d, n) -> n.endsWith(".zip"));
        return files != null ? files : new File[0];
    }
}