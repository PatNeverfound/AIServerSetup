package com.example.aiserversetup.marketplace;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.util.ChatUtil;

/** Central holder for all marketplace components. */
public class MarketplaceManager {

    private final HangarClient hangar;
    private final ModrinthClient modrinth;
    private final PluginInstaller installer;
    private final PluginUpdater updater;
    private final PluginBackup backup;
    private final DependencyResolver resolver;
    private final MarketplaceGUI gui;

    public MarketplaceManager(AIServerSetupPlugin plugin, ChatUtil chat) {
        this.hangar    = new HangarClient();
        this.modrinth  = new ModrinthClient();
        this.installer = new PluginInstaller(plugin, hangar, modrinth, chat);
        this.updater   = new PluginUpdater(plugin, hangar, modrinth, installer, chat);
        this.backup    = new PluginBackup(plugin, chat);
        this.resolver  = new DependencyResolver(plugin, chat);
        this.gui       = new MarketplaceGUI(plugin);
    }

    public HangarClient       getHangar()    { return hangar; }
    public ModrinthClient     getModrinth()  { return modrinth; }
    public PluginInstaller    getInstaller() { return installer; }
    public PluginUpdater      getUpdater()   { return updater; }
    public PluginBackup       getBackup()    { return backup; }
    public DependencyResolver getResolver()  { return resolver; }
    public MarketplaceGUI     getGui()       { return gui; }
}