package com.example.aiserversetup.marketplace;

import com.google.gson.*;

import java.net.URI;
import java.net.http.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Client for the Hangar PaperMC plugin repository API.
 * Docs: https://hangar.papermc.io/api-docs
 */
public class HangarClient {

    private static final String BASE = "https://hangar.papermc.io/api/v1";
    private final HttpClient http = HttpClient.newHttpClient();
    private final Gson gson = new Gson();

    /** Get the latest version string for a project. */
    public CompletableFuture<Optional<String>> getLatestVersion(String author, String slug) {
        String url = BASE + "/projects/" + author + "/" + slug + "/latestrelease";
        return get(url).thenApply(body -> {
            if (body == null) return Optional.empty();
            // Response is a plain version string
            return Optional.of(body.trim().replace("\"", ""));
        });
    }

    /** Build the download URL for a specific version on Hangar. */
    public String buildDownloadUrl(String author, String slug, String version) {
        return BASE + "/projects/" + author + "/" + slug
                + "/versions/" + version + "/PAPER/download";
    }

    /** Search Hangar for plugins matching a query. Returns list of {name, description, author, slug}. */
    public CompletableFuture<List<Map<String, String>>> search(String query, int limit) {
        String url = BASE + "/projects?q=" + encode(query) + "&limit=" + limit + "&platform=PAPER";
        return get(url).thenApply(body -> {
            List<Map<String, String>> results = new ArrayList<>();
            if (body == null) return results;
            try {
                JsonObject json = JsonParser.parseString(body).getAsJsonObject();
                JsonArray arr = json.getAsJsonArray("result");
                for (JsonElement el : arr) {
                    JsonObject p = el.getAsJsonObject();
                    Map<String, String> m = new LinkedHashMap<>();
                    m.put("name",        p.get("name").getAsString());
                    m.put("description", p.has("description") ? p.get("description").getAsString() : "");
                    m.put("author",      p.has("namespace") ? p.getAsJsonObject("namespace").get("owner").getAsString() : "");
                    m.put("slug",        p.has("namespace") ? p.getAsJsonObject("namespace").get("slug").getAsString() : "");
                    results.add(m);
                }
            } catch (Exception ignored) {}
            return results;
        });
    }

    private CompletableFuture<String> get(String url) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Accept", "application/json")
                        .GET().build();
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
                return resp.statusCode() == 200 ? resp.body() : null;
            } catch (Exception e) { return null; }
        });
    }

    private String encode(String s) {
        return s.replace(" ", "%20");
    }
}