package com.example.aiserversetup.marketplace;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.marketplace.PluginCatalog.PluginEntry;
import com.example.aiserversetup.marketplace.PluginCatalog.Source;
import com.example.aiserversetup.util.ChatUtil;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Checks installed plugins against catalog and fetches latest versions.
 */
public class PluginUpdater {

    private final AIServerSetupPlugin plugin;
    private final HangarClient hangar;
    private final ModrinthClient modrinth;
    private final PluginInstaller installer;
    private final ChatUtil chat;

    public PluginUpdater(AIServerSetupPlugin p, HangarClient h, ModrinthClient m,
                         PluginInstaller inst, ChatUtil chat) {
        this.plugin = p; this.hangar = h; this.modrinth = m; this.installer = inst; this.chat = chat;
    }

    /** Check all installed plugins for available updates. */
    public CompletableFuture<List<UpdateInfo>> checkAll(CommandSender sender) {
        chat.header(sender, "Checking for Plugin Updates");
        Plugin[] loaded = plugin.getServer().getPluginManager().getPlugins();
        List<CompletableFuture<Optional<UpdateInfo>>> futures = new ArrayList<>();

        for (Plugin p : loaded) {
            Optional<PluginEntry> entry = PluginCatalog.findByName(p.getName());
            if (entry.isEmpty()) continue;
            String currentVer = p.getDescription().getVersion();
            futures.add(checkPlugin(entry.get(), currentVer));
        }

        return CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).thenApply(v -> {
            List<UpdateInfo> updates = new ArrayList<>();
            for (var f : futures) {
                try { f.get().ifPresent(updates::add); } catch (Exception ignored) {}
            }
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                if (updates.isEmpty()) {
                    chat.success(sender, "All plugins are up to date!");
                } else {
                    chat.sendRaw(sender, "<yellow>" + updates.size() + " update(s) available:</yellow>");
                    updates.forEach(u -> chat.sendRaw(sender,
                            "  <aqua>" + u.name() + "</aqua> "
                            + "<gray>" + u.currentVersion() + " → </gray>"
                            + "<green>" + u.latestVersion() + "</green>"
                            + " <yellow><click:run_command:'/aiupdate install "
                            + u.name() + "'>[Update]</click></yellow>"));
                }
            });
            return updates;
        });
    }

    /** Update a single plugin by name. */
    public CompletableFuture<Boolean> updatePlugin(String name, CommandSender sender) {
        Optional<PluginEntry> opt = PluginCatalog.findByName(name);
        if (opt.isEmpty()) {
            chat.error(sender, "Plugin '" + name + "' not found in catalog.");
            return CompletableFuture.completedFuture(false);
        }
        return installer.install(opt.get(), sender).thenApply(r -> !r.failed());
    }

    private CompletableFuture<Optional<UpdateInfo>> checkPlugin(PluginEntry entry, String currentVer) {
        CompletableFuture<Optional<String>> versionFuture =
                entry.source() == Source.MODRINTH
                        ? modrinth.getLatestVersionString(entry.slug())
                        : entry.source() == Source.HANGAR
                            ? hangar.getLatestVersion(entry.author(), entry.slug())
                            : CompletableFuture.completedFuture(Optional.empty());

        return versionFuture.thenApply(latest -> latest
                .filter(v -> !v.equals(currentVer))
                .map(v -> new UpdateInfo(entry.name(), currentVer, v, entry)));
    }

    public record UpdateInfo(String name, String currentVersion, String latestVersion, PluginEntry entry) {}
}