package com.example.aiserversetup.marketplace;

import java.util.*;

/**
 * Master catalog of 100+ well-known Minecraft plugins with metadata,
 * download sources, categories, and dependency information.
 */
public class PluginCatalog {

    public enum Category {
        ADMIN, ANTI_CHEAT, CHAT, ECONOMY, PROTECTION, WORLD, FUN,
        PERFORMANCE, CROSS_PLATFORM, UTILITIES, MINIGAME, RPGG,
        LOGGING, PERMISSIONS, MAPS, NPCS, HOLOGRAMS, SHOP, COSMETICS, MISC
    }

    public enum Source { HANGAR, MODRINTH, SPIGOT, GITHUB }

    public record PluginEntry(
            String id,           // unique internal id
            String name,         // display name
            String description,  // short description
            Category category,
            Source   source,
            String   slug,       // slug for Hangar/Modrinth API
            String   author,     // for Hangar: namespace
            String   spigotId,   // SpigotMC resource ID (if applicable)
            String   directUrl,  // fallback direct download URL
            List<String> dependencies, // list of plugin IDs this requires
            String   mcVersion,  // target MC version
            boolean  free,
            String   iconMaterial // Bukkit Material name for GUI
    ) {}

    private static final List<PluginEntry> ALL = new ArrayList<>();

    static {
        // ── ADMIN ─────────────────────────────────────────────────────────────
        add("essentialsx",     "EssentialsX",        "Core server commands: homes, warps, kits, economy",           Category.ADMIN,        Source.HANGAR,   "EssentialsX",    "EssentialsX",  null, null, List.of(), "1.21", true,  "BOOK");
        add("essentialsx-chat","EssentialsX Chat",   "Chat formatting with EssentialsX groups",                     Category.CHAT,         Source.HANGAR,   "EssentialsX",    "EssentialsX",  null, null, List.of("essentialsx"), "1.21", true, "PAPER");
        add("essentialsx-spawn","EssentialsX Spawn", "Spawn control and join messages",                             Category.ADMIN,        Source.HANGAR,   "EssentialsX",    "EssentialsX",  null, null, List.of("essentialsx"), "1.21", true, "BED");
        add("luckperms",       "LuckPerms",          "Most powerful permissions plugin, web editor",                Category.PERMISSIONS,  Source.HANGAR,   "LuckPerms",      "lucko",        null, null, List.of(), "1.21", true, "NETHER_STAR");
        add("vault",           "Vault",              "Economy/permissions API bridge used by many plugins",         Category.ADMIN,        Source.SPIGOT,   null,             null,           "34315", null, List.of(), "1.21", true, "GOLD_INGOT");
        add("commandapi",      "CommandAPI",         "Advanced command framework for plugin devs",                  Category.ADMIN,        Source.MODRINTH, "commandapi",     null,           null, null, List.of(), "1.21", true, "COMMAND_BLOCK");
        add("sudo",            "Sudo",               "Run commands as other players or console",                    Category.ADMIN,        Source.HANGAR,   "Sudo",           "CyberCyclone",  null, null, List.of(), "1.21", true, "STICK");
        add("staffplus",       "StaffPlus",          "Staff management: vanish, freeze, report system",            Category.ADMIN,        Source.SPIGOT,   null,             null,           "41500", null, List.of(), "1.21", true, "IRON_SWORD");

        // ── PERMISSIONS ───────────────────────────────────────────────────────
        add("ultraperms",      "UltraPermissions",   "GUI-based permissions manager",                              Category.PERMISSIONS,  Source.SPIGOT,   null,             null,           "42678", null, List.of(), "1.21", false, "ENCHANTED_BOOK");
        add("groupmanager",    "GroupManager",       "Classic group-based permissions",                             Category.PERMISSIONS,  Source.SPIGOT,   null,             null,           "38875", null, List.of(), "1.21", true,  "BOOK");

        // ── CHAT ──────────────────────────────────────────────────────────────
        add("chatcontrol",     "ChatControl Red",    "Ultimate chat management: filter, format, announce",          Category.CHAT,         Source.SPIGOT,   null,             null,           "271", null, List.of(), "1.21", false, "PAPER");
        add("discordsrv",      "DiscordSRV",         "Link Minecraft chat ↔ Discord channels",                    Category.CHAT,         Source.HANGAR,   "DiscordSRV",     "Scarsz",        null, null, List.of(), "1.21", true, "MUSIC_DISC_11");
        add("venturechat",     "VentureChat",        "Channels, private messages, bungee chat",                    Category.CHAT,         Source.SPIGOT,   null,             null,           "771", null, List.of(), "1.21", true, "WRITABLE_BOOK");
        add("chatgames",       "ChatGames",          "Trivia, math, unscramble games in chat",                     Category.CHAT,         Source.HANGAR,   "ChatGames",      "hyperdefined",  null, null, List.of(), "1.21", true, "PAPER");
        add("headdatabase",    "HeadDatabase",       "Access to 40,000+ custom player heads",                      Category.MISC,         Source.SPIGOT,   null,             null,           "14280", null, List.of(), "1.21", false, "PLAYER_HEAD");

        // ── ECONOMY ───────────────────────────────────────────────────────────
        add("economyx",        "EconomyX",           "Simple Vault-compatible economy",                             Category.ECONOMY,      Source.SPIGOT,   null,             null,           "43657", null, List.of("vault"), "1.21", true, "GOLD_NUGGET");
        add("shopguiplus",     "ShopGUI+",           "Feature-rich shop GUI with item buy/sell",                   Category.SHOP,         Source.SPIGOT,   null,             null,           "6515", null, List.of("vault"), "1.21", false, "EMERALD");
        add("playershops",     "PlayerShops",        "Player-run chest shops",                                     Category.SHOP,         Source.SPIGOT,   null,             null,           "1048", null, List.of("vault"), "1.21", true, "CHEST");
        add("quickshop",       "QuickShop Hikari",   "Chest shop plugin, easy to use",                             Category.SHOP,         Source.HANGAR,   "QuickShop-Hikari","PotatoCraft",  null, null, List.of("vault"), "1.21", true, "CHEST");
        add("tokenmanager",    "TokenManager",       "Token-based secondary currency",                             Category.ECONOMY,      Source.SPIGOT,   null,             null,           "38866", null, List.of(), "1.21", true, "SUNFLOWER");
        add("gemseconomy",     "GemsEconomy",        "Multiple currency economy",                                   Category.ECONOMY,      Source.HANGAR,   "GemsEconomy",    "CryptoMorin",  null, null, List.of(), "1.21", true, "EMERALD");

        // ── PROTECTION ────────────────────────────────────────────────────────
        add("worldguard",      "WorldGuard",         "Region protection, flags, blacklists",                        Category.PROTECTION,   Source.MODRINTH, "worldguard",     null,           null, null, List.of("worldedit"), "1.21", true, "OAK_FENCE");
        add("worldedit",       "WorldEdit",          "Powerful in-game world editing toolkit",                      Category.WORLD,        Source.MODRINTH, "worldedit",      null,           null, null, List.of(), "1.21", true, "WOODEN_AXE");
        add("coreprotect",     "CoreProtect",        "Block logging and grief rollback",                            Category.LOGGING,      Source.HANGAR,   "CoreProtect",    "Intelli",      null, null, List.of(), "1.21", true, "CLOCK");
        add("grief-prevention","GriefPrevention",    "Automatic land claiming system",                              Category.PROTECTION,   Source.HANGAR,   "GriefPrevention","TechFortress",  null, null, List.of(), "1.21", true, "GOLDEN_SHOVEL");
        add("bentobox",        "BentoBox",           "Skyblock, OneBlock, and island game frameworks",             Category.WORLD,        Source.HANGAR,   "BentoBox",       "BentoBoxWorld",null, null, List.of(), "1.21", true, "GRASS_BLOCK");
        add("factions",        "Factions",           "Faction wars, territory claiming, alliances",                 Category.PROTECTION,   Source.SPIGOT,   null,             null,           "1900", null, List.of("vault"), "1.21", false, "RED_BANNER");
        add("residence",       "Residence",          "Advanced land claiming with rent/buy",                        Category.PROTECTION,   Source.SPIGOT,   null,             null,           "11480", null, List.of(), "1.21", false, "OAK_DOOR");
        add("plotsquared",     "PlotSquared",        "Plot management for creative servers",                        Category.PROTECTION,   Source.HANGAR,   "PlotSquared",    "IntellectualSites", null, null, List.of(), "1.21", true, "GRASS_BLOCK");
        add("lands",           "Lands",              "Modern land claiming with GUI",                               Category.PROTECTION,   Source.SPIGOT,   null,             null,           "53313", null, List.of(), "1.21", false, "MAP");

        // ── ANTI-CHEAT ────────────────────────────────────────────────────────
        add("matrix",          "Matrix AntiCheat",   "Highly accurate anti-cheat with async checks",               Category.ANTI_CHEAT,   Source.SPIGOT,   null,             null,           "82702", null, List.of(), "1.21", false, "BARRIER");
        add("vulcan",          "Vulcan",             "Advanced anti-cheat with checks for all hacks",              Category.ANTI_CHEAT,   Source.SPIGOT,   null,             null,           "83626", null, List.of(), "1.21", false, "BARRIER");
        add("nocheatplus",     "NoCheatPlus",        "Free, classic anti-cheat plugin",                            Category.ANTI_CHEAT,   Source.MODRINTH, "nocheatplus",    null,           null, null, List.of(), "1.21", true, "BARRIER");
        add("grim",            "Grim AntiCheat",     "Modern open-source anti-cheat",                              Category.ANTI_CHEAT,   Source.HANGAR,   "GrimAC",         "MWHunter3",    null, null, List.of(), "1.21", true, "BARRIER");

        // ── PERFORMANCE ───────────────────────────────────────────────────────
        add("chunky",          "Chunky",             "Fast world pre-generation to eliminate lag",                  Category.PERFORMANCE,  Source.HANGAR,   "Chunky",         "pop4959",      null, null, List.of(), "1.21", true, "GRASS_BLOCK");
        add("spark",           "Spark",              "Performance profiler — find lag sources",                     Category.PERFORMANCE,  Source.HANGAR,   "spark",          "lucko",        null, null, List.of(), "1.21", true, "BLAZE_ROD");
        add("clearlag",        "ClearLag",           "Remove entities, optimize mob counts",                        Category.PERFORMANCE,  Source.SPIGOT,   null,             null,           "68271", null, List.of(), "1.21", true, "IRON_SWORD");
        add("illegalstack",    "IllegalStack",       "Fix item duplication exploits",                               Category.PERFORMANCE,  Source.MODRINTH, "illegalstack",   null,           null, null, List.of(), "1.21", true, "IRON_INGOT");
        add("fastasyncworldedit","FastAsyncWorldEdit","Async WorldEdit for massive builds without lag",            Category.PERFORMANCE,  Source.HANGAR,   "FastAsyncWorldEdit","IntellectualSites",null,null, List.of(), "1.21", true, "GOLDEN_AXE");

        // ── CROSS-PLATFORM ────────────────────────────────────────────────────
        add("geyser",          "GeyserMC",           "Allow Bedrock players to join Java servers",                  Category.CROSS_PLATFORM,Source.HANGAR,  "Geyser",         "GeyserMC",     null, null, List.of(), "1.21", true, "DIAMOND");
        add("floodgate",       "Floodgate",          "Bedrock auth bypass for GeyserMC",                           Category.CROSS_PLATFORM,Source.HANGAR,  "Floodgate",      "GeyserMC",     null, null, List.of("geyser"), "1.21", true, "DIAMOND_INGOT");
        add("viaversion",      "ViaVersion",         "Let newer clients join older servers",                        Category.CROSS_PLATFORM,Source.HANGAR,  "ViaVersion",     "ViaVersion",   null, null, List.of(), "1.21", true, "COMPARATOR");
        add("viabackwards",    "ViaBackwards",       "Let older clients join newer servers",                        Category.CROSS_PLATFORM,Source.HANGAR,  "ViaBackwards",   "ViaVersion",   null, null, List.of("viaversion"), "1.21", true, "COMPARATOR");
        add("viarewind",       "ViaRewind",          "Support for 1.7/1.8 clients",                                Category.CROSS_PLATFORM,Source.HANGAR,  "ViaRewind",      "ViaVersion",   null, null, List.of("viaversion","viabackwards"), "1.21", true, "COMPARATOR");

        // ── WORLD ─────────────────────────────────────────────────────────────
        add("multiverse",      "Multiverse-Core",    "Manage multiple worlds on one server",                        Category.WORLD,        Source.HANGAR,   "Multiverse-Core","TheDS9",       null, null, List.of(), "1.21", true, "ENDER_EYE");
        add("multiverse-portals","Multiverse-Portals","Create custom portals between worlds",                      Category.WORLD,        Source.HANGAR,   "Multiverse-Portals","TheDS9",     null, null, List.of("multiverse"), "1.21", true, "NETHER_PORTAL");
        add("terraformgenerator","TerraformGenerator","Beautiful custom world generation",                          Category.WORLD,        Source.HANGAR,   "TerraformGenerator","Anand_Yadav",null, null, List.of(), "1.21", true, "CHERRY_SAPLING");
        add("iris",            "Iris",               "Advanced procedural world generation",                        Category.WORLD,        Source.MODRINTH, "iris",           null,           null, null, List.of(), "1.21", true, "BLUE_DYE");
        add("terra",           "Terra",              "Ultra-customizable world generation",                         Category.WORLD,        Source.MODRINTH, "terra",          null,           null, null, List.of(), "1.21", true, "GREEN_DYE");
        add("dynmap",          "Dynmap",             "Real-time 2D web map of your world",                          Category.MAPS,         Source.HANGAR,   "dynmap",         "webbukkit",    null, null, List.of(), "1.21", true, "MAP");
        add("bluemap",         "BlueMap",            "Beautiful 3D web map of your world",                          Category.MAPS,         Source.HANGAR,   "BlueMap",        "TBlueF4ng",    null, null, List.of(), "1.21", true, "BLUE_WOOL");
        add("pl3xmap",         "Pl3xMap",            "Lightweight 2D tile-based web map",                           Category.MAPS,         Source.HANGAR,   "Pl3xMap",        "Pl3xGames",    null, null, List.of(), "1.21", true, "FILLED_MAP");
        add("worldborder",     "WorldBorder",        "Create circular/square world borders",                        Category.WORLD,        Source.SPIGOT,   null,             null,           "60905", null, List.of(), "1.21", true, "STONE_BRICKS");

        // ── NPCS ──────────────────────────────────────────────────────────────
        add("citizens",        "Citizens",           "The original NPC plugin with AI capabilities",                Category.NPCS,         Source.SPIGOT,   null,             null,           "13811", null, List.of(), "1.21", false, "PLAYER_HEAD");
        add("znpcsplus",       "ZNPCsPlus",          "Free NPC plugin with holograms and actions",                  Category.NPCS,         Source.HANGAR,   "ZNPCsPlus",      "gonalez",      null, null, List.of(), "1.21", true, "PLAYER_HEAD");
        add("fancynpcs",       "FancyNpcs",          "Modern lightweight NPCs with actions",                        Category.NPCS,         Source.HANGAR,   "FancyNpcs",      "Oliver",       null, null, List.of(), "1.21", true, "PLAYER_HEAD");
        add("shopkeeper",      "Shopkeepers",        "Villager-based player shops",                                  Category.SHOP,         Source.HANGAR,   "Shopkeepers",    "nisovin",      null, null, List.of(), "1.21", true, "VILLAGER_SPAWN_EGG");

        // ── HOLOGRAMS ─────────────────────────────────────────────────────────
        add("holographicdisplays","HolographicDisplays","Classic floating text plugin",                            Category.HOLOGRAMS,    Source.SPIGOT,   null,             null,           "75097", null, List.of(), "1.21", true, "CYAN_DYE");
        add("fancyholograms",  "FancyHolograms",     "Modern holograms with animations",                            Category.HOLOGRAMS,    Source.HANGAR,   "FancyHolograms", "Oliver",       null, null, List.of(), "1.21", true, "NAME_TAG");
        add("decentholograms", "DecentHolograms",    "Feature-rich hologram plugin",                                Category.HOLOGRAMS,    Source.SPIGOT,   null,             null,           "96927", null, List.of(), "1.21", true, "NAME_TAG");

        // ── LOGGING ───────────────────────────────────────────────────────────
        add("prism",           "Prism",              "Block logging, rollback, lookup",                             Category.LOGGING,      Source.HANGAR,   "Prism",          "prism-bukkit",  null, null, List.of(), "1.21", true, "AMETHYST_SHARD");
        add("logblock",        "LogBlock",           "Detailed block logging with MySQL",                           Category.LOGGING,      Source.SPIGOT,   null,             null,           "67701", null, List.of(), "1.21", true, "OAK_LOG");

        // ── FUN ───────────────────────────────────────────────────────────────
        add("skywars",         "SkyWars Reloaded",   "Classic skywars minigame",                                    Category.MINIGAME,     Source.SPIGOT,   null,             null,           "60711", null, List.of(), "1.21", true, "DIAMOND_SWORD");
        add("bedwars",         "BedWars1058",        "Bedwars minigame with arena editor",                          Category.MINIGAME,     Source.SPIGOT,   null,             null,           "50942", null, List.of(), "1.21", false, "RED_BED");
        add("murdermystery",   "MurderMystery",      "Murder mystery party game",                                   Category.MINIGAME,     Source.SPIGOT,   null,             null,           "18702", null, List.of(), "1.21", true, "WOODEN_SWORD");
        add("paintball",       "Paintball Battle",   "Paintball minigame with teams",                               Category.MINIGAME,     Source.SPIGOT,   null,             null,           "16", null, List.of(), "1.21", true, "SNOWBALL");
        add("ultimategames",   "UltimateGames",      "Multi-game framework (TDM, CTF, etc.)",                      Category.MINIGAME,     Source.SPIGOT,   null,             null,           "22", null, List.of(), "1.21", true, "DIAMOND");
        add("mmoitems",        "MMOItems",           "Custom weapons, armor, abilities",                            Category.RPGG,         Source.SPIGOT,   null,             null,           "39267", null, List.of(), "1.21", false, "GOLDEN_SWORD");
        add("mythicmobs",      "MythicMobs",         "Custom mobs, bosses, skills system",                          Category.RPGG,         Source.SPIGOT,   null,             null,           "5702", null, List.of(), "1.21", false, "WITHER_SKULL");
        add("executableitems", "ExecutableItems",    "Items with custom commands and effects",                      Category.RPGG,         Source.SPIGOT,   null,             null,           "87809", null, List.of(), "1.21", false, "COMMAND_BLOCK");
        add("aureliumskills",  "AureliumSkills",     "RPG skill system with leveling",                             Category.RPGG,         Source.HANGAR,   "AureliumSkills", "Archy",        null, null, List.of(), "1.21", true, "EXPERIENCE_BOTTLE");
        add("jobs",            "Jobs Reborn",        "Earn money from in-game jobs",                                Category.ECONOMY,      Source.SPIGOT,   null,             null,           "4216", null, List.of("vault"), "1.21", false, "IRON_PICKAXE");
        add("clans",           "Clans",              "Clan system with wars and alliances",                         Category.PROTECTION,   Source.SPIGOT,   null,             null,           "10953", null, List.of(), "1.21", false, "BANNER");

        // ── COSMETICS ─────────────────────────────────────────────────────────
        add("gadgetsmenu",     "GadgetsMenu",        "Cosmetics, trails, morphs, pets, balloons",                  Category.COSMETICS,    Source.SPIGOT,   null,             null,           "62831", null, List.of(), "1.21", false, "BLAZE_POWDER");
        add("oraxen",          "Oraxen",             "Custom items, blocks, HUDs, cosmetics",                       Category.COSMETICS,    Source.HANGAR,   "Oraxen",         "oraxen",       null, null, List.of(), "1.21", false, "PAINTING");
        add("itemsadder",      "ItemsAdder",         "Custom items, blocks, mobs via resource pack",               Category.COSMETICS,    Source.SPIGOT,   null,             null,           "73355", null, List.of(), "1.21", false, "DIRT");
        add("modelengine",     "ModelEngine",        "Custom 3D entity models",                                     Category.COSMETICS,    Source.SPIGOT,   null,             null,           "79477", null, List.of(), "1.21", false, "ARMOR_STAND");

        // ── UTILITIES ─────────────────────────────────────────────────────────
        add("placeholderapi",  "PlaceholderAPI",     "Use placeholders from any plugin anywhere",                   Category.UTILITIES,    Source.HANGAR,   "PlaceholderAPI", "HelpChat",     null, null, List.of(), "1.21", true, "PAPER");
        add("skript",          "Skript",             "Script Minecraft events with English-like syntax",            Category.UTILITIES,    Source.HANGAR,   "Skript",         "SkriptLang",   null, null, List.of(), "1.21", true, "WRITABLE_BOOK");
        add("bentobox-bskyblock","BSkyBlock",        "Classic SkyBlock using BentoBox framework",                  Category.WORLD,        Source.HANGAR,   "BSkyBlock",      "BentoBoxWorld",null, null, List.of("bentobox"), "1.21", true, "GRASS_BLOCK");
        add("aoneblock",       "AOneBlock",          "OneBlock skyblock challenge",                                  Category.MINIGAME,     Source.HANGAR,   "AOneBlock",      "BentoBoxWorld",null, null, List.of("bentobox"), "1.21", true, "STONE");
        add("gsit",            "GSit",               "Sit on stairs/slabs, crawl, lay down",                       Category.FUN,          Source.HANGAR,   "GSit",           "gecolay",      null, null, List.of(), "1.21", true, "OAK_STAIRS");
        add("marriagemaster",  "MarriageMaster",     "Marriage system with teleport and shared home",               Category.FUN,          Source.SPIGOT,   null,             null,           "19273", null, List.of(), "1.21", true, "PINK_DYE");
        add("mcmmo",           "mcMMO",              "RPG skills and abilities leveling system",                    Category.RPGG,         Source.HANGAR,   "mcMMO",          "mcMMO",        null, null, List.of(), "1.21", true, "DIAMOND_PICKAXE");
        add("levelledmobs",    "LevelledMobs",       "Dynamic mob leveling with difficulty scaling",               Category.RPGG,         Source.HANGAR,   "LevelledMobs",   "lokka94",      null, null, List.of(), "1.21", true, "ZOMBIE_HEAD");
        add("mmocore",         "MMOCore",            "Player class, skill, quest system",                           Category.RPGG,         Source.SPIGOT,   null,             null,           "70575", null, List.of(), "1.21", false, "GOLDEN_HELMET");
        add("ultimatejobs",    "UltimateJobs",       "Advanced jobs with quest integration",                       Category.ECONOMY,      Source.SPIGOT,   null,             null,           "95541", null, List.of("vault"), "1.21", false, "IRON_AXE");
        add("vote-party",      "VoteParty",          "Reward all players when vote goal reached",                   Category.UTILITIES,    Source.HANGAR,   "VoteParty",      "sahilxh",      null, null, List.of(), "1.21", true, "FIREWORK_ROCKET");
        add("votifier",        "Votifier",           "Register and receive votes from server lists",                Category.UTILITIES,    Source.HANGAR,   "Votifier",       "vectrix",      null, null, List.of(), "1.21", true, "PAPER");
        add("advancedban",     "AdvancedBan",        "Advanced ban/mute/warn system with UI",                       Category.ADMIN,        Source.SPIGOT,   null,             null,           "8695", null, List.of(), "1.21", true, "IRON_BARS");
        add("litebans",        "LiteBans",           "Feature-rich punishment system",                              Category.ADMIN,        Source.SPIGOT,   null,             null,           "3715", null, List.of(), "1.21", false, "IRON_BARS");
        add("matrix-anticheat","NuVotifier",         "Modern Votifier replacement",                                  Category.UTILITIES,    Source.HANGAR,   "NuVotifier",     "vectrix",      null, null, List.of(), "1.21", true, "PAPER");
        add("tab",             "TAB",                "TAB plugin: scoreboard, nametags, header/footer", Category.UTILITIES, Source.HANGAR, "TAB", "Neznamy", null, null, List.of(), "1.21", true, "NAME_TAG");
        add("factionsx",       "FactionsX",          "Modern factions with chunk claiming",                         Category.PROTECTION,   Source.SPIGOT,   null,             null,           "99921", null, List.of("vault"), "1.21", false, "RED_BANNER");
        add("towny",           "Towny Advanced",     "Towns, nations, and civilization management",                 Category.PROTECTION,   Source.HANGAR,   "Towny",          "Towny",        null, null, List.of(), "1.21", true, "BRICK");
        add("iridiumskyblock", "IridiumSkyBlock",    "Feature-rich skyblock with upgrades, boosters",              Category.WORLD,        Source.HANGAR,   "IridiumSkyBlock","Iridium-Development",null,null, List.of(), "1.21", true, "GRASS_BLOCK");
        add("parkour",         "Parkour",            "Create and play parkour courses",                             Category.MINIGAME,     Source.SPIGOT,   null,             null,           "23272", null, List.of(), "1.21", true, "QUARTZ_STAIRS");
        add("signshop",        "SignShop",           "Chest/sign shops economy",                                    Category.SHOP,         Source.SPIGOT,   null,             null,           "7607", null, List.of("vault"), "1.21", true, "OAK_SIGN");
        add("keepinventory",   "PerWorldInventory",  "Separate inventories per world",                              Category.WORLD,        Source.SPIGOT,   null,             null,           "13879", null, List.of(), "1.21", true, "CHEST");
        add("betterenderpearl","BetterEnderPearl",   "Customize enderperl mechanics",                               Category.UTILITIES,    Source.MODRINTH, "better-ender-pearl",null,        null, null, List.of(), "1.21", true, "ENDER_PEARL");
        add("antixray",        "Orebfuscator",       "Prevent X-Ray hacks with block obfuscation",                 Category.ANTI_CHEAT,   Source.HANGAR,   "Orebfuscator",   "Islandscout",  null, null, List.of(), "1.21", true, "DIAMOND_ORE");
        add("trailgui",        "TrailGUI",           "Particle trails/cosmetics for players",                       Category.COSMETICS,    Source.SPIGOT,   null,             null,           "28151", null, List.of(), "1.21", false, "FIREWORK_STAR");
        add("banitem",         "BanItem",            "Ban specific items per world or globally",                    Category.ADMIN,        Source.SPIGOT,   null,             null,           "65643", null, List.of(), "1.21", true, "BARRIER");
        add("slimefun",        "Slimefun4",          "Adds 500+ new items, machines, and tech",                    Category.RPGG,         Source.HANGAR,   "Slimefun4",      "Slimefun",     null, null, List.of(), "1.21", true, "FURNACE");
        add("mythiccrucible",  "MythicCrucible",     "Custom crafting, upgrades for MythicMobs",                   Category.RPGG,         Source.SPIGOT,   null,             null,           "89921", null, List.of("mythicmobs"), "1.21", false, "BLAST_FURNACE");
        add("shopplus",        "ShopPlus",           "Admin shop with category GUI",                                Category.SHOP,         Source.SPIGOT,   null,             null,           "99870", null, List.of("vault"), "1.21", true, "EMERALD_BLOCK");
        add("betonquest",      "BetonQuest",         "Advanced quest plugin with NPC integration",                  Category.RPGG,         Source.HANGAR,   "BetonQuest",     "Silthus",      null, null, List.of(), "1.21", true, "BOOK");
        add("quests",          "Quests",             "Simple quest plugin with Citizens support",                   Category.RPGG,         Source.HANGAR,   "Quests",         "PikaMug",      null, null, List.of(), "1.21", true, "WRITABLE_BOOK");
        add("papi-extension",  "PAPI Expansion Pack","Extra placeholders for PlaceholderAPI",                      Category.UTILITIES,    Source.MODRINTH, "papi-expansion-pack",null,       null, null, List.of("placeholderapi"), "1.21", true, "PAPER");
        add("ebackup",         "eBackup",            "Automated server and world backups",                          Category.ADMIN,        Source.SPIGOT,   null,             null,           "72871", null, List.of(), "1.21", true, "CHEST");
        add("perworldplugins", "PerWorldPlugins",    "Enable/disable plugins per world",                            Category.ADMIN,        Source.SPIGOT,   null,             null,           "6398", null, List.of(), "1.21", true, "COMMAND_BLOCK");
        add("vk-treefeller",   "TreeFeller",         "Chop down whole trees at once",                              Category.UTILITIES,    Source.HANGAR,   "TreeFeller",     "Vertical-Knowledge",null,null, List.of(), "1.21", true, "OAK_LOG");
        add("combatlog",       "CombatLog",          "Punish logging out during combat",                            Category.ADMIN,        Source.SPIGOT,   null,             null,           "31689", null, List.of(), "1.21", true, "IRON_SWORD");
        add("playervaults",    "PlayerVaults",       "Extra private vaults accessible anywhere",                   Category.UTILITIES,    Source.SPIGOT,   null,             null,           "14)), null, List.of(), "1.21", true, "ENDER_CHEST");
        add("backpack",        "BackpacksPlus",      "Custom player backpacks with GUI",                            Category.UTILITIES,    Source.SPIGOT,   null,             null,           "89752", null, List.of(), "1.21", false, "LEATHER_CHESTPLATE");
        add("authme",          "AuthMe",             "Login/register system for offline servers",                   Category.ADMIN,        Source.HANGAR,   "AuthMeReloaded", "AuthMe",       null, null, List.of(), "1.21", true, "LOCK");
        add("tpa",             "TPA",                "Teleport request system between players",                     Category.UTILITIES,    Source.HANGAR,   "TpAddon",        "MGTV",         null, null, List.of(), "1.21", true, "ENDER_PEARL");
        add("sparc",           "SPARC",              "Configurable region control plugin",                          Category.PROTECTION,   Source.SPIGOT,   null,             null,           "67015", null, List.of(), "1.21", true, "BRICK_WALL");
    }

    private static void add(String id, String name, String desc, Category cat, Source src,
                             String slug, String author, String spigotId, String directUrl,
                             List<String> deps, String mc, boolean free, String icon) {
        ALL.add(new PluginEntry(id, name, desc, cat, src, slug, author, spigotId,
                directUrl, deps, mc, free, icon));
    }

    public static List<PluginEntry> getAll()                           { return Collections.unmodifiableList(ALL); }
    public static Optional<PluginEntry> findById(String id)           { return ALL.stream().filter(p -> p.id().equals(id)).findFirst(); }
    public static Optional<PluginEntry> findByName(String name)       { return ALL.stream().filter(p -> p.name().equalsIgnoreCase(name)).findFirst(); }
    public static List<PluginEntry> byCategory(Category cat)          { return ALL.stream().filter(p -> p.category() == cat).toList(); }
    public static List<PluginEntry> freeOnly()                        { return ALL.stream().filter(PluginEntry::free).toList(); }
    public static List<PluginEntry> search(String query) {
        String q = query.toLowerCase();
        return ALL.stream().filter(p ->
                p.name().toLowerCase().contains(q) ||
                p.description().toLowerCase().contains(q) ||
                p.category().name().toLowerCase().contains(q)
        ).toList();
    }
    public static List<Category> allCategories() { return List.of(Category.values()); }
}