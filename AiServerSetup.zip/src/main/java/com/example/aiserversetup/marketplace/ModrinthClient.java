package com.example.aiserversetup.marketplace;

import com.google.gson.*;

import java.net.URI;
import java.net.http.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * Client for the Modrinth plugin repository API v2.
 * Docs: https://docs.modrinth.com/api/
 */
public class ModrinthClient {

    private static final String BASE = "https://api.modrinth.com/v2";
    private static final String MC_VERSION = "1.21.1";
    private final HttpClient http = HttpClient.newHttpClient();

    /** Get the latest version download URL for a project slug. */
    public CompletableFuture<Optional<String>> getLatestDownloadUrl(String slug) {
        String url = BASE + "/project/" + slug + "/version?loaders=[\"paper\",\"spigot\"]"
                + "&game_versions=[\"" + MC_VERSION + "\"]";
        return get(url).thenApply(body -> {
            if (body == null) return Optional.empty();
            try {
                JsonArray arr = JsonParser.parseString(body).getAsJsonArray();
                if (arr.isEmpty()) return Optional.empty();
                JsonObject latest = arr.get(0).getAsJsonObject();
                JsonArray files   = latest.getAsJsonArray("files");
                if (files.isEmpty()) return Optional.empty();
                // Prefer primary file
                for (JsonElement f : files) {
                    JsonObject file = f.getAsJsonObject();
                    if (file.has("primary") && file.get("primary").getAsBoolean()) {
                        return Optional.of(file.get("url").getAsString());
                    }
                }
                return Optional.of(files.get(0).getAsJsonObject().get("url").getAsString());
            } catch (Exception e) { return Optional.empty(); }
        });
    }

    /** Search Modrinth for plugins. Returns list of {name, description, slug, project_id}. */
    public CompletableFuture<List<Map<String, String>>> search(String query, int limit) {
        String url = BASE + "/search?query=" + encode(query)
                + "&facets=[[\"project_type:plugin\"],[\"categories:paper\"]]&limit=" + limit;
        return get(url).thenApply(body -> {
            List<Map<String, String>> results = new ArrayList<>();
            if (body == null) return results;
            try {
                JsonObject json = JsonParser.parseString(body).getAsJsonObject();
                JsonArray hits  = json.getAsJsonArray("hits");
                for (JsonElement el : hits) {
                    JsonObject p = el.getAsJsonObject();
                    Map<String, String> m = new LinkedHashMap<>();
                    m.put("name",       p.get("title").getAsString());
                    m.put("description",p.get("description").getAsString());
                    m.put("slug",       p.get("slug").getAsString());
                    m.put("project_id", p.get("project_id").getAsString());
                    m.put("downloads",  p.get("downloads").getAsString());
                    results.add(m);
                }
            } catch (Exception ignored) {}
            return results;
        });
    }

    /** Get latest version number string for a project. */
    public CompletableFuture<Optional<String>> getLatestVersionString(String slug) {
        String url = BASE + "/project/" + slug + "/version?loaders=[\"paper\",\"spigot\"]"
                + "&game_versions=[\"" + MC_VERSION + "\"]";
        return get(url).thenApply(body -> {
            if (body == null) return Optional.empty();
            try {
                JsonArray arr = JsonParser.parseString(body).getAsJsonArray();
                if (arr.isEmpty()) return Optional.empty();
                return Optional.of(arr.get(0).getAsJsonObject().get("version_number").getAsString());
            } catch (Exception e) { return Optional.empty(); }
        });
    }

    private CompletableFuture<String> get(String url) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Accept", "application/json")
                        .header("User-Agent", "AIServerSetup/3.0")
                        .GET().build();
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
                return resp.statusCode() == 200 ? resp.body() : null;
            } catch (Exception e) { return null; }
        });
    }

    private String encode(String s) { return s.replace(" ", "%20"); }
}