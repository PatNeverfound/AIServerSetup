package com.example.aiserversetup.marketplace;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.marketplace.PluginCatalog.*;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Full paginated plugin marketplace GUI.
 * Page 0: Category browser
 * Page 1+: Plugin list for selected category
 * Also supports search results display.
 */
public class MarketplaceGUI {

    public static final String TITLE_PREFIX = "§b§l🏪 Plugin Marketplace";
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final AIServerSetupPlugin plugin;

    // Per-player state
    private final Map<String, Integer> currentPage     = new HashMap<>();
    private final Map<String, Category> selectedCat    = new HashMap<>();
    private final Map<String, List<PluginEntry>> displayList = new HashMap<>();
    private final Map<String, String> mode             = new HashMap<>(); // "browse", "search", "featured"

    private static final int ITEMS_PER_PAGE = 28;

    public MarketplaceGUI(AIServerSetupPlugin plugin) { this.plugin = plugin; }

    /** Open the category browser. */
    public void openCategories(Player player) {
        mode.put(player.getName(), "browse");
        Inventory inv = Bukkit.createInventory(null, 54,
                MM.deserialize("<!bold><gradient:#00c6ff:#0072ff>🏪 Plugin Marketplace — Categories</gradient>"));

        fillBorder(inv);

        Category[] cats = Category.values();
        int[] catSlots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        for (int i = 0; i < Math.min(cats.length, catSlots.length); i++) {
            Category cat = cats[i];
            int count = PluginCatalog.byCategory(cat).size();
            inv.setItem(catSlots[i], makeItem(
                    categoryMaterial(cat),
                    "<aqua>" + titleCase(cat.name()),
                    List.of("<gray>" + count + " plugins</gray>",
                            "",
                            "<yellow>Click to browse</yellow>")));
        }

        // Featured / All / Search buttons
        inv.setItem(46, makeItem(Material.NETHER_STAR,  "<gold>⭐ Featured",    List.of("<gray>Staff-recommended plugins</gray>")));
        inv.setItem(48, makeItem(Material.COMPASS,      "<green>🔍 Search",      List.of("<gray>Search all plugins live</gray>")));
        inv.setItem(50, makeItem(Material.BOOK,         "<aqua>📋 All Plugins",  List.of("<gray>Browse complete catalog</gray>")));
        inv.setItem(52, makeItem(Material.BARRIER,      "<red>✗ Close",          List.of()));

        player.openInventory(inv);
    }

    /** Open paginated plugin list for a category. */
    public void openCategory(Player player, Category cat, int page) {
        selectedCat.put(player.getName(), cat);
        currentPage.put(player.getName(), page);
        mode.put(player.getName(), "browse");

        List<PluginEntry> plugins = PluginCatalog.byCategory(cat);
        displayList.put(player.getName(), plugins);
        openPluginList(player, plugins, "Category: " + titleCase(cat.name()), page);
    }

    /** Open paginated search results. */
    public void openSearchResults(Player player, List<PluginEntry> results, String query) {
        mode.put(player.getName(), "search");
        displayList.put(player.getName(), results);
        currentPage.put(player.getName(), 0);
        openPluginList(player, results, "Search: \"" + query + "\"", 0);
    }

    /** Open featured plugins. */
    public void openFeatured(Player player) {
        List<PluginEntry> featured = List.of(
                PluginCatalog.findById("essentialsx").orElseThrow(),
                PluginCatalog.findById("luckperms").orElseThrow(),
                PluginCatalog.findById("worldguard").orElseThrow(),
                PluginCatalog.findById("worldedit").orElseThrow(),
                PluginCatalog.findById("coreprotect").orElseThrow(),
                PluginCatalog.findById("vault").orElseThrow(),
                PluginCatalog.findById("placeholderapi").orElseThrow(),
                PluginCatalog.findById("discordsrv").orElseThrow(),
                PluginCatalog.findById("geyser").orElseThrow(),
                PluginCatalog.findById("viaversion").orElseThrow(),
                PluginCatalog.findById("chunky").orElseThrow(),
                PluginCatalog.findById("spark").orElseThrow(),
                PluginCatalog.findById("luckperms").orElseThrow(),
                PluginCatalog.findById("dynmap").orElseThrow(),
                PluginCatalog.findById("skript").orElseThrow()
        );
        mode.put(player.getName(), "featured");
        displayList.put(player.getName(), featured);
        currentPage.put(player.getName(), 0);
        openPluginList(player, featured, "⭐ Featured Plugins", 0);
    }

    private void openPluginList(Player player, List<PluginEntry> plugins, String title, int page) {
        int totalPages = (int) Math.ceil(plugins.size() / (double) ITEMS_PER_PAGE);
        if (totalPages == 0) totalPages = 1;
        if (page >= totalPages) page = totalPages - 1;
        if (page < 0) page = 0;
        currentPage.put(player.getName(), page);

        Inventory inv = Bukkit.createInventory(null, 54,
                MM.deserialize("<!bold><gradient:#00c6ff:#0072ff>🏪 " + title
                        + " (" + (page + 1) + "/" + totalPages + ")</gradient>"));
        fillBorder(inv);

        int[] slots = { 10,11,12,13,14,15,16,
                        19,20,21,22,23,24,25,
                        28,29,30,31,32,33,34,
                        37,38,39,40,41,42,43 };

        int start = page * ITEMS_PER_PAGE;
        for (int i = 0; i < ITEMS_PER_PAGE && start + i < plugins.size(); i++) {
            PluginEntry p = plugins.get(start + i);
            boolean installed = plugin.getMarketplace().getInstaller().isInstalled(p.name());
            String status = installed ? "<green>✔ Installed</green>" : (p.free() ? "<green>Free</green>" : "<red>Paid</red>");
            String srcIcon = switch (p.source()) {
                case HANGAR -> "🏗 Hangar";
                case MODRINTH -> "💠 Modrinth";
                case SPIGOT -> "🌿 Spigot";
                case GITHUB -> "🐙 GitHub";
            };
            List<String> lore = new ArrayList<>();
            lore.add("<gray>" + truncate(p.description(), 45) + "</gray>");
            lore.add("");
            lore.add("<dark_gray>Source: " + srcIcon + "</dark_gray>");
            lore.add("<dark_gray>Category: " + titleCase(p.category().name()) + "</dark_gray>");
            if (!p.dependencies().isEmpty())
                lore.add("<dark_gray>Deps: " + String.join(", ", p.dependencies()) + "</dark_gray>");
            lore.add("");
            lore.add(status);
            if (!installed) lore.add("<yellow>Left-click to install</yellow>");
            lore.add("<aqua>Right-click for AI advice</aqua>");

            Material mat = safeMaterial(p.iconMaterial());
            if (installed) mat = Material.LIME_STAINED_GLASS_PANE;
            inv.setItem(slots[i], makeItem(mat, "<white>" + p.name(), lore));
        }

        // Navigation
        if (page > 0)
            inv.setItem(45, makeItem(Material.ARROW, "<white>◀ Previous", List.of("<gray>Page " + page + "</gray>")));
        if (page < totalPages - 1)
            inv.setItem(53, makeItem(Material.ARROW, "<white>Next ▶", List.of("<gray>Page " + (page + 2) + "</gray>")));
        inv.setItem(49, makeItem(Material.DARK_OAK_DOOR, "<red>◀ Back", List.of("<gray>Return to categories</gray>")));
        inv.setItem(47, makeItem(Material.BOOK, "<aqua>🤖 AI Recommend", List.of("<gray>Ask AI what to install</gray>")));

        player.openInventory(inv);
    }

    // ── Accessors for GUI Listener ────────────────────────────────────────────

    public int getPage(String playerName)               { return currentPage.getOrDefault(playerName, 0); }
    public Category getCategory(String playerName)      { return selectedCat.get(playerName); }
    public List<PluginEntry> getDisplayList(String name){ return displayList.getOrDefault(name, List.of()); }
    public String getMode(String playerName)            { return mode.getOrDefault(playerName, "browse"); }

    /** Get the PluginEntry for the item at a given slot on the current page. */
    public Optional<PluginEntry> getEntryAtSlot(String playerName, int slot) {
        int[] slots = { 10,11,12,13,14,15,16, 19,20,21,22,23,24,25,
                        28,29,30,31,32,33,34, 37,38,39,40,41,42,43 };
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == slot) {
                List<PluginEntry> list = getDisplayList(playerName);
                int idx = getPage(playerName) * ITEMS_PER_PAGE + i;
                return idx < list.size() ? Optional.of(list.get(idx)) : Optional.empty();
            }
        }
        return Optional.empty();
    }

    public Category getCategoryAtSlot(int slot) {
        int[] catSlots = {10,11,12,13,14,15,16, 19,20,21,22,23,24,25, 28,29,30,31,32,33,34};
        Category[] cats = Category.values();
        for (int i = 0; i < catSlots.length; i++) {
            if (catSlots[i] == slot && i < cats.length) return cats[i];
        }
        return null;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void fillBorder(Inventory inv) {
        ItemStack glass = makeItem(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < 9; i++)  inv.setItem(i, glass);
        for (int i = 45; i < 54; i++) inv.setItem(i, glass);
        for (int i = 9; i < 45; i += 9)  inv.setItem(i, glass);
        for (int i = 17; i < 45; i += 9) inv.setItem(i, glass);
    }

    private ItemStack makeItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta  = item.getItemMeta();
        meta.displayName(MM.deserialize("<!italic>" + name));
        meta.lore(lore.stream().map(l -> MM.deserialize("<!italic>" + l)).toList());
        item.setItemMeta(meta);
        return item;
    }

    private Material categoryMaterial(Category cat) {
        return switch (cat) {
            case ADMIN          -> Material.COMMAND_BLOCK;
            case ANTI_CHEAT     -> Material.BARRIER;
            case CHAT           -> Material.PAPER;
            case ECONOMY        -> Material.GOLD_INGOT;
            case PROTECTION     -> Material.OAK_FENCE;
            case WORLD          -> Material.GRASS_BLOCK;
            case FUN            -> Material.FIREWORK_ROCKET;
            case PERFORMANCE    -> Material.BLAZE_ROD;
            case CROSS_PLATFORM -> Material.DIAMOND;
            case UTILITIES      -> Material.COMPARATOR;
            case MINIGAME       -> Material.DIAMOND_SWORD;
            case RPGG           -> Material.GOLDEN_SWORD;
            case LOGGING        -> Material.CLOCK;
            case PERMISSIONS    -> Material.NETHER_STAR;
            case MAPS           -> Material.MAP;
            case NPCS           -> Material.PLAYER_HEAD;
            case HOLOGRAMS      -> Material.NAME_TAG;
            case SHOP           -> Material.CHEST;
            case COSMETICS      -> Material.BLAZE_POWDER;
            case MISC           -> Material.BOOK;
        };
    }

    private Material safeMaterial(String name) {
        try { return Material.valueOf(name.toUpperCase()); }
        catch (Exception e) { return Material.BOOK; }
    }

    private String titleCase(String s) {
        return Arrays.stream(s.split("_")).map(w -> w.charAt(0) + w.substring(1).toLowerCase()).collect(Collectors.joining(" "));
    }

    private String truncate(String s, int max) {
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }
}