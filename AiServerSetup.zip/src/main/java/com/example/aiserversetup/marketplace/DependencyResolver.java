package com.example.aiserversetup.marketplace;

import com.example.aiserversetup.marketplace.PluginCatalog.PluginEntry;
import com.example.aiserversetup.util.ChatUtil;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

/**
 * Analyzes a list of plugins to install and resolves their full dependency tree.
 */
public class DependencyResolver {

    private final JavaPlugin plugin;
    private final ChatUtil chat;

    public DependencyResolver(JavaPlugin plugin, ChatUtil chat) {
        this.plugin = plugin;
        this.chat   = chat;
    }

    /**
     * Given a list of plugin IDs, return the full install order
     * with dependencies listed before the plugins that need them.
     */
    public List<PluginEntry> resolve(List<String> pluginIds, CommandSender sender) {
        Set<String> seen   = new LinkedHashSet<>();
        List<PluginEntry> ordered = new ArrayList<>();

        for (String id : pluginIds) {
            PluginCatalog.findById(id).ifPresent(entry -> resolveEntry(entry, seen, ordered, sender, 0));
        }

        return ordered;
    }

    private void resolveEntry(PluginEntry entry, Set<String> seen,
                               List<PluginEntry> ordered, CommandSender sender, int depth) {
        if (seen.contains(entry.id())) return;
        seen.add(entry.id());

        if (depth > 10) {
            chat.warn(sender, "Circular dependency detected for " + entry.name() + ", skipping.");
            return;
        }

        // Resolve deps first
        for (String depId : entry.dependencies()) {
            PluginCatalog.findById(depId).ifPresent(dep ->
                    resolveEntry(dep, seen, ordered, sender, depth + 1));
        }
        ordered.add(entry);
    }

    /** Check which dependencies for a plugin are missing from the server. */
    public List<String> getMissingDependencies(PluginEntry entry) {
        List<String> missing = new ArrayList<>();
        for (String depId : entry.dependencies()) {
            PluginCatalog.findById(depId).ifPresent(dep -> {
                if (plugin.getServer().getPluginManager().getPlugin(dep.name()) == null) {
                    missing.add(dep.name());
                }
            });
        }
        return missing;
    }

    /** Generate an install order string for display. */
    public String formatOrder(List<PluginEntry> order) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < order.size(); i++) {
            sb.append(i + 1).append(". ").append(order.get(i).name());
            if (!order.get(i).dependencies().isEmpty()) {
                sb.append(" (needs: ").append(String.join(", ", order.get(i).dependencies())).append(")");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}