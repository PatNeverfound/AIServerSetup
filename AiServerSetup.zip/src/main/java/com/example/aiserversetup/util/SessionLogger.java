package com.example.aiserversetup.util;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

/**
 * Logs AI conversation sessions to dated log files.
 */
public class SessionLogger {

    private final boolean enabled;
    private final File logDir;
    private BufferedWriter writer;
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public SessionLogger(File dataFolder, boolean enabled) {
        this.enabled = enabled;
        this.logDir  = new File(dataFolder, "logs");
        if (enabled) {
            logDir.mkdirs();
            openLogFile();
        }
    }

    private void openLogFile() {
        String date = LocalDate.now().format(DATE_FMT);
        File file = new File(logDir, "session-" + date + ".log");
        try {
            writer = new BufferedWriter(new FileWriter(file, true));
            writer.write("\n=== Session started: " + LocalDateTime.now() + " ===\n");
            writer.flush();
        } catch (IOException e) {
            System.err.println("[AIServerSetup] Failed to open log file: " + e.getMessage());
        }
    }

    public void log(String sender, String role, String message) {
        if (!enabled || writer == null) return;
        try {
            String time = LocalTime.now().format(TIME_FMT);
            writer.write("[" + time + "] [" + sender + "/" + role.toUpperCase() + "] " + message + "\n");
            writer.flush();
        } catch (IOException ignored) {}
    }

    public void close() {
        if (writer != null) {
            try { writer.close(); } catch (IOException ignored) {}
        }
    }
}