package com.example.aiserversetup.util;

import java.util.*;

/** Records every config action for undo support. */
public class ActionHistory {

    public enum ActionType { SERVER_PROPERTY, YAML, WHITELIST, OP }

    public record Action(ActionType type, String key, String oldValue, String newValue, long timestamp) {}

    private final int maxSize;
    private final Deque<Action> history = new ArrayDeque<>();

    public ActionHistory(int maxSize) { this.maxSize = maxSize; }

    public void record(ActionType type, String key, String old, String newVal) {
        if (history.size() >= maxSize) history.pollFirst();
        history.addLast(new Action(type, key, old, newVal, System.currentTimeMillis()));
    }

    public Optional<Action> peekLast() {
        return history.isEmpty() ? Optional.empty() : Optional.of(history.peekLast());
    }

    public Optional<Action> popLast() {
        return history.isEmpty() ? Optional.empty() : Optional.of(history.pollLast());
    }

    public List<Action> getAll() { return new ArrayList<>(history); }
    public int size()            { return history.size(); }
    public void clear()          { history.clear(); }
}