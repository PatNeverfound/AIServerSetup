package com.example.aiserversetup.util;

import java.util.Optional;
import java.util.function.*;

/**
 * Rust-inspired Result<T, E> type.
 * Eliminates scattered try/catch and null checks throughout the codebase.
 *
 * Usage:
 *   Result<ItemStack, String> r = Result.ok(item);
 *   Result<ItemStack, String> r = Result.err("Item not found");
 *   r.ifOk(item -> player.give(item));
 *   r.ifErr(msg -> player.sendMessage(msg));
 *   String msg = r.fold(item -> "Got item", err -> "Error: " + err);
 */
public sealed interface Result<T, E> permits Result.Ok, Result.Err {

    record Ok<T, E>(T value)  implements Result<T, E> {}
    record Err<T, E>(E error) implements Result<T, E> {}

    static <T, E> Result<T, E> ok(T value)  { return new Ok<>(value); }
    static <T, E> Result<T, E> err(E error) { return new Err<>(error); }

    static <T> Result<T, String> tryRun(java.util.concurrent.Callable<T> action) {
        try { return ok(action.call()); }
        catch (Exception e) { return err(e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName()); }
    }

    default boolean isOk()  { return this instanceof Ok; }
    default boolean isErr() { return this instanceof Err; }

    default T value() {
        if (this instanceof Ok<T, E> ok) return ok.value();
        throw new NoSuchElementException("Result is Err");
    }

    default E error() {
        if (this instanceof Err<T, E> err) return err.error();
        throw new NoSuchElementException("Result is Ok");
    }

    default Optional<T> toOptional() { return isOk() ? Optional.of(value()) : Optional.empty(); }

    default void ifOk(Consumer<T> action)  { if (isOk())  action.accept(value()); }
    default void ifErr(Consumer<E> action) { if (isErr()) action.accept(error()); }

    default <U> U fold(Function<T, U> onOk, Function<E, U> onErr) {
        return isOk() ? onOk.apply(value()) : onErr.apply(error());
    }

    default <U> Result<U, E> map(Function<T, U> mapper) {
        return isOk() ? ok(mapper.apply(value())) : err(error());
    }
}