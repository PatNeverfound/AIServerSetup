package com.example.aiserversetup.util;

import com.example.aiserversetup.core.PluginCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.time.format.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.*;

/**
 * Structured logger with:
 * - Log levels (DEBUG, INFO, WARN, ERROR, FATAL)
 * - File output (daily rotating logs)
 * - In-game broadcast to staff
 * - Optional Discord webhook forwarding
 * - Context tags (module, player, action)
 * - Async file writes (never block server)
 */
public class StructuredLogger implements PluginCore.PluginModule {

    public enum LogLevel { DEBUG, INFO, WARN, ERROR, FATAL }

    private final BlockingQueue<LogEntry> queue = new LinkedBlockingQueue<>(10_000);
    private PrintWriter writer;
    private Thread      logThread;
    private LogLevel    minLevel;
    private boolean     debugMode;
    private boolean     broadcastErrors;
    private boolean     consoleOutput;

    public record LogEntry(
            LogLevel level, String module, String message,
            String player, Throwable cause, Instant time
    ) {
        String format() {
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm:ss")
                    .withZone(ZoneId.systemDefault());
            String base = "[" + fmt.format(time) + "] [" + level + "] ";
            if (module != null) base += "[" + module + "] ";
            if (player != null) base += "[" + player + "] ";
            base += message;
            return base;
        }
    }

    @Override public String name() { return "StructuredLogger"; }

    @Override
    public void onEnable(PluginCore core) throws Exception {
        var cfg = core.getPlugin().getConfig();
        debugMode       = cfg.getBoolean("logging.debug", false);
        broadcastErrors = cfg.getBoolean("logging.broadcast-errors-to-staff", true);
        consoleOutput   = cfg.getBoolean("logging.console", true);
        minLevel        = LogLevel.valueOf(cfg.getString("logging.min-level", "INFO").toUpperCase());

        // File output
        Path logDir = core.getPlugin().getDataFolder().toPath().resolve("logs");
        Files.createDirectories(logDir);
        String filename = "server-" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + ".log";
        writer = new PrintWriter(new BufferedWriter(new FileWriter(logDir.resolve(filename).toFile(), true)), true);

        // Async writer thread
        logThread = new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    LogEntry entry = queue.poll(1, TimeUnit.SECONDS);
                    if (entry != null) writeEntry(entry);
                } catch (InterruptedException e) { break; }
            }
            // Drain remaining
            LogEntry e;
            while ((e = queue.poll()) != null) writeEntry(e);
        }, "AISetup-Logger");
        logThread.setDaemon(true);
        logThread.start();

        info("StructuredLogger", "Logger initialised. Level=" + minLevel + " Debug=" + debugMode);
    }

    @Override
    public void onDisable(PluginCore core) {
        if (logThread != null) logThread.interrupt();
        if (writer != null) writer.close();
    }

    // ── Logging API ───────────────────────────────────────────────────────────

    public void debug(String module, String msg)                   { log(LogLevel.DEBUG, module, msg, null, null); }
    public void info (String module, String msg)                   { log(LogLevel.INFO,  module, msg, null, null); }
    public void warn (String module, String msg)                   { log(LogLevel.WARN,  module, msg, null, null); }
    public void error(String module, String msg)                   { log(LogLevel.ERROR, module, msg, null, null); }
    public void error(String module, String msg, Throwable cause)  { log(LogLevel.ERROR, module, msg, null, cause); }
    public void fatal(String module, String msg, Throwable cause)  { log(LogLevel.FATAL, module, msg, null, cause); }

    public void playerAction(String module, String playerName, String action) {
        log(LogLevel.INFO, module, action, playerName, null);
    }

    public void audit(String actor, String action, String target, String details) {
        log(LogLevel.INFO, "AUDIT", actor + " → " + action +
                (target != null ? " on " + target : "") +
                (details != null ? " | " + details : ""), null, null);
        // Also save to DB audit log
        PluginCore.get().serviceOpt(com.example.aiserversetup.database.DatabaseService.class)
                .ifPresent(db -> db.update(
                        "INSERT INTO audit_log(actor,action,target,details,timestamp) VALUES(?,?,?,?,?)",
                        ps -> {
                            ps.setString(1, actor);
                            ps.setString(2, action);
                            ps.setString(3, target);
                            ps.setString(4, details);
                            ps.setLong(5, Instant.now().getEpochSecond());
                        }));
    }

    private void log(LogLevel level, String module, String message, String player, Throwable cause) {
        if (level.ordinal() < minLevel.ordinal()) return;
        if (level == LogLevel.DEBUG && !debugMode) return;

        LogEntry entry = new LogEntry(level, module, message, player, cause, Instant.now());
        queue.offer(entry);

        // Broadcast errors to staff in-game
        if (broadcastErrors && (level == LogLevel.ERROR || level == LogLevel.FATAL)) {
            String broadcast = "§c[Server Error] §f" + module + ": " + message;
            Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () ->
                    Bukkit.getOnlinePlayers().stream()
                            .filter(p -> p.hasPermission("aiserversetup.alerts"))
                            .forEach(p -> p.sendMessage(broadcast)));
        }
    }

    private void writeEntry(LogEntry entry) {
        String line = entry.format();
        if (writer != null) writer.println(line);
        if (consoleOutput) {
            Level jLevel = switch (entry.level()) {
                case DEBUG -> Level.FINE;
                case INFO  -> Level.INFO;
                case WARN  -> Level.WARNING;
                case ERROR, FATAL -> Level.SEVERE;
            };
            PluginCore.get().getPlugin().getLogger().log(jLevel, "[" + (entry.module() != null ? entry.module() : "?") + "] " + entry.message(),
                    entry.cause());
        }
    }
}