package com.example.aiserversetup.util;

import java.util.*;
import java.util.concurrent.*;

/** Holds pending dangerous actions awaiting /confirm or /cancel. */
public class ConfirmationManager {

    public record PendingAction(String description, Runnable action, long expiry) {}

    private final Map<String, PendingAction> pending = new ConcurrentHashMap<>();
    private static final long TIMEOUT_MS = 30_000;

    public void add(String senderName, String description, Runnable action) {
        pending.put(senderName, new PendingAction(description, action, System.currentTimeMillis() + TIMEOUT_MS));
    }

    public boolean confirm(String senderName) {
        PendingAction pa = pending.remove(senderName);
        if (pa == null || System.currentTimeMillis() > pa.expiry()) return false;
        pa.action().run();
        return true;
    }

    public boolean cancel(String senderName) {
        return pending.remove(senderName) != null;
    }

    public Optional<PendingAction> getPending(String senderName) {
        PendingAction pa = pending.get(senderName);
        if (pa != null && System.currentTimeMillis() > pa.expiry()) { pending.remove(senderName); return Optional.empty(); }
        return Optional.ofNullable(pa);
    }
}