package com.example.aiserversetup.util;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Shows a bossbar while the AI is thinking. */
public class BossBarManager {

    private static JavaPlugin plugin;
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final Map<String, BossBar> activeBars = new ConcurrentHashMap<>();

    public static void init(JavaPlugin p) { plugin = p; }

    public static void showThinking(Player player) {
        BossBar bar = BossBar.bossBar(
                MM.deserialize("<gradient:#00c6ff:#0072ff>⟳ AI is thinking...</gradient>"),
                1.0f, BossBar.Color.BLUE, BossBar.Overlay.PROGRESS);
        activeBars.put(player.getName(), bar);
        player.showBossBar(bar);

        // Animate progress drain
        int[] tick = {0};
        plugin.getServer().getScheduler().runTaskTimer(plugin, (task) -> {
            if (!activeBars.containsKey(player.getName())) { task.cancel(); return; }
            tick[0]++;
            float progress = Math.max(0f, 1f - (tick[0] / 200f));
            bar.progress(progress);
            if (tick[0] > 200) task.cancel();
        }, 0L, 1L);
    }

    public static void hide(Player player) {
        BossBar bar = activeBars.remove(player.getName());
        if (bar != null) player.hideBossBar(bar);
    }

    public static void showSuccess(Player player) {
        BossBar bar = BossBar.bossBar(
                MM.deserialize("<green>✔ AI response received!</green>"),
                1.0f, BossBar.Color.GREEN, BossBar.Overlay.PROGRESS);
        player.showBossBar(bar);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> player.hideBossBar(bar), 40L);
    }
}