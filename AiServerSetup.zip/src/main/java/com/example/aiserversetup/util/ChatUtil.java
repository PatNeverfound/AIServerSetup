    /** Convenience: show success or error based on a boolean result. */
    public void result(CommandSender sender, boolean ok, String successMsg, String failMsg) {
        if (ok) success(sender, successMsg);
        else    error(sender, failMsg);
    }