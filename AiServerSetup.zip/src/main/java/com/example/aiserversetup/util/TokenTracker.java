package com.example.aiserversetup.util;

import java.util.concurrent.atomic.*;

/** Tracks token usage and cost estimates across all AI calls. */
public class TokenTracker {

    private final String model;
    private final AtomicLong promptTokens     = new AtomicLong();
    private final AtomicLong completionTokens = new AtomicLong();
    private final AtomicLong requestCount     = new AtomicLong();

    public TokenTracker(String model) { this.model = model; }

    public void record(long prompt, long completion) {
        promptTokens.addAndGet(prompt);
        completionTokens.addAndGet(completion);
        requestCount.incrementAndGet();
    }

    public long getPromptTokens()     { return promptTokens.get(); }
    public long getCompletionTokens() { return completionTokens.get(); }
    public long getTotalTokens()      { return promptTokens.get() + completionTokens.get(); }
    public long getRequestCount()     { return requestCount.get(); }

    public double estimateCostUSD() {
        double in  = model.contains("4o")      ? 0.000005 :
                     model.contains("4-turbo") ? 0.00001  : 0.0000005;
        double out = model.contains("4o")      ? 0.000015 :
                     model.contains("4-turbo") ? 0.00003  : 0.0000015;
        return (promptTokens.get() * in) + (completionTokens.get() * out);
    }

    public String summary() {
        return String.format("Requests: %d | Tokens: %d (in: %d, out: %d) | ~$%.5f",
                requestCount.get(), getTotalTokens(),
                promptTokens.get(), completionTokens.get(), estimateCostUSD());
    }
}