package com.example.aiserversetup.diagnostics;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.database.DatabaseService;
import org.bukkit.*;
import org.bukkit.scheduler.BukkitTask;

import java.lang.management.*;
import java.util.List;

/**
 * Collects and persists server performance metrics.
 * Provides TPS, memory, entity count, and chunk load data.
 * Logs metrics to DB every 60 seconds.
 */
public class ServerDiagnostics implements PluginCore.PluginModule {

    /**
     * Immutable snapshot of server health at a point in time.
     */
    public record DiagSnapshot(
            double tps,
            int    onlinePlayers,
            long   memUsedMB,
            long   memMaxMB,
            double memPctUsed,
            int    totalEntities,
            int    loadedChunks,
            long   timestamp
    ) {
        public String summary() {
            return String.format("TPS=%.1f Players=%d Mem=%d/%dMB Entities=%d Chunks=%d",
                    tps, onlinePlayers, memUsedMB, memMaxMB, totalEntities, loadedChunks);
        }

        public boolean isHealthy() {
            return tps >= 18.0 && memPctUsed < 90.0;
        }
    }

    private BukkitTask logTask;
    private DiagSnapshot lastSnapshot;

    @Override
    public String name() { return "ServerDiagnostics"; }

    @Override
    public void onEnable(PluginCore core) {
        // Collect and log metrics every 60 seconds
        logTask = Bukkit.getScheduler().runTaskTimerAsynchronously(
                core.getPlugin(), this::collectAndLog, 20L * 30, 20L * 60);
        core.getPlugin().getLogger().info("[Diagnostics] Metrics collection started.");
    }

    @Override
    public void onDisable(PluginCore core) {
        if (logTask != null) logTask.cancel();
    }

    // ── Core collection ───────────────────────────────────────────────────────

    /**
     * Collect a fresh server snapshot right now.
     * Safe to call from main thread or async.
     */
    public DiagSnapshot collect() {
        double tps = Bukkit.getTPS()[0]; // 1-minute average
        tps = Math.min(20.0, tps);       // Cap at 20 (Paper can briefly report >20)

        Runtime rt       = Runtime.getRuntime();
        long memUsed     = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
        long memMax      = rt.maxMemory() / (1024 * 1024);
        double memPct    = memMax > 0 ? (double) memUsed / memMax * 100.0 : 0.0;

        int entities = 0;
        int chunks   = 0;
        try {
            // These calls are safe to make from async in Paper
            for (World w : Bukkit.getWorlds()) {
                entities += w.getEntityCount();
                chunks   += w.getLoadedChunks().length;
            }
        } catch (Exception ignored) {}

        lastSnapshot = new DiagSnapshot(
                tps,
                Bukkit.getOnlinePlayers().size(),
                memUsed,
                memMax,
                memPct,
                entities,
                chunks,
                System.currentTimeMillis()
        );
        return lastSnapshot;
    }

    public DiagSnapshot getLastSnapshot() {
        if (lastSnapshot == null) return collect();
        return lastSnapshot;
    }

    // ── DB logging ────────────────────────────────────────────────────────────

    private void collectAndLog() {
        DiagSnapshot snap = collect();
        PluginCore.get().serviceOpt(DatabaseService.class).ifPresent(db ->
                db.update(
                        "INSERT INTO tps_log(tps, memory_used, cpu_pct, online, timestamp) VALUES(?,?,?,?,?)",
                        ps -> {
                            ps.setDouble(1, snap.tps());
                            ps.setLong(2,   snap.memUsedMB());
                            ps.setDouble(3, snap.memPctUsed());
                            ps.setInt(4,    snap.onlinePlayers());
                            ps.setLong(5,   snap.timestamp() / 1000);
                        })
                .exceptionally(e -> { /* Silently ignore DB write errors */ return 0; })
        );

        // Warn if server is struggling
        if (!snap.isHealthy()) {
            PluginCore.get().serviceOpt(com.example.aiserversetup.util.StructuredLogger.class)
                    .ifPresent(log -> log.warn("Diagnostics",
                            "Server health warning! " + snap.summary()));
        }
    }

    // ── Historical queries ────────────────────────────────────────────────────

    /**
     * Get average TPS over the last N minutes.
     */
    public double getAverageTPS(int minutes) {
        // Use Paper's built-in TPS array
        double[] tps = Bukkit.getTPS();
        return switch (minutes) {
            case 1  -> Math.min(20.0, tps[0]);
            case 5  -> Math.min(20.0, tps[1]);
            case 15 -> Math.min(20.0, tps[2]);
            default -> Math.min(20.0, tps[0]);
        };
    }

    /**
     * Get JVM thread count.
     */
    public int getThreadCount() {
        return ManagementFactory.getThreadMXBean().getThreadCount();
    }

    /**
     * Get the server's uptime in seconds.
     */
    public long getUptimeSeconds() {
        return ManagementFactory.getRuntimeMXBean().getUptime() / 1000;
    }
}