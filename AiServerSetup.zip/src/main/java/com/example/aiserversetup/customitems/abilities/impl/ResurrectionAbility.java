package com.example.aiserversetup.customitems.abilities.impl;

import com.example.aiserversetup.customitems.abilities.Ability;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.Map;

/**
 * When the player would die, they are auto-revived with partial HP.
 * Single-use per item — burns the item on use.
 */
public class ResurrectionAbility implements Ability {
    @Override public String getId()          { return "resurrection"; }
    @Override public String getDisplayName() { return "Resurrection"; }
    @Override public String getDescription(){ return "Auto-revive on death (single use)"; }
    @Override public String getCategory()   { return "Utility"; }
    @Override public Trigger getTrigger()   { return Trigger.DEATH; }
    @Override public int getDefaultCooldown(){ return 0; }

    @Override
    public void execute(Player player, Map<String, Object> params, Event event) {
        double reviveHp = params.containsKey("hp") ? ((Number)params.get("hp")).doubleValue() : 4.0;
        boolean burnItem = !params.containsKey("reusable") || !((Boolean)params.get("reusable"));

        Bukkit.getScheduler().runTaskLater(player.getPlugin() == null ? Bukkit.getPluginManager().getPlugin("AIServerSetup") : player.getPlugin(),
                () -> {
                    player.setHealth(reviveHp);
                    player.setFireTicks(0);
                    player.getActivePotionEffects().forEach(e2 -> player.removePotionEffect(e2.getType()));
                    player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation(), 60, 0.5, 1, 0.5, 0.1);
                    player.playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1f, 1f);
                    player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize("<gold>✦ Resurrection! You were saved!"));

                    if (burnItem) {
                        var hand = player.getInventory().getItemInMainHand();
                        if (!hand.getType().isAir() && hand.getAmount() > 1) hand.setAmount(hand.getAmount()-1);
                        else player.getInventory().setItemInMainHand(null);
                    }
                }, 1L);
    }
}