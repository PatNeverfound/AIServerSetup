package com.example.aiserversetup.customitems.abilities;

import com.example.aiserversetup.customitems.abilities.impl.*;

import java.util.*;

/**
 * Central registry of ALL 35 built-in abilities.
 * Each ability has an ID, trigger, description, and execute logic.
 */
public class AbilityRegistry {

    private static final Map<String, Ability> REGISTRY = new LinkedHashMap<>();

    static {
        // ── Combat Abilities ────────────────────────────────────────────────
        register(new LightningStrikeAbility());     // lightning_strike
        register(new FireballAbility());             // fireball
        register(new ExplosiveHitAbility());         // explosive_hit
        register(new VampirismAbility());            // vampirism
        register(new FrostbiteAbility());            // frostbite
        register(new KnockbackWaveAbility());        // knockback_wave
        register(new BerserkerAbility());            // berserker
        register(new PoisonCloudAbility());          // poison_cloud
        register(new SoulStealAbility());            // soul_steal
        register(new BlindingStrikeAbility());       // blinding_strike
        register(new ThunderClapAbility());          // thunder_clap
        register(new WitherTouchAbility());          // wither_touch
        register(new InstantKillChanceAbility());    // execute

        // ── Movement Abilities ───────────────────────────────────────────────
        register(new DashAbility());                 // dash
        register(new TeleportBehindAbility());       // shadow_step
        register(new DoubleJumpAbility());           // double_jump
        register(new FlightBoostAbility());          // flight_boost
        register(new BunnyHopAbility());             // bunny_hop
        register(new PhaseAbility());                // phase (walk through walls briefly)

        // ── Utility Abilities ────────────────────────────────────────────────
        register(new HealAbility());                 // heal
        register(new ShieldAbility());               // shield
        register(new InvisibilityAbility());         // invisibility
        register(new FireResistAbility());           // fire_resist
        register(new SpeedBoostAbility());           // speed_boost
        register(new StrengthBoostAbility());        // strength_boost
        register(new NightVisionAbility());          // night_vision
        register(new WaterBreathingAbility());       // water_breathing
        register(new ResurrectionAbility());         // resurrection (auto-revive)

        // ── Area / World Abilities ───────────────────────────────────────────
        register(new TreeFellerAbility());           // tree_feller (chop whole tree)
        register(new VeinMinerAbility());            // vein_miner (mine whole vein)
        register(new AOEMineAbility());              // aoe_mine (3x3 mining)
        register(new PlantAllAbility());             // plant_all (auto plant crops)
        register(new SummonLightningStormAbility()); // lightning_storm (area lightning)
        register(new MagnetAbility());               // magnet (pull dropped items)
        register(new TimeControlAbility());          // time_control (set day/night)
    }

    private static void register(Ability a) { REGISTRY.put(a.getId(), a); }

    public static Ability get(String id)     { return REGISTRY.get(id); }
    public static boolean has(String id)     { return REGISTRY.containsKey(id); }
    public static Collection<Ability> all()  { return REGISTRY.values(); }
    public static Set<String> ids()          { return REGISTRY.keySet(); }

    public static Map<String, List<Ability>> byCategory() {
        Map<String, List<Ability>> map = new LinkedHashMap<>();
        map.put("Combat",   new ArrayList<>());
        map.put("Movement", new ArrayList<>());
        map.put("Utility",  new ArrayList<>());
        map.put("World",    new ArrayList<>());
        for (Ability a : REGISTRY.values()) {
            map.computeIfAbsent(a.getCategory(), k -> new ArrayList<>()).add(a);
        }
        return map;
    }
}