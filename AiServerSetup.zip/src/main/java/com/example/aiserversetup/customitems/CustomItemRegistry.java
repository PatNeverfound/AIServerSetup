package com.example.aiserversetup.customitems;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.google.gson.*;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Stores, loads, and persists all CustomItemDefinitions.
 * JSON-backed per-item files in plugins/AIServerSetup/custom_items/
 */
public class CustomItemRegistry {

    private final AIServerSetupPlugin plugin;
    private final File itemDir;
    private final Map<String, CustomItemDefinition> items = new ConcurrentHashMap<>();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final AtomicInteger nextCMD = new AtomicInteger(10000);

    public CustomItemRegistry(AIServerSetupPlugin plugin) {
        this.plugin  = plugin;
        this.itemDir = new File(plugin.getDataFolder(), "custom_items");
        itemDir.mkdirs();
        loadAll();
    }

    private void loadAll() {
        File[] files = itemDir.listFiles((d, n) -> n.endsWith(".json"));
        if (files == null) return;
        for (File f : files) {
            try {
                String json = Files.readString(f.toPath());
                CustomItemDefinition def = gson.fromJson(json, CustomItemDefinition.class);
                items.put(def.getId(), def);
                if (def.getCustomModelData() >= nextCMD.get()) {
                    nextCMD.set(def.getCustomModelData() + 1);
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to load custom item: " + f.getName() + " — " + e.getMessage());
            }
        }
        plugin.getLogger().info("[CustomItems] Loaded " + items.size() + " custom items.");
    }

    public void save(CustomItemDefinition def) {
        try {
            File f = new File(itemDir, def.getId() + ".json");
            Files.writeString(f.toPath(), gson.toJson(def));
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to save item: " + def.getId() + " — " + e.getMessage());
        }
    }

    public boolean register(CustomItemDefinition def) {
        if (def.getCustomModelData() <= 0) {
            def.setCustomModelData(nextCMD.getAndIncrement());
        }
        items.put(def.getId(), def);
        save(def);
        return true;
    }

    public boolean delete(String id) {
        items.remove(id);
        File f = new File(itemDir, id + ".json");
        return f.exists() && f.delete();
    }

    public CustomItemDefinition get(String id) { return items.get(id); }
    public boolean exists(String id)            { return items.containsKey(id); }
    public Collection<CustomItemDefinition> getAll() { return items.values(); }
    public int size()                           { return items.size(); }
    public int nextCMD()                        { return nextCMD.get(); }
    public Set<String> ids()                    { return items.keySet(); }
}