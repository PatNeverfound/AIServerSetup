package com.example.aiserversetup.customitems.upgrades;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.customitems.*;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * Handles upgrading custom items.
 * Each upgrade improves: ability cooldown reduction, damage bonus,
 * particle effects, stat bonuses. Costs configurable money/items.
 */
public class UpgradeSystem {

    public record UpgradeCost(double money, Map<Material, Integer> items, int expLevels) {}

    private final AIServerSetupPlugin plugin;
    private final Map<Integer, UpgradeCost> costs = new LinkedHashMap<>();

    public UpgradeSystem(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        loadDefaultCosts();
    }

    private void loadDefaultCosts() {
        costs.put(1, new UpgradeCost(1000,  Map.of(Material.IRON_INGOT, 5),   5));
        costs.put(2, new UpgradeCost(2500,  Map.of(Material.GOLD_INGOT, 5),   10));
        costs.put(3, new UpgradeCost(5000,  Map.of(Material.DIAMOND, 3),      15));
        costs.put(4, new UpgradeCost(10000, Map.of(Material.NETHERITE_SCRAP, 2), 20));
        costs.put(5, new UpgradeCost(25000, Map.of(Material.NETHERITE_INGOT, 1), 30));
    }

    public enum UpgradeResult {
        SUCCESS, MAX_LEVEL, CANT_AFFORD, MISSING_ITEMS, ITEM_NOT_CUSTOM, NOT_UPGRADEABLE
    }

    public UpgradeResult upgrade(Player player, ItemStack item) {
        if (!CustomItemBuilder.isCustomItem(item)) return UpgradeResult.ITEM_NOT_CUSTOM;

        String itemId = CustomItemBuilder.getItemId(item);
        CustomItemDefinition def = plugin.getCustomItemRegistry().get(itemId);
        if (def == null) return UpgradeResult.ITEM_NOT_CUSTOM;

        int current = def.getUpgradeLevel();
        int max     = def.getMaxUpgradeLevel();

        if (current >= max) return UpgradeResult.MAX_LEVEL;

        int nextLevel = current + 1;
        UpgradeCost cost = costs.get(nextLevel);
        if (cost == null) return UpgradeResult.MAX_LEVEL;

        // Check economy
        Economy eco = plugin.getIntegrations().getVault() != null ?
                plugin.getIntegrations().getVault().getEconomy() : null;
        if (eco != null && cost.money() > 0) {
            if (!eco.has(player, cost.money())) return UpgradeResult.CANT_AFFORD;
        }

        // Check exp
        if (cost.expLevels() > 0 && player.getLevel() < cost.expLevels()) return UpgradeResult.CANT_AFFORD;

        // Check material costs
        for (Map.Entry<Material, Integer> req : cost.items().entrySet()) {
            if (!hasItems(player, req.getKey(), req.getValue())) return UpgradeResult.MISSING_ITEMS;
        }

        // Deduct costs
        if (eco != null && cost.money() > 0) eco.withdrawPlayer(player, cost.money());
        if (cost.expLevels() > 0) player.setLevel(player.getLevel() - cost.expLevels());
        for (Map.Entry<Material, Integer> req : cost.items().entrySet()) {
            removeItems(player, req.getKey(), req.getValue());
        }

        // Apply upgrade to the item in hand
        def.setUpgradeLevel(nextLevel);
        plugin.getCustomItemRegistry().save(def);
        ItemStack upgraded = CustomItemBuilder.build(def);
        player.getInventory().setItemInMainHand(upgraded);

        // Effects
        player.getWorld().spawnParticle(Particle.ENCHANTMENT_TABLE, player.getLocation(), 50, 0.5, 1, 0.5, 1);
        player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1f, 1.2f);
        player.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<green>✦ " + def.getDisplayName() + " <aqua>upgraded to tier " + nextLevel + "!"));

        return UpgradeResult.SUCCESS;
    }

    public UpgradeCost getCost(int level) { return costs.get(level); }

    public String getCostDisplay(int level) {
        UpgradeCost c = costs.get(level);
        if (c == null) return "N/A";
        StringBuilder sb = new StringBuilder();
        if (c.money() > 0) sb.append("$").append(String.format("%.0f", c.money()));
        if (c.expLevels() > 0) sb.append(" | ").append(c.expLevels()).append(" XP levels");
        for (Map.Entry<Material, Integer> e : c.items().entrySet())
            sb.append(" | ").append(e.getValue()).append("x ").append(e.getKey().name());
        return sb.toString();
    }

    private boolean hasItems(Player p, Material mat, int amount) {
        int count = 0;
        for (ItemStack i : p.getInventory().getContents()) {
            if (i != null && i.getType() == mat) count += i.getAmount();
        }
        return count >= amount;
    }

    private void removeItems(Player p, Material mat, int amount) {
        p.getInventory().removeItem(new ItemStack(mat, amount));
    }
}