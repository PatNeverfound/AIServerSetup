package com.example.aiserversetup.customitems.command;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.customitems.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * /customitems (alias: /ci, /items)
 *
 * Subcommands:
 *   /ci create <description...>        — AI-create item
 *   /ci give <player> <id> [amount]    — give an item
 *   /ci list                           — list all registered items
 *   /ci delete <id>                    — delete an item
 *   /ci info <id>                      — show item details
 *   /ci menu                           — open item creator GUI
 *   /ci pack                           — regenerate resource pack
 *   /ci upgrade                        — upgrade held item
 *   /ci abilities                      — list all available abilities
 *   /ci reload                         — reload items from disk
 *   /ci edit <id>                      — open item editor
 *   /ci texture <id> <base64>          — set item texture from base64 PNG
 */
public class CustomItemCommand implements CommandExecutor, TabCompleter {

    private final AIServerSetupPlugin plugin;

    public CustomItemCommand(AIServerSetupPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player p) plugin.getItemCreatorGUI().openMainMenu(p);
            else listItems(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "create", "c" -> {
                if (args.length < 2) { plugin.getChatUtil().error(sender, "Usage: /ci create <description>"); return true; }
                String desc = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                plugin.getCustomItemManager().createItemWithAI(desc, sender);
            }

            case "give", "g" -> {
                if (args.length < 3) { plugin.getChatUtil().error(sender, "Usage: /ci give <player> <id> [amount]"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { plugin.getChatUtil().error(sender, "Player not found."); return true; }
                String id = args[2];
                int amount = args.length >= 4 ? parseInt(args[3], 1) : 1;
                boolean ok = plugin.getCustomItemManager().giveItem(target, id, amount);
                plugin.getChatUtil().result(sender, ok, "Gave " + amount + "x " + id + " to " + target.getName(), "Item not found: " + id);
            }

            case "list", "l" -> listItems(sender);

            case "delete", "del" -> {
                if (args.length < 2) { plugin.getChatUtil().error(sender, "Usage: /ci delete <id>"); return true; }
                boolean ok = plugin.getCustomItemRegistry().delete(args[1]);
                plugin.getChatUtil().result(sender, ok, "Deleted item: " + args[1], "Item not found: " + args[1]);
            }

            case "info", "i" -> {
                if (args.length < 2) { plugin.getChatUtil().error(sender, "Usage: /ci info <id>"); return true; }
                CustomItemDefinition def = plugin.getCustomItemRegistry().get(args[1]);
                if (def == null) { plugin.getChatUtil().error(sender, "Item not found."); return true; }
                showItemInfo(sender, def);
            }

            case "menu", "m" -> {
                if (!(sender instanceof Player p)) { plugin.getChatUtil().error(sender, "In-game only."); return true; }
                plugin.getItemCreatorGUI().openMainMenu(p);
            }

            case "pack", "p" -> plugin.getCustomItemManager().regeneratePack(sender);

            case "upgrade", "u" -> {
                if (!(sender instanceof Player p)) { plugin.getChatUtil().error(sender, "In-game only."); return true; }
                var result = plugin.getUpgradeSystem().upgrade(p, p.getInventory().getItemInMainHand());
                plugin.getChatUtil().result(sender, result == com.example.aiserversetup.customitems.upgrades.UpgradeSystem.UpgradeResult.SUCCESS,
                        "Upgraded!", "Upgrade failed: " + result.name());
            }

            case "abilities", "a" -> {
                plugin.getChatUtil().header(sender, "Available Abilities");
                for (var cat : com.example.aiserversetup.customitems.abilities.AbilityRegistry.byCategory().entrySet()) {
                    plugin.getChatUtil().sendRaw(sender, "<aqua>" + cat.getKey() + ":");
                    for (var ab : cat.getValue()) {
                        plugin.getChatUtil().sendRaw(sender,
                                "  <yellow>" + ab.getId() + " <gray>— " + ab.getDescription() +
                                " <dark_gray>[trigger: " + ab.getTrigger() + ", cd: " + ab.getDefaultCooldown() + "s]");
                    }
                }
            }

            case "reload", "r" -> {
                plugin.getCustomItemManager().reloadItems();
                plugin.getChatUtil().success(sender, "Custom items reloaded. " + plugin.getCustomItemRegistry().size() + " items loaded.");
            }

            case "edit", "e" -> {
                if (!(sender instanceof Player p)) { plugin.getChatUtil().error(sender, "In-game only."); return true; }
                if (args.length < 2) { plugin.getChatUtil().error(sender, "Usage: /ci edit <id>"); return true; }
                plugin.getItemCreatorGUI().openItemEditor(p, args[1]);
            }

            case "texture", "t" -> {
                if (args.length < 3) { plugin.getChatUtil().error(sender, "Usage: /ci texture <id> <base64>"); return true; }
                CustomItemDefinition def = plugin.getCustomItemRegistry().get(args[1]);
                if (def == null) { plugin.getChatUtil().error(sender, "Item not found."); return true; }
                def.setTextureBase64(args[2]);
                plugin.getCustomItemRegistry().save(def);
                plugin.getChatUtil().success(sender, "Texture set for " + args[1] + ". Run /ci pack to apply.");
            }

            default -> plugin.getChatUtil().error(sender, "Unknown subcommand. Use /ci for help.");
        }
        return true;
    }

    private void listItems(CommandSender sender) {
        plugin.getChatUtil().header(sender, "Custom Items (" + plugin.getCustomItemRegistry().size() + ")");
        for (CustomItemDefinition def : plugin.getCustomItemRegistry().getAll()) {
            plugin.getChatUtil().sendRaw(sender,
                    "  <gray>• <yellow>" + def.getId() +
                    " <gray>(" + def.getRarity() + " " + def.getBaseMaterial().name() + ")" +
                    " <dark_gray>CMD:" + def.getCustomModelData() +
                    " Abilities:" + def.getAbilities().size());
        }
    }

    private void showItemInfo(CommandSender sender, CustomItemDefinition def) {
        plugin.getChatUtil().header(sender, "Item: " + def.getId());
        plugin.getChatUtil().sendRaw(sender, "<gray>Name: <white>" + def.getDisplayName());
        plugin.getChatUtil().sendRaw(sender, "<gray>Material: <white>" + def.getBaseMaterial().name());
        plugin.getChatUtil().sendRaw(sender, "<gray>Rarity: <white>" + def.getRarity());
        plugin.getChatUtil().sendRaw(sender, "<gray>CMD: <white>" + def.getCustomModelData());
        plugin.getChatUtil().sendRaw(sender, "<gray>Upgrade: <white>" + def.getUpgradeLevel() + "/" + def.getMaxUpgradeLevel());
        plugin.getChatUtil().sendRaw(sender, "<gray>Abilities: <yellow>" + def.getAbilities().stream()
                .map(CustomItemDefinition.AbilityEntry::abilityId).reduce((a,b)->a+", "+b).orElse("none"));
        plugin.getChatUtil().sendRaw(sender, "<gray>Created by: <white>" + def.getCreatedBy());
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        if (args.length == 1) return List.of("create","give","list","delete","info","menu","pack","upgrade","abilities","reload","edit","texture");
        if (args.length == 2 && List.of("give","delete","info","edit","texture").contains(args[0].toLowerCase()))
            return new ArrayList<>(plugin.getCustomItemRegistry().ids());
        if (args.length == 2 && "give".equals(args[0].toLowerCase()))
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        return List.of();
    }

    private int parseInt(String s, int def) { try { return Integer.parseInt(s); } catch (Exception e) { return def; } }
}