package com.example.aiserversetup.customitems;

import org.bukkit.Material;

import java.util.*;

/**
 * Full definition of a custom item — stored as JSON, applied as NBT.
 */
public class CustomItemDefinition {

    private String id;               // Unique ID: "storm_blade"
    private String displayName;      // MiniMessage: "<gradient:blue:white>Storm Blade"
    private String description;      // Short lore description
    private Material baseMaterial;   // DIAMOND_SWORD, STICK, etc.
    private int customModelData;     // Resource pack CMD integer
    private List<String> lore;       // Additional lore lines
    private List<AbilityEntry> abilities;    // Bound abilities
    private List<EnchantEntry> customEnchants;
    private int upgradeLevel;        // Current upgrade tier (0 = base)
    private int maxUpgradeLevel;     // Max tier allowed
    private boolean unbreakable;
    private boolean glowing;         // Force enchant glint
    private String rarity;           // COMMON, RARE, EPIC, LEGENDARY, MYTHIC
    private String textureBase64;    // Optional embedded texture (for AI-generated items)
    private String texturePath;      // Relative path in resource pack
    private String modelJson;        // Full model JSON override
    private Map<String, Object> customData; // Freeform persistent data
    private long createdAt;
    private String createdBy;        // Player or "AI"

    public CustomItemDefinition() {
        this.lore          = new ArrayList<>();
        this.abilities     = new ArrayList<>();
        this.customEnchants= new ArrayList<>();
        this.customData    = new HashMap<>();
        this.rarity        = "COMMON";
        this.upgradeLevel  = 0;
        this.maxUpgradeLevel = 5;
        this.unbreakable   = false;
        this.glowing       = false;
        this.createdAt     = System.currentTimeMillis();
        this.createdBy     = "Unknown";
    }

    // ── Nested records ────────────────────────────────────────────────────────

    public record AbilityEntry(String abilityId, Map<String, Object> params) {}
    public record EnchantEntry(String enchantId, int level) {}

    // ── Rarity system ─────────────────────────────────────────────────────────

    public enum Rarity {
        COMMON    ("<gray>",      "§7",  1),
        UNCOMMON  ("<green>",     "§a",  2),
        RARE      ("<aqua>",      "§b",  3),
        EPIC      ("<light_purple>","§d",4),
        LEGENDARY ("<gold>",      "§6",  5),
        MYTHIC    ("<gradient:gold:red>","§c§l", 6),
        DIVINE    ("<gradient:aqua:white>","§f§l",7);

        public final String miniMsg;
        public final String legacy;
        public final int tier;
        Rarity(String m, String l, int t) { miniMsg = m; legacy = l; tier = t; }
    }

    public Rarity getRarityEnum() {
        try { return Rarity.valueOf(rarity.toUpperCase()); }
        catch (Exception e) { return Rarity.COMMON; }
    }

    // ── Getters / Setters ─────────────────────────────────────────────────────
    public String getId()                                  { return id; }
    public void   setId(String id)                         { this.id = id; }
    public String getDisplayName()                         { return displayName; }
    public void   setDisplayName(String displayName)       { this.displayName = displayName; }
    public String getDescription()                         { return description; }
    public void   setDescription(String desc)              { this.description = desc; }
    public Material getBaseMaterial()                      { return baseMaterial; }
    public void   setBaseMaterial(Material m)              { this.baseMaterial = m; }
    public int    getCustomModelData()                     { return customModelData; }
    public void   setCustomModelData(int cmd)              { this.customModelData = cmd; }
    public List<String> getLore()                          { return lore; }
    public void   setLore(List<String> lore)               { this.lore = lore; }
    public List<AbilityEntry> getAbilities()               { return abilities; }
    public void   setAbilities(List<AbilityEntry> a)       { this.abilities = a; }
    public List<EnchantEntry> getCustomEnchants()          { return customEnchants; }
    public void   setCustomEnchants(List<EnchantEntry> e)  { this.customEnchants = e; }
    public int    getUpgradeLevel()                        { return upgradeLevel; }
    public void   setUpgradeLevel(int level)               { this.upgradeLevel = level; }
    public int    getMaxUpgradeLevel()                     { return maxUpgradeLevel; }
    public void   setMaxUpgradeLevel(int max)              { this.maxUpgradeLevel = max; }
    public boolean isUnbreakable()                         { return unbreakable; }
    public void   setUnbreakable(boolean u)                { this.unbreakable = u; }
    public boolean isGlowing()                             { return glowing; }
    public void   setGlowing(boolean g)                    { this.glowing = g; }
    public String getRarity()                              { return rarity; }
    public void   setRarity(String rarity)                 { this.rarity = rarity; }
    public String getTextureBase64()                       { return textureBase64; }
    public void   setTextureBase64(String t)               { this.textureBase64 = t; }
    public String getTexturePath()                         { return texturePath; }
    public void   setTexturePath(String t)                 { this.texturePath = t; }
    public String getModelJson()                           { return modelJson; }
    public void   setModelJson(String m)                   { this.modelJson = m; }
    public Map<String, Object> getCustomData()             { return customData; }
    public void   setCustomData(Map<String, Object> d)     { this.customData = d; }
    public long   getCreatedAt()                           { return createdAt; }
    public void   setCreatedAt(long t)                     { this.createdAt = t; }
    public String getCreatedBy()                           { return createdBy; }
    public void   setCreatedBy(String b)                   { this.createdBy = b; }
}