package com.example.aiserversetup.customitems;

import com.google.gson.Gson;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Converts a CustomItemDefinition into a Bukkit ItemStack.
 * Uses Paper 1.21.4 APIs: editMeta(), editPersistentDataContainer(),
 * direct PDC access via item.getPersistentDataContainer().
 */
public class CustomItemBuilder {

    private static final MiniMessage MM   = MiniMessage.miniMessage();
    private static final Gson        GSON = new Gson();

    public static final NamespacedKey KEY_ITEM_ID       = new NamespacedKey("aiserversetup", "custom_item_id");
    public static final NamespacedKey KEY_ABILITY_JSON  = new NamespacedKey("aiserversetup", "abilities_json");
    public static final NamespacedKey KEY_UPGRADE_LEVEL = new NamespacedKey("aiserversetup", "upgrade_level");
    public static final NamespacedKey KEY_CUSTOM_DATA   = new NamespacedKey("aiserversetup", "custom_data");
    public static final NamespacedKey KEY_ENCHANTS      = new NamespacedKey("aiserversetup", "custom_enchants");
    public static final NamespacedKey KEY_RARITY        = new NamespacedKey("aiserversetup", "rarity");

    private CustomItemBuilder() {}

    // ── Build ─────────────────────────────────────────────────────────────────

    public static ItemStack build(CustomItemDefinition def) {
        ItemStack item = new ItemStack(def.getBaseMaterial());

        // FIX: use editMeta() — Paper 1.21.4 recommended pattern
        item.editMeta(meta -> {
            // Display name
            String rarityPrefix = def.getRarityEnum().miniMsg;
            String name = def.getDisplayName() != null && def.getDisplayName().startsWith("<")
                    ? def.getDisplayName()
                    : rarityPrefix + def.getDisplayName();
            meta.displayName(MM.deserialize(name));

            // Custom model data
            if (def.getCustomModelData() > 0) {
                meta.setCustomModelData(def.getCustomModelData());
            }

            // Unbreakable
            if (def.isUnbreakable()) {
                meta.setUnbreakable(true);
                meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
            }

            // Glowing enchant glint
            if (def.isGlowing()) {
                meta.addEnchant(Enchantment.LUCK_OF_THE_SEA, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }

            // Build lore
            List<net.kyori.adventure.text.Component> lore = buildLore(def);
            meta.lore(lore);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);

            // FIX: write PDC inside editMeta using getPersistentDataContainer()
            var pdc = meta.getPersistentDataContainer();
            pdc.set(KEY_ITEM_ID,       PersistentDataType.STRING,  def.getId());
            pdc.set(KEY_UPGRADE_LEVEL, PersistentDataType.INTEGER, def.getUpgradeLevel());
            pdc.set(KEY_RARITY,        PersistentDataType.STRING,  def.getRarity());

            if (!def.getAbilities().isEmpty()) {
                pdc.set(KEY_ABILITY_JSON, PersistentDataType.STRING, GSON.toJson(def.getAbilities()));
            }
            if (!def.getCustomEnchants().isEmpty()) {
                pdc.set(KEY_ENCHANTS, PersistentDataType.STRING, GSON.toJson(def.getCustomEnchants()));
            }
            if (!def.getCustomData().isEmpty()) {
                pdc.set(KEY_CUSTOM_DATA, PersistentDataType.STRING, GSON.toJson(def.getCustomData()));
            }
        });

        return item;
    }

    // ── Lore builder ─────────────────────────────────────────────────────────

    private static List<net.kyori.adventure.text.Component> buildLore(CustomItemDefinition def) {
        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();

        // Description
        if (def.getDescription() != null && !def.getDescription().isBlank()) {
            lore.add(MM.deserialize("<gray><i>" + def.getDescription() + "</i>"));
            lore.add(MM.deserialize("<dark_gray> "));
        }

        // Custom lore lines
        for (String line : def.getLore()) {
            lore.add(MM.deserialize(line));
        }

        // Abilities section
        if (!def.getAbilities().isEmpty()) {
            lore.add(MM.deserialize("<dark_gray> "));
            lore.add(MM.deserialize("<yellow>⚡ Abilities:"));
            for (CustomItemDefinition.AbilityEntry entry : def.getAbilities()) {
                String cd = entry.params() != null && entry.params().containsKey("cooldown")
                        ? " <dark_gray>(" + entry.params().get("cooldown") + "s cd)" : "";
                lore.add(MM.deserialize("  <gold>• " + formatName(entry.abilityId()) + cd));
            }
        }

        // Custom enchants
        if (!def.getCustomEnchants().isEmpty()) {
            lore.add(MM.deserialize("<dark_gray> "));
            for (CustomItemDefinition.EnchantEntry enc : def.getCustomEnchants()) {
                lore.add(MM.deserialize("<blue>✦ " + formatName(enc.enchantId()) + " " + toRoman(enc.level())));
            }
        }

        // Upgrade level
        if (def.getUpgradeLevel() > 0) {
            lore.add(MM.deserialize("<dark_gray> "));
            lore.add(MM.deserialize("<aqua>⬆ Upgrade: " + def.getUpgradeLevel() + "/" + def.getMaxUpgradeLevel()));
        }

        // Rarity footer
        lore.add(MM.deserialize("<dark_gray> "));
        lore.add(MM.deserialize(def.getRarityEnum().miniMsg + "✦ " + def.getRarityEnum().name()));
        return lore;
    }

    // ── PDC read helpers (Paper 1.21.4 direct item PDC access) ───────────────

    /**
     * Check if an ItemStack is a custom item.
     * Uses direct PDC access on the item (Paper 1.21.4+).
     */
    public static boolean isCustomItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        // Paper 1.21.4: direct PDC access without going through ItemMeta
        return item.getPersistentDataContainer().has(KEY_ITEM_ID, PersistentDataType.STRING);
    }

    /** Get the custom item ID from an ItemStack. Returns null if not a custom item. */
    public static String getItemId(ItemStack item) {
        if (!isCustomItem(item)) return null;
        return item.getPersistentDataContainer().get(KEY_ITEM_ID, PersistentDataType.STRING);
    }

    /** Get the current upgrade level stored in the item. */
    public static int getUpgradeLevel(ItemStack item) {
        if (!isCustomItem(item)) return 0;
        Integer lvl = item.getPersistentDataContainer().get(KEY_UPGRADE_LEVEL, PersistentDataType.INTEGER);
        return lvl == null ? 0 : lvl;
    }

    /** Rebuild the item with an updated upgrade level. */
    public static ItemStack setUpgradeLevel(ItemStack item, int level, CustomItemDefinition def) {
        def.setUpgradeLevel(level);
        return build(def);
    }

    // ── Util ──────────────────────────────────────────────────────────────────

    private static String formatName(String id) {
        if (id == null) return "Unknown";
        return Arrays.stream(id.split("[_\\-]"))
                .filter(s -> !s.isEmpty())
                .map(s -> Character.toUpperCase(s.charAt(0)) + s.substring(1).toLowerCase())
                .collect(Collectors.joining(" "));
    }

    private static String toRoman(int n) {
        return switch (n) {
            case 1 -> "I";   case 2 -> "II";  case 3 -> "III";
            case 4 -> "IV";  case 5 -> "V";   case 6 -> "VI";
            case 7 -> "VII"; case 8 -> "VIII"; case 9 -> "IX";
            case 10 -> "X";  default -> String.valueOf(n);
        };
    }
}