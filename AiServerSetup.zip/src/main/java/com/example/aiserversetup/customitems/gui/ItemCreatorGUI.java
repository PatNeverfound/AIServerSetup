package com.example.aiserversetup.customitems.gui;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.customitems.*;
import com.example.aiserversetup.customitems.abilities.AbilityRegistry;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/**
 * In-game GUI for creating and editing custom items.
 * 54-slot chest GUI with category navigation.
 */
public class ItemCreatorGUI implements Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final AIServerSetupPlugin plugin;
    // Track which player has which item open for editing
    private final Map<UUID, String> editing = new HashMap<>();   // uuid → itemId

    public ItemCreatorGUI(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    // ── Open main creator menu ────────────────────────────────────────────────

    public void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54,
                net.kyori.adventure.text.Component.text("✦ Custom Item Manager"));

        // Header: registered items
        int slot = 0;
        for (CustomItemDefinition def : plugin.getCustomItemRegistry().getAll()) {
            if (slot >= 45) break;
            inv.setItem(slot++, CustomItemBuilder.build(def));
        }

        // Bottom row controls
        inv.setItem(45, buildControl(Material.WRITABLE_BOOK, "<green>✦ Create New Item (AI)", List.of("<gray>Ask AI to create a custom item")));
        inv.setItem(46, buildControl(Material.CRAFTING_TABLE, "<aqua>✦ Create New Item (Manual)", List.of("<gray>Build item step by step")));
        inv.setItem(48, buildControl(Material.CHEST, "<gold>✦ Generate Resource Pack", List.of("<gray>Compile textures & models to ZIP")));
        inv.setItem(49, buildControl(Material.BARRIER, "<red>✦ Delete Selected", List.of("<gray>Click an item then this to delete")));
        inv.setItem(50, buildControl(Material.ANVIL, "<yellow>✦ Upgrade Item", List.of("<gray>Hold an item and click to upgrade")));
        inv.setItem(53, buildControl(Material.ARROW, "<gray>Close", List.of()));

        // Border
        fillBorder(inv, 45);
        player.openInventory(inv);
    }

    // ── Open ability selector ─────────────────────────────────────────────────

    public void openAbilitySelector(Player player, String itemId) {
        Inventory inv = Bukkit.createInventory(null, 54,
                net.kyori.adventure.text.Component.text("⚡ Select Abilities"));
        editing.put(player.getUniqueId(), itemId);

        int slot = 0;
        for (var entry : AbilityRegistry.byCategory().entrySet()) {
            for (var ability : entry.getValue()) {
                if (slot >= 45) break;
                ItemStack icon = new ItemStack(categoryMaterial(entry.getKey()));
                ItemMeta meta = icon.getItemMeta();
                meta.displayName(MM.deserialize("<yellow>⚡ " + ability.getDisplayName()));
                meta.lore(List.of(
                        MM.deserialize("<gray>" + ability.getDescription()),
                        MM.deserialize("<dark_gray>Trigger: <white>" + ability.getTrigger().name()),
                        MM.deserialize("<dark_gray>Default CD: <white>" + ability.getDefaultCooldown() + "s"),
                        MM.deserialize("<dark_gray>Category: <aqua>" + ability.getCategory()),
                        MM.deserialize(""),
                        MM.deserialize("<green>Click to add to item")
                ));
                meta.getPersistentDataContainer().set(
                        new NamespacedKey("aiserversetup", "ability_id"),
                        org.bukkit.persistence.PersistentDataType.STRING, ability.getId());
                icon.setItemMeta(meta);
                inv.setItem(slot++, icon);
            }
        }

        inv.setItem(53, buildControl(Material.ARROW, "<gray>Back", List.of()));
        player.openInventory(inv);
    }

    // ── Click handling ────────────────────────────────────────────────────────

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        String title = e.getView().title().toString();
        if (!title.contains("Custom Item") && !title.contains("Select Abilities") &&
            !title.contains("Upgrade Item")) return;

        e.setCancelled(true);
        if (e.getCurrentItem() == null || e.getCurrentItem().getType() == Material.AIR) return;

        ItemStack clicked = e.getCurrentItem();

        if (title.contains("Custom Item Manager")) {
            handleMainMenuClick(player, clicked, e.getSlot());
        } else if (title.contains("Select Abilities")) {
            handleAbilitySelectorClick(player, clicked);
        }
    }

    private void handleMainMenuClick(Player player, ItemStack clicked, int slot) {
        if (slot == 45) {
            // AI Create
            player.closeInventory();
            player.sendMessage(MM.deserialize("<aqua>[CustomItems] Describe your item in chat (type 'cancel' to stop):"));
            plugin.getChatUtil().listenNextMessage(player, description -> {
                if ("cancel".equalsIgnoreCase(description)) return;
                plugin.getCustomItemManager().createItemWithAI(description, player);
            });
        } else if (slot == 46) {
            // Manual create → open editor
            player.closeInventory();
            openManualCreator(player);
        } else if (slot == 48) {
            // Generate resource pack
            player.closeInventory();
            player.sendMessage(MM.deserialize("<yellow>⏳ Generating resource pack..."));
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                try {
                    java.io.File zip = plugin.getResourcePackGenerator().generate();
                    Bukkit.getScheduler().runTask(plugin, () ->
                            player.sendMessage(MM.deserialize("<green>✔ Resource pack generated: <white>" + zip.getAbsolutePath())));
                } catch (Exception e) {
                    Bukkit.getScheduler().runTask(plugin, () ->
                            player.sendMessage(MM.deserialize("<red>✘ Failed: " + e.getMessage())));
                }
            });
        } else if (slot == 50) {
            // Upgrade
            player.closeInventory();
            ItemStack hand = player.getInventory().getItemInMainHand();
            if (CustomItemBuilder.isCustomItem(hand)) {
                var result = plugin.getUpgradeSystem().upgrade(player, hand);
                if (result != com.example.aiserversetup.customitems.upgrades.UpgradeSystem.UpgradeResult.SUCCESS) {
                    player.sendMessage(MM.deserialize("<red>✘ Upgrade failed: " + result.name()));
                }
            } else {
                player.sendMessage(MM.deserialize("<red>Hold a custom item to upgrade it!"));
            }
        } else if (CustomItemBuilder.isCustomItem(clicked)) {
            // Open item editor
            String id = CustomItemBuilder.getItemId(clicked);
            openItemEditor(player, id);
        }
    }

    private void handleAbilitySelectorClick(Player player, ItemStack clicked) {
        var pdc = clicked.getItemMeta().getPersistentDataContainer();
        NamespacedKey key = new NamespacedKey("aiserversetup", "ability_id");
        if (!pdc.has(key, org.bukkit.persistence.PersistentDataType.STRING)) return;

        String abilityId = pdc.get(key, org.bukkit.persistence.PersistentDataType.STRING);
        String itemId    = editing.get(player.getUniqueId());
        if (itemId == null) return;

        CustomItemDefinition def = plugin.getCustomItemRegistry().get(itemId);
        if (def == null) return;

        // Check if already has ability
        boolean exists = def.getAbilities().stream().anyMatch(a -> a.abilityId().equals(abilityId));
        if (exists) {
            // Remove it
            def.getAbilities().removeIf(a -> a.abilityId().equals(abilityId));
            player.sendMessage(MM.deserialize("<red>✘ Removed ability: " + abilityId));
        } else {
            // Add with defaults
            def.getAbilities().add(new CustomItemDefinition.AbilityEntry(abilityId, new HashMap<>()));
            player.sendMessage(MM.deserialize("<green>✔ Added ability: " + abilityId));
        }

        plugin.getCustomItemRegistry().save(def);
        player.closeInventory();
        openItemEditor(player, itemId);
    }

    // ── Item editor view ──────────────────────────────────────────────────────

    public void openItemEditor(Player player, String itemId) {
        CustomItemDefinition def = plugin.getCustomItemRegistry().get(itemId);
        if (def == null) return;

        Inventory inv = Bukkit.createInventory(null, 54,
                net.kyori.adventure.text.Component.text("✦ Edit: " + itemId));

        // Preview (center)
        inv.setItem(13, CustomItemBuilder.build(def));

        // Ability list
        int slot = 18;
        for (CustomItemDefinition.AbilityEntry entry : def.getAbilities()) {
            var ab = com.example.aiserversetup.customitems.abilities.AbilityRegistry.get(entry.abilityId());
            if (ab == null) continue;
            ItemStack icon = buildControl(Material.BLAZE_POWDER, "<yellow>" + ab.getDisplayName(),
                    List.of("<gray>" + ab.getDescription(), "", "<red>Click to remove"));
            icon.getItemMeta().getPersistentDataContainer().set(
                    new NamespacedKey("aiserversetup", "remove_ability"),
                    org.bukkit.persistence.PersistentDataType.STRING, entry.abilityId());
            inv.setItem(slot++, icon);
        }

        // Controls
        inv.setItem(45, buildControl(Material.BLAZE_POWDER, "<aqua>Add/Remove Abilities",
                List.of("<gray>Select abilities for this item")));
        inv.setItem(46, buildControl(Material.ANVIL, "<yellow>Upgrade (" + def.getUpgradeLevel() + "/" + def.getMaxUpgradeLevel() + ")",
                List.of("<gray>" + plugin.getUpgradeSystem().getCostDisplay(def.getUpgradeLevel()+1))));
        inv.setItem(47, buildControl(Material.PAPER, "<green>Give to Self",
                List.of("<gray>Add this item to your inventory")));
        inv.setItem(48, buildControl(Material.NAME_TAG, "<aqua>Rename (AI)",
                List.of("<gray>AI renames & improves the lore")));
        inv.setItem(49, buildControl(Material.BARRIER, "<red>Delete Item",
                List.of("<red>Permanently delete this item definition")));
        inv.setItem(53, buildControl(Material.ARROW, "<gray>Back", List.of()));

        fillBorder(inv, 45);
        editing.put(player.getUniqueId(), itemId);
        player.openInventory(inv);
    }

    public void openManualCreator(Player player) {
        // A simplified chat-driven creator
        player.sendMessage(MM.deserialize("<aqua>--- Custom Item Creator ---"));
        player.sendMessage(MM.deserialize("<yellow>Enter item ID (e.g. storm_blade):"));
        plugin.getChatUtil().listenNextMessage(player, id -> {
            id = id.toLowerCase().replaceAll("[^a-z0-9_]", "_");
            if (plugin.getCustomItemRegistry().exists(id)) {
                player.sendMessage(MM.deserialize("<red>Item ID already exists!"));
                return;
            }
            final String finalId = id;
            player.sendMessage(MM.deserialize("<yellow>Enter display name (MiniMessage supported):"));
            plugin.getChatUtil().listenNextMessage(player, displayName -> {
                player.sendMessage(MM.deserialize("<yellow>Enter base material (e.g. DIAMOND_SWORD):"));
                plugin.getChatUtil().listenNextMessage(player, matStr -> {
                    try {
                        Material mat = Material.valueOf(matStr.toUpperCase());
                        player.sendMessage(MM.deserialize("<yellow>Enter rarity (COMMON/UNCOMMON/RARE/EPIC/LEGENDARY/MYTHIC/DIVINE):"));
                        plugin.getChatUtil().listenNextMessage(player, rarityStr -> {
                            CustomItemDefinition def = new CustomItemDefinition();
                            def.setId(finalId);
                            def.setDisplayName(displayName);
                            def.setBaseMaterial(mat);
                            def.setRarity(rarityStr.toUpperCase());
                            def.setCreatedBy(player.getName());
                            plugin.getCustomItemRegistry().register(def);
                            player.sendMessage(MM.deserialize("<green>✔ Item created! Opening editor..."));
                            Bukkit.getScheduler().runTaskLater(plugin,
                                    () -> openItemEditor(player, finalId), 2L);
                        });
                    } catch (Exception e) {
                        player.sendMessage(MM.deserialize("<red>Invalid material!"));
                    }
                });
            });
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private ItemStack buildControl(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta  meta = item.getItemMeta();
        meta.displayName(MM.deserialize(name));
        meta.lore(lore.stream().map(MM::deserialize).toList());
        item.setItemMeta(meta);
        return item;
    }

    private void fillBorder(Inventory inv, int stopRow) {
        ItemStack glass = buildControl(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = stopRow; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) inv.setItem(i, glass);
        }
    }

    private Material categoryMaterial(String cat) {
        return switch (cat) {
            case "Combat"   -> Material.DIAMOND_SWORD;
            case "Movement" -> Material.FEATHER;
            case "Utility"  -> Material.TOTEM_OF_UNDYING;
            case "World"    -> Material.GRASS_BLOCK;
            default         -> Material.NETHER_STAR;
        };
    }
}