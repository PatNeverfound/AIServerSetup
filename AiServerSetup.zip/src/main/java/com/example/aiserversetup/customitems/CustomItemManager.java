package com.example.aiserversetup.customitems;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.google.gson.*;
import org.bukkit.*;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * High-level manager — AI-driven item creation, give, reload, regenerate pack.
 */
public class CustomItemManager {

    private final AIServerSetupPlugin plugin;
    private final Gson gson = new Gson();

    public CustomItemManager(AIServerSetupPlugin plugin) { this.plugin = plugin; }

    /**
     * Ask the AI to create a full CustomItemDefinition from a natural language description.
     * The AI returns a JSON object which we parse directly into a definition.
     */
    public void createItemWithAI(String description, CommandSender sender) {
        plugin.getChatUtil().sendRaw(sender, "<yellow>⏳ AI is designing your item: " + description + "...</yellow>");

        String abilitiesList = String.join(", ", com.example.aiserversetup.customitems.abilities.AbilityRegistry.ids());
        int nextCMD = plugin.getCustomItemRegistry().nextCMD();

        String prompt = """
            Design a Minecraft custom item for this description: """ + description + """
            
            Available abilities: """ + abilitiesList + """
            
            Return ONLY a valid JSON object with these exact fields (no explanation, no markdown):
            {
              "id": "snake_case_unique_id",
              "displayName": "<gradient:color1:color2>Name or simple name",
              "description": "Short lore description",
              "baseMaterial": "MATERIAL_NAME",
              "rarity": "COMMON|UNCOMMON|RARE|EPIC|LEGENDARY|MYTHIC|DIVINE",
              "customModelData": """ + nextCMD + """,
              "lore": ["<color>Lore line 1", "<color>Lore line 2"],
              "abilities": [
                {"abilityId": "ability_id", "params": {"cooldown": 10, "power": 1.5}}
              ],
              "customEnchants": [
                {"enchantId": "sharpness_boost", "level": 3}
              ],
              "unbreakable": true,
              "glowing": false,
              "maxUpgradeLevel": 5,
              "createdBy": "AI"
            }
            
            Rules:
            - id must be unique snake_case, max 30 chars
            - baseMaterial must be a valid Bukkit Material name
            - Choose 1-3 abilities that make sense for the item description
            - rarity must match the power level of the item
            - lore lines should use MiniMessage color tags
            - params should have realistic values (cooldown 5-30, power 0.5-3.0)
            - Return ONLY the JSON, nothing else
            """;

        plugin.getAiClient().chat(List.of(Map.of("role", "user", "content", prompt)))
                .thenAccept(response -> {
                    Bukkit.getScheduler().runTask(plugin, () -> {
                        try {
                            String json = response.content().strip();
                            // Strip markdown if present
                            if (json.startsWith("```")) {
                                json = json.replaceAll("^```[a-z]*\\n?", "").replaceAll("```$", "").strip();
                            }

                            CustomItemDefinition def = gson.fromJson(json, CustomItemDefinition.class);

                            // Validate
                            if (def.getId() == null || def.getBaseMaterial() == null) {
                                plugin.getChatUtil().error(sender, "AI returned an invalid item definition.");
                                return;
                            }

                            // Ensure ID is unique
                            String baseId = def.getId();
                            int suffix = 1;
                            while (plugin.getCustomItemRegistry().exists(def.getId())) {
                                def.setId(baseId + "_" + suffix++);
                            }

                            // Register and save
                            plugin.getCustomItemRegistry().register(def);

                            // Show result
                            if (sender instanceof Player p) {
                                p.getInventory().addItem(CustomItemBuilder.build(def));
                                plugin.getChatUtil().success(sender,
                                        "✔ Created item: <white>" + def.getDisplayName() +
                                        " <gray>(id: " + def.getId() + ", CMD: " + def.getCustomModelData() + ")");
                                plugin.getChatUtil().info(sender,
                                        "Abilities: <yellow>" + def.getAbilities().stream()
                                                .map(CustomItemDefinition.AbilityEntry::abilityId)
                                                .reduce((a, b) -> a + ", " + b).orElse("none"));
                                plugin.getChatUtil().info(sender,
                                        "Run <aqua>/customitems pack</aqua> to regenerate the resource pack!");
                            } else {
                                plugin.getChatUtil().success(sender, "Item created: " + def.getId());
                            }

                        } catch (Exception e) {
                            plugin.getChatUtil().error(sender, "Failed to parse AI item: " + e.getMessage());
                            plugin.getLogger().warning("AI item JSON parse error: " + e.getMessage() + "\nRaw: " + response.content());
                        }
                    });
                });
    }

    /** Give a registered custom item to a player. */
    public boolean giveItem(Player player, String itemId, int amount) {
        CustomItemDefinition def = plugin.getCustomItemRegistry().get(itemId);
        if (def == null) return false;
        org.bukkit.inventory.ItemStack item = CustomItemBuilder.build(def);
        item.setAmount(amount);
        player.getInventory().addItem(item);
        return true;
    }

    /** Reload all items from disk. */
    public void reloadItems() { plugin.getCustomItemRegistry().getAll().forEach(d -> {}); }

    /** Regenerate and optionally host the resource pack. */
    public void regeneratePack(CommandSender sender) {
        sender.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<yellow>⏳ Regenerating resource pack..."));
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                java.io.File zip = plugin.getResourcePackGenerator().generate();
                Bukkit.getScheduler().runTask(plugin, () ->
                        plugin.getChatUtil().success(sender,
                                "✔ Resource pack: <white>" + zip.getAbsolutePath() +
                                " <gray>(" + zip.length()/1024 + "KB)"));
            } catch (Exception e) {
                Bukkit.getScheduler().runTask(plugin, () ->
                        plugin.getChatUtil().error(sender, "Pack generation failed: " + e.getMessage()));
            }
        });
    }
}