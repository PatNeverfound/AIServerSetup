package com.example.aiserversetup.customitems.abilities.impl;

import com.example.aiserversetup.customitems.abilities.Ability;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockBreakEvent;

import java.util.*;

public class VeinMinerAbility implements Ability {
    @Override public String getId()          { return "vein_miner"; }
    @Override public String getDisplayName() { return "Vein Miner"; }
    @Override public String getDescription(){ return "Mine an entire ore vein at once"; }
    @Override public String getCategory()   { return "World"; }
    @Override public Trigger getTrigger()   { return Trigger.BLOCK_BREAK; }
    @Override public int getDefaultCooldown(){ return 3; }

    private static final Set<Material> ORES = Set.of(
            Material.COAL_ORE, Material.DEEPSLATE_COAL_ORE,
            Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE,
            Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE,
            Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE,
            Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE,
            Material.LAPIS_ORE, Material.DEEPSLATE_LAPIS_ORE,
            Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE,
            Material.NETHER_QUARTZ_ORE, Material.ANCIENT_DEBRIS,
            Material.COPPER_ORE, Material.DEEPSLATE_COPPER_ORE
    );

    @Override
    public void execute(Player player, Map<String, Object> params, Event event) {
        if (!(event instanceof BlockBreakEvent bbe)) return;
        Block origin = bbe.getBlock();
        if (!ORES.contains(origin.getType())) return;

        int maxBlocks = params.containsKey("max_blocks") ? ((Number)params.get("max_blocks")).intValue() : 64;
        Material type = origin.getType();
        Set<Block> toBreak = new HashSet<>();
        Queue<Block> queue = new LinkedList<>();
        queue.add(origin);

        while (!queue.isEmpty() && toBreak.size() < maxBlocks) {
            Block b = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        Block adj = b.getRelative(dx, dy, dz);
                        if (adj.getType() == type && !toBreak.contains(adj)) {
                            toBreak.add(adj);
                            queue.add(adj);
                        }
                    }
                }
            }
        }

        for (Block b : toBreak) {
            b.getWorld().spawnParticle(Particle.CRIT_MAGIC, b.getLocation().add(0.5,0.5,0.5), 3);
            b.breakNaturally(player.getInventory().getItemInMainHand());
        }
        player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<green>⛏ Vein Miner: +" + toBreak.size() + " blocks!"));
    }
}