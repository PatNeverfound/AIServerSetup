package com.example.aiserversetup.customitems.abilities.impl;

import com.example.aiserversetup.customitems.abilities.Ability;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.util.Vector;

import java.util.Map;

public class DashAbility implements Ability {
    @Override public String getId()          { return "dash"; }
    @Override public String getDisplayName() { return "Dash"; }
    @Override public String getDescription(){ return "Launches you forward at high speed"; }
    @Override public String getCategory()   { return "Movement"; }
    @Override public Trigger getTrigger()   { return Trigger.SNEAK; }
    @Override public int getDefaultCooldown(){ return 5; }

    @Override
    public void execute(Player player, Map<String, Object> params, Event event) {
        double power = params.containsKey("power") ? ((Number)params.get("power")).doubleValue() : 1.8;
        Vector dir = player.getEyeLocation().getDirection().normalize().multiply(power);
        dir.setY(0.3);
        player.setVelocity(dir);
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 20, 0.2, 0.1, 0.2, 0.05);
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5f, 1.5f);
        player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<aqua>💨 Dash!"));
    }
}