package com.example.aiserversetup.customitems.abilities;

import java.util.*;
import java.util.concurrent.*;

public class CooldownManager {

    // uuid → (abilityId → expiryTimeMs)
    private final Map<UUID, Map<String, Long>> data = new ConcurrentHashMap<>();

    public void setCooldown(UUID uuid, String abilityId, int seconds) {
        data.computeIfAbsent(uuid, k -> new ConcurrentHashMap<>())
                .put(abilityId, System.currentTimeMillis() + (seconds * 1000L));
    }

    public boolean isReady(UUID uuid, String abilityId) {
        Map<String, Long> m = data.get(uuid);
        if (m == null) return true;
        Long expiry = m.get(abilityId);
        return expiry == null || System.currentTimeMillis() >= expiry;
    }

    public long getRemaining(UUID uuid, String abilityId) {
        Map<String, Long> m = data.get(uuid);
        if (m == null) return 0;
        Long expiry = m.get(abilityId);
        if (expiry == null) return 0;
        long rem = (expiry - System.currentTimeMillis()) / 1000;
        return Math.max(0, rem);
    }

    public void clearCooldowns(UUID uuid) { data.remove(uuid); }

    public Map<String, Long> getCooldowns(UUID uuid) {
        return data.getOrDefault(uuid, Map.of());
    }
}