package com.example.aiserversetup.customitems.abilities.impl;

import com.example.aiserversetup.customitems.abilities.Ability;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.Event;
import org.bukkit.util.Vector;

import java.util.Map;

public class FireballAbility implements Ability {
    @Override public String getId()          { return "fireball"; }
    @Override public String getDisplayName() { return "Fireball Launch"; }
    @Override public String getDescription(){ return "Launches a massive fireball"; }
    @Override public String getCategory()   { return "Combat"; }
    @Override public Trigger getTrigger()   { return Trigger.RIGHT_CLICK; }
    @Override public int getDefaultCooldown(){ return 8; }

    @Override
    public void execute(Player player, Map<String, Object> params, Event event) {
        int yield = params.containsKey("yield") ? ((Number)params.get("yield")).intValue() : 3;
        Vector dir = player.getEyeLocation().getDirection().multiply(2);
        Fireball fb = player.launchProjectile(Fireball.class, dir);
        fb.setYield(yield);
        fb.setIsIncendiary(true);
        player.getWorld().spawnParticle(Particle.FLAME, player.getEyeLocation(), 10, 0.1, 0.1, 0.1, 0.1);
        player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<red>🔥 Fireball!"));
    }
}