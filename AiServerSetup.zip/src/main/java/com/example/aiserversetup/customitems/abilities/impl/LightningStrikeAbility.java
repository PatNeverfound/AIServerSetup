package com.example.aiserversetup.customitems.abilities.impl;

import com.example.aiserversetup.customitems.abilities.Ability;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.Event;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Map;

public class LightningStrikeAbility implements Ability {
    @Override public String getId()          { return "lightning_strike"; }
    @Override public String getDisplayName() { return "Lightning Strike"; }
    @Override public String getDescription(){ return "Calls lightning at your target"; }
    @Override public String getCategory()   { return "Combat"; }
    @Override public Trigger getTrigger()   { return Trigger.RIGHT_CLICK; }
    @Override public int getDefaultCooldown(){ return 10; }

    @Override
    public void execute(Player player, Map<String, Object> params, Event event) {
        int range = params.containsKey("range") ? ((Number)params.get("range")).intValue() : 20;
        Entity target = getTarget(player, range);
        Location loc  = target != null ? target.getLocation() : player.getTargetBlock(null, range).getLocation();
        loc.getWorld().strikeLightning(loc);
        player.getWorld().spawnParticle(Particle.FLASH, player.getLocation(), 1);
        player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize("<yellow>⚡ Lightning Strike!"));
    }

    private Entity getTarget(Player player, int range) {
        for (Entity e : player.getNearbyEntities(range, range, range)) {
            if (e instanceof LivingEntity && !e.equals(player)) return e;
        }
        return null;
    }
}