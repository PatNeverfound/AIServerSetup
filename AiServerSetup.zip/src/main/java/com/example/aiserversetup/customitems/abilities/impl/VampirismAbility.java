package com.example.aiserversetup.customitems.abilities.impl;

import com.example.aiserversetup.customitems.abilities.Ability;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import java.util.Map;

public class VampirismAbility implements Ability {
    @Override public String getId()          { return "vampirism"; }
    @Override public String getDisplayName() { return "Vampirism"; }
    @Override public String getDescription(){ return "Steal life on every hit"; }
    @Override public String getCategory()   { return "Combat"; }
    @Override public Trigger getTrigger()   { return Trigger.HIT_ENTITY; }
    @Override public int getDefaultCooldown(){ return 0; } // No cooldown — passive

    @Override
    public void execute(Player player, Map<String, Object> params, Event event) {
        double steal = params.containsKey("amount") ? ((Number)params.get("amount")).doubleValue() : 2.0;
        double newHp = Math.min(player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue(),
                player.getHealth() + steal);
        player.setHealth(newHp);
        player.getWorld().spawnParticle(Particle.HEART, player.getLocation().add(0,1,0), 3);
    }
}