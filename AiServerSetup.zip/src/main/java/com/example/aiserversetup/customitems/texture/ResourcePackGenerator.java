package com.example.aiserversetup.customitems.texture;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.customitems.CustomItemDefinition;
import com.example.aiserversetup.customitems.CustomItemRegistry;
import com.google.gson.*;
import org.bukkit.Material;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Generates a full Minecraft resource pack from all registered custom items.
 * Handles: pack.mcmeta, model JSON overrides, texture placement, pack zipping,
 * and automatic server resource-pack URL update.
 *
 * Resource pack structure:
 *   custom_items_pack/
 *     pack.mcmeta
 *     pack.png
 *     assets/minecraft/models/item/{base_material}.json  ← CMD overrides
 *     assets/minecraft/models/item/custom/{item_id}.json ← custom models
 *     assets/minecraft/textures/item/custom/{item_id}.png
 */
public class ResourcePackGenerator {

    private static final int PACK_FORMAT = 34; // 1.21.x

    private final AIServerSetupPlugin plugin;
    private final File packDir;
    private final File packZip;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public ResourcePackGenerator(AIServerSetupPlugin plugin) {
        this.plugin  = plugin;
        this.packDir = new File(plugin.getDataFolder(), "resource_pack");
        this.packZip = new File(plugin.getDataFolder(), "custom_items_pack.zip");
    }

    /**
     * Full pack generation pipeline:
     * 1. Write pack.mcmeta
     * 2. For each registered custom item: write model JSON + texture
     * 3. Write per-material override JSON files
     * 4. ZIP the result
     * 5. Return path to the ZIP
     */
    public File generate() throws IOException {
        plugin.getLogger().info("[CustomItems] Generating resource pack...");

        // Clean old pack
        if (packDir.exists()) deleteDir(packDir);
        packDir.mkdirs();

        writeMcmeta();
        writePackIcon();

        Map<Material, List<CustomItemDefinition>> byMaterial = new HashMap<>();
        for (CustomItemDefinition def : plugin.getCustomItemRegistry().getAll()) {
            byMaterial.computeIfAbsent(def.getBaseMaterial(), k -> new ArrayList<>()).add(def);
            writeItemModel(def);
            writeItemTexture(def);
        }

        // Write material override files (combine all CMD entries per base material)
        for (Map.Entry<Material, List<CustomItemDefinition>> entry : byMaterial.entrySet()) {
            writeMaterialOverride(entry.getKey(), entry.getValue());
        }

        // Zip
        zipDirectory(packDir, packZip);
        plugin.getLogger().info("[CustomItems] Resource pack generated: " + packZip.getAbsolutePath());
        return packZip;
    }

    // ── pack.mcmeta ──────────────────────────────────────────────────────────

    private void writeMcmeta() throws IOException {
        JsonObject pack = new JsonObject();
        pack.addProperty("pack_format", PACK_FORMAT);
        pack.addProperty("description", "§6Custom Items §7| §bAIServerSetup");
        JsonObject root = new JsonObject();
        root.add("pack", pack);
        write(new File(packDir, "pack.mcmeta"), gson.toJson(root));
    }

    private void writePackIcon() throws IOException {
        // Write a simple 64x64 placeholder PNG (purple gradient)
        java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(64, 64, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g = img.createGraphics();
        g.setPaint(new java.awt.GradientPaint(0, 0, new java.awt.Color(128, 0, 255),
                64, 64, new java.awt.Color(0, 128, 255)));
        g.fillRect(0, 0, 64, 64);
        g.setColor(java.awt.Color.WHITE);
        g.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 10));
        g.drawString("Custom", 8, 28);
        g.drawString("Items", 12, 42);
        g.dispose();
        File out = new File(packDir, "pack.png");
        javax.imageio.ImageIO.write(img, "PNG", out);
    }

    // ── Item model JSON ──────────────────────────────────────────────────────

    private void writeItemModel(CustomItemDefinition def) throws IOException {
        File modelDir = new File(packDir, "assets/minecraft/models/item/custom");
        modelDir.mkdirs();

        String modelJson = def.getModelJson();
        if (modelJson == null || modelJson.isBlank()) {
            // Auto-generate a simple layered model
            modelJson = buildDefaultModel(def);
        }

        write(new File(modelDir, def.getId() + ".json"), modelJson);
    }

    private String buildDefaultModel(CustomItemDefinition def) {
        // Determine parent model type based on material
        String parent = isHandheld(def.getBaseMaterial()) ? "item/handheld" : "item/generated";
        JsonObject model = new JsonObject();
        model.addProperty("parent", parent);
        JsonObject textures = new JsonObject();
        textures.addProperty("layer0", "minecraft:item/custom/" + def.getId());
        model.add("textures", textures);
        return gson.toJson(model);
    }

    private boolean isHandheld(Material m) {
        return m != null && (m.name().contains("SWORD") || m.name().contains("AXE") ||
                m.name().contains("PICKAXE") || m.name().contains("SHOVEL") ||
                m.name().contains("HOE") || m.name().contains("BOW") ||
                m.name().contains("TRIDENT") || m.name().contains("STICK"));
    }

    // ── Material override (CMD predicates) ───────────────────────────────────

    private void writeMaterialOverride(Material mat, List<CustomItemDefinition> defs) throws IOException {
        File overrideDir = new File(packDir, "assets/minecraft/models/item");
        overrideDir.mkdirs();

        // Sort by CMD
        defs.sort(Comparator.comparingInt(CustomItemDefinition::getCustomModelData));

        JsonObject model = new JsonObject();
        model.addProperty("parent", isHandheld(mat) ? "item/handheld" : "item/generated");

        JsonObject textures = new JsonObject();
        textures.addProperty("layer0", "minecraft:item/" + mat.name().toLowerCase());
        model.add("textures", textures);

        JsonArray overrides = new JsonArray();
        for (CustomItemDefinition def : defs) {
            if (def.getCustomModelData() <= 0) continue;
            JsonObject predObj = new JsonObject();
            JsonObject pred = new JsonObject();
            pred.addProperty("custom_model_data", def.getCustomModelData());
            predObj.add("predicate", pred);
            predObj.addProperty("model", "minecraft:item/custom/" + def.getId());
            overrides.add(predObj);
        }
        model.add("overrides", overrides);

        write(new File(overrideDir, mat.name().toLowerCase() + ".json"), gson.toJson(model));
    }

    // ── Textures ─────────────────────────────────────────────────────────────

    private void writeItemTexture(CustomItemDefinition def) throws IOException {
        File texDir = new File(packDir, "assets/minecraft/textures/item/custom");
        texDir.mkdirs();
        File texFile = new File(texDir, def.getId() + ".png");

        // If base64 texture was provided (AI-generated), use it
        if (def.getTextureBase64() != null && !def.getTextureBase64().isBlank()) {
            byte[] data = Base64.getDecoder().decode(def.getTextureBase64());
            Files.write(texFile.toPath(), data);
            return;
        }

        // If a texture file path was provided, copy it
        if (def.getTexturePath() != null && !def.getTexturePath().isBlank()) {
            File src = new File(def.getTexturePath());
            if (src.exists()) { Files.copy(src.toPath(), texFile.toPath()); return; }
        }

        // Auto-generate a procedural texture based on rarity + name
        generateProceduralTexture(def, texFile);
    }

    /**
     * Generates a 16x16 pixel texture procedurally based on the item's rarity and ID.
     * This is a placeholder — real textures should be replaced with actual art.
     */
    private void generateProceduralTexture(CustomItemDefinition def, File out) throws IOException {
        java.awt.image.BufferedImage img = new java.awt.image.BufferedImage(16, 16,
                java.awt.image.BufferedImage.TYPE_INT_ARGB);
        java.awt.Graphics2D g = img.createGraphics();

        // Rarity-based gradient colors
        java.awt.Color c1, c2;
        switch (def.getRarityEnum()) {
            case COMMON    -> { c1 = new java.awt.Color(180,180,180); c2 = new java.awt.Color(100,100,100); }
            case UNCOMMON  -> { c1 = new java.awt.Color(80,220,80);   c2 = new java.awt.Color(0,120,0); }
            case RARE      -> { c1 = new java.awt.Color(80,180,255);  c2 = new java.awt.Color(0,80,200); }
            case EPIC      -> { c1 = new java.awt.Color(200,80,255);  c2 = new java.awt.Color(100,0,180); }
            case LEGENDARY -> { c1 = new java.awt.Color(255,180,0);   c2 = new java.awt.Color(200,80,0); }
            case MYTHIC    -> { c1 = new java.awt.Color(255,50,50);   c2 = new java.awt.Color(180,0,100); }
            case DIVINE    -> { c1 = new java.awt.Color(255,255,255); c2 = new java.awt.Color(100,220,255); }
            default        -> { c1 = java.awt.Color.GRAY;             c2 = java.awt.Color.DARK_GRAY; }
        }

        // Background gradient
        g.setPaint(new java.awt.GradientPaint(0, 0, c1, 16, 16, c2));
        g.fillRect(0, 0, 16, 16);

        // Draw a simple item silhouette based on material type
        g.setColor(new java.awt.Color(255,255,255,160));
        String mat = def.getBaseMaterial().name();
        if (mat.contains("SWORD")) {
            g.fillRect(7, 1, 2, 10);  // blade
            g.fillRect(4, 9, 8, 2);   // guard
            g.fillRect(7, 11, 2, 3);  // handle
        } else if (mat.contains("PICKAXE")) {
            g.fillRect(2, 4, 12, 2);  // head
            g.fillRect(7, 6, 2, 8);   // handle
        } else if (mat.contains("AXE")) {
            g.fillRect(3, 2, 6, 6);   // head
            g.fillRect(7, 8, 2, 6);   // handle
        } else if (mat.contains("BOW")) {
            g.drawArc(4, 1, 8, 14, 0, 180);
            g.fillRect(7, 1, 2, 14);  // string
        } else {
            // Generic orb/gem shape
            g.fillOval(4, 4, 8, 8);
        }

        // Glint overlay for high rarity
        if (def.getRarityEnum().tier >= 4) {
            g.setColor(new java.awt.Color(255,255,255,40));
            g.fillRect(0, 0, 16, 4);
            g.fillRect(0, 0, 4, 16);
        }

        g.dispose();
        javax.imageio.ImageIO.write(img, "PNG", out);
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private void write(File f, String content) throws IOException {
        f.getParentFile().mkdirs();
        Files.writeString(f.toPath(), content);
    }

    private void deleteDir(File dir) {
        File[] files = dir.listFiles();
        if (files != null) for (File f : files) { if (f.isDirectory()) deleteDir(f); else f.delete(); }
        dir.delete();
    }

    private void zipDirectory(File srcDir, File zipFile) throws IOException {
        if (zipFile.exists()) zipFile.delete();
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            zipDir(srcDir, srcDir.getName(), zos);
        }
    }

    private void zipDir(File dir, String base, ZipOutputStream zos) throws IOException {
        for (File f : Objects.requireNonNull(dir.listFiles())) {
            if (f.isDirectory()) {
                zipDir(f, base + "/" + f.getName(), zos);
            } else {
                zos.putNextEntry(new ZipEntry(base + "/" + f.getName()));
                Files.copy(f.toPath(), zos);
                zos.closeEntry();
            }
        }
    }

    public File getPackZip() { return packZip; }
}