package com.example.aiserversetup.customitems.abilities;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.customitems.CustomItemBuilder;
import com.example.aiserversetup.customitems.CustomItemDefinition;
import com.example.aiserversetup.customitems.CustomItemRegistry;
import com.google.gson.*;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;

import java.lang.reflect.Type;
import java.util.*;

/**
 * Listens to all Bukkit events and routes them to the correct ability.
 */
public class AbilityExecutor implements Listener {

    private final AIServerSetupPlugin plugin;
    private final CooldownManager cooldowns;
    private final Gson gson = new Gson();

    public AbilityExecutor(AIServerSetupPlugin plugin) {
        this.plugin    = plugin;
        this.cooldowns = new CooldownManager();
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    // ── Right click ──────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getItem() == null) return;
        if (e.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_AIR ||
            e.getAction() == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) {
            fireAbilities(e.getPlayer(), e.getItem(), Ability.Trigger.RIGHT_CLICK, e);
        }
        if (e.getAction() == org.bukkit.event.block.Action.LEFT_CLICK_AIR ||
            e.getAction() == org.bukkit.event.block.Action.LEFT_CLICK_BLOCK) {
            fireAbilities(e.getPlayer(), e.getItem(), Ability.Trigger.LEFT_CLICK, e);
        }
    }

    // ── Hit entity ───────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        fireAbilities(p, p.getInventory().getItemInMainHand(), Ability.Trigger.HIT_ENTITY, e);
    }

    // ── Take damage ──────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTakeDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        // Check all equipped items
        for (ItemStack item : getEquippedItems(p)) {
            fireAbilities(p, item, Ability.Trigger.TAKE_DAMAGE, e);
        }
    }

    // ── Block break ──────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        fireAbilities(e.getPlayer(), e.getPlayer().getInventory().getItemInMainHand(),
                Ability.Trigger.BLOCK_BREAK, e);
    }

    // ── Block place ──────────────────────────────────────────────────────────
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        fireAbilities(e.getPlayer(), e.getPlayer().getInventory().getItemInMainHand(),
                Ability.Trigger.BLOCK_PLACE, e);
    }

    // ── Kill entity ──────────────────────────────────────────────────────────
    @EventHandler
    public void onKill(EntityDeathEvent e) {
        if (e.getEntity().getKiller() == null) return;
        Player p = e.getEntity().getKiller();
        fireAbilities(p, p.getInventory().getItemInMainHand(), Ability.Trigger.KILL_ENTITY, e);
    }

    // ── Player death ─────────────────────────────────────────────────────────
    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        // Check all equipped items
        for (ItemStack item : getEquippedItems(p)) {
            fireAbilities(p, item, Ability.Trigger.DEATH, e);
        }
    }

    // ── Sneak toggle ──────────────────────────────────────────────────────────
    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (!e.isSneaking()) return;
        fireAbilities(e.getPlayer(), e.getPlayer().getInventory().getItemInMainHand(),
                Ability.Trigger.SNEAK, e);
    }

    // ── Passive tick (every 1s) ───────────────────────────────────────────────
    public void startPassiveTick() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                for (ItemStack item : getEquippedItems(p)) {
                    fireAbilities(p, item, Ability.Trigger.PASSIVE_TICK, null);
                }
            }
        }, 20L, 20L);
    }

    // ── Core dispatch ─────────────────────────────────────────────────────────

    private void fireAbilities(Player player, ItemStack item, Ability.Trigger trigger, Event event) {
        if (!CustomItemBuilder.isCustomItem(item)) return;
        String itemId = CustomItemBuilder.getItemId(item);
        if (itemId == null) return;

        CustomItemDefinition def = plugin.getCustomItemRegistry().get(itemId);
        if (def == null) return;

        for (CustomItemDefinition.AbilityEntry entry : def.getAbilities()) {
            Ability ability = AbilityRegistry.get(entry.abilityId());
            if (ability == null || ability.getTrigger() != trigger) continue;

            // Cooldown check
            int cooldownSec = entry.params() != null && entry.params().containsKey("cooldown")
                    ? ((Number)entry.params().get("cooldown")).intValue()
                    : ability.getDefaultCooldown();

            // Scale cooldown with upgrades
            int upgradeLevel = CustomItemBuilder.getUpgradeLevel(item);
            cooldownSec = Math.max(1, (int)(cooldownSec * Math.pow(0.85, upgradeLevel)));

            if (cooldownSec > 0 && !cooldowns.isReady(player.getUniqueId(), entry.abilityId())) {
                long remaining = cooldowns.getRemaining(player.getUniqueId(), entry.abilityId());
                player.sendActionBar(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                        .deserialize("<red>⏳ " + ability.getDisplayName() + " cooldown: " + remaining + "s"));
                continue;
            }

            if (!ability.canExecute(player, entry.params() != null ? entry.params() : Map.of())) continue;

            // Execute
            try {
                ability.execute(player, entry.params() != null ? entry.params() : Map.of(), event);
                if (cooldownSec > 0) {
                    cooldowns.setCooldown(player.getUniqueId(), entry.abilityId(), cooldownSec);
                }
            } catch (Exception ex) {
                plugin.getLogger().warning("Ability error [" + entry.abilityId() + "]: " + ex.getMessage());
            }
        }
    }

    private List<ItemStack> getEquippedItems(Player p) {
        List<ItemStack> items = new ArrayList<>();
        if (p.getInventory().getItemInMainHand() != null) items.add(p.getInventory().getItemInMainHand());
        if (p.getInventory().getItemInOffHand() != null)  items.add(p.getInventory().getItemInOffHand());
        if (p.getInventory().getHelmet() != null)         items.add(p.getInventory().getHelmet());
        if (p.getInventory().getChestplate() != null)     items.add(p.getInventory().getChestplate());
        if (p.getInventory().getLeggings() != null)       items.add(p.getInventory().getLeggings());
        if (p.getInventory().getBoots() != null)          items.add(p.getInventory().getBoots());
        items.removeIf(i -> i == null || i.getType() == Material.AIR);
        return items;
    }

    public CooldownManager getCooldowns() { return cooldowns; }
}