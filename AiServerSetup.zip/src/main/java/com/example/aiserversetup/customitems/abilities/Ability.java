package com.example.aiserversetup.customitems.abilities;

import org.bukkit.entity.Player;
import org.bukkit.event.Event;

import java.util.Map;

/**
 * Base interface for all custom item abilities.
 */
public interface Ability {
    String getId();            // "lightning_strike"
    String getDisplayName();   // "Lightning Strike"
    String getDescription();   // "Calls down lightning at your target"
    String getCategory();      // "Combat", "Movement", "Utility", "World"
    Trigger getTrigger();      // When this ability fires

    /** Default cooldown in seconds */
    int getDefaultCooldown();

    /**
     * Execute the ability.
     * @param player  The player using the item
     * @param params  Config params from the item definition
     * @param event   The originating event (may be null for passive)
     */
    void execute(Player player, Map<String, Object> params, Event event);

    /** Whether this ability can be triggered at this moment (pre-checks). */
    default boolean canExecute(Player player, Map<String, Object> params) { return true; }

    enum Trigger {
        RIGHT_CLICK,        // Player right-clicks
        LEFT_CLICK,         // Player left-clicks
        HIT_ENTITY,         // Player hits an entity
        TAKE_DAMAGE,        // Player takes damage
        KILL_ENTITY,        // Player kills an entity
        BLOCK_BREAK,        // Player breaks a block
        BLOCK_PLACE,        // Player places a block
        SNEAK,              // Player sneaks
        SPRINT,             // Player sprints
        JUMP,               // Player jumps
        ON_EQUIP,           // Item is equipped (passive)
        ON_UNEQUIP,         // Item is removed (passive end)
        PASSIVE_TICK,       // Every N ticks while held
        DEATH               // Player dies
    }
}