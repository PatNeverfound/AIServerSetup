package com.example.aiserversetup;

import java.util.*;

/**
 * Manages per-player (or console) conversation history for the AI.
 */
public class ConversationManager {

    private final String systemPrompt;
    private final int maxHistory;

    // Key: player name or "CONSOLE", Value: list of {role, content} maps
    private final Map<String, List<Map<String, String>>> histories = new HashMap<>();

    public ConversationManager(String systemPrompt, int maxHistory) {
        this.systemPrompt = systemPrompt;
        this.maxHistory = maxHistory;
    }

    /**
     * Gets (or initializes) the full message list for a sender, with the system prompt prepended.
     */
    public List<Map<String, String>> getHistory(String sender) {
        histories.putIfAbsent(sender, new ArrayList<>());
        return histories.get(sender);
    }

    /**
     * Builds the full message list to send to OpenAI: system prompt + history.
     */
    public List<Map<String, String>> buildMessages(String sender) {
        List<Map<String, String>> messages = new ArrayList<>();
        messages.add(Map.of("role", "system", "content", systemPrompt));
        messages.addAll(getHistory(sender));
        return messages;
    }

    /**
     * Adds a user message to the history.
     */
    public void addUserMessage(String sender, String content) {
        List<Map<String, String>> history = getHistory(sender);
        history.add(Map.of("role", "user", "content", content));
        trimHistory(history);
    }

    /**
     * Adds an assistant message to the history.
     */
    public void addAssistantMessage(String sender, String content) {
        List<Map<String, String>> history = getHistory(sender);
        history.add(Map.of("role", "assistant", "content", content));
        trimHistory(history);
    }

    /**
     * Clears all conversation history for a sender.
     */
    public void clearHistory(String sender) {
        histories.remove(sender);
    }

    private void trimHistory(List<Map<String, String>> history) {
        // Keep only the most recent maxHistory*2 messages (user+assistant pairs)
        while (history.size() > maxHistory * 2) {
            history.remove(0);
        }
    }
}