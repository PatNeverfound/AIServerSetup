package com.example.aiserversetup.broadcast;

import com.example.aiserversetup.core.PluginCore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

/**
 * Sends rotating broadcast messages to all players on a configurable interval.
 */
public class BroadcastScheduler implements PluginCore.PluginModule {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final List<String> messages = new ArrayList<>();
    private int       index     = 0;
    private BukkitTask task;

    @Override
    public String name() { return "BroadcastScheduler"; }

    @Override
    public void onEnable(PluginCore core) {
        var cfg = core.getPlugin().getConfig();
        messages.addAll(cfg.getStringList("broadcasts.messages"));
        if (messages.isEmpty()) {
            messages.add("<gold>[AIServer] <white>Welcome! Use <yellow>/ai ask <question></yellow> to chat with the AI!");
            messages.add("<gold>[AIServer] <white>Type <yellow>/gm</yellow> to browse gamemodes.");
            messages.add("<gold>[AIServer] <white>Type <yellow>/ci</yellow> to browse custom items.");
        }
        long intervalTicks = cfg.getLong("broadcasts.interval-ticks", 20L * 300); // 5 min default
        task = Bukkit.getScheduler().runTaskTimer(core.getPlugin(), this::broadcast,
                intervalTicks, intervalTicks);
        core.getPlugin().getLogger().info("[BroadcastScheduler] " + messages.size() + " messages, interval=" + intervalTicks + " ticks");
    }

    @Override
    public void onDisable(PluginCore core) {
        if (task != null) task.cancel();
    }

    private void broadcast() {
        if (messages.isEmpty() || Bukkit.getOnlinePlayers().isEmpty()) return;
        String msg = messages.get(index % messages.size());
        index++;
        Bukkit.broadcast(MM.deserialize(msg));
    }

    public void addMessage(String msg) { messages.add(msg); }
    public void clearMessages()        { messages.clear(); }
    public List<String> getMessages()  { return Collections.unmodifiableList(messages); }
}