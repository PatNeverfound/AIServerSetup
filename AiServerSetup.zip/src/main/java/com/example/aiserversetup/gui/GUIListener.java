package com.example.aiserversetup.gui;

import com.example.aiserversetup.config.FileEditor;
import com.example.aiserversetup.util.ChatUtil;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.plugin.Plugin;

import java.util.Map;

/**
 * Handles clicks inside the Setup GUI.
 */
public class GUIListener implements Listener {

    private final SetupGUI gui;
    private final FileEditor fileEditor;
    private final ChatUtil chat;

    public GUIListener(SetupGUI gui, FileEditor fe, ChatUtil chat) {
        this.gui        = gui;
        this.fileEditor = fe;
        this.chat       = chat;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null) return;

        String title = PlainTextComponentSerializer.plainText()
                .serialize(event.getView().title());
        if (!title.contains("AI Server Setup")) return;

        event.setCancelled(true);

        if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) return;
        if (event.getCurrentItem().getType() == Material.GRAY_STAINED_GLASS_PANE) return;

        int slot = event.getSlot();

        if (event.getCurrentItem().getType() == Material.BARRIER) {
            player.closeInventory();
            return;
        }

        // Preset slots
        if (SetupGUI.PRESET_SLOTS.containsKey(slot)) {
            String presetKey = SetupGUI.PRESET_SLOTS.get(slot);
            applyPreset(player, presetKey);
            player.closeInventory();
            return;
        }

        // Action buttons
        switch (slot) {
            case 28 -> { // Audit
                player.closeInventory();
                player.chat("/aiaudit");
            }
            case 30 -> { // Profiles
                player.closeInventory();
                player.chat("/aiprofile list");
            }
            case 32 -> { // Plugin manager
                player.closeInventory();
                player.chat("/aiplugin list");
            }
        }
    }

    private void applyPreset(Player player, String presetKey) {
        var section = gui.plugin().getConfig().getConfigurationSection("presets." + presetKey + ".settings");
        if (section == null) {
            chat.error(player, "Preset '" + presetKey + "' not found in config.yml.");
            return;
        }
        chat.header(player, "Applying Preset: " + presetKey);
        int applied = 0;
        for (String key : section.getKeys(false)) {
            String value = section.getString(key, "");
            if (fileEditor.setServerProperty(key, value)) {
                chat.success(player, "<aqua>" + key + "</aqua> = <green>" + value + "</green>");
                applied++;
            }
        }
        chat.warn(player, "Applied " + applied + " settings. Restart the server to take effect.");
    }
}