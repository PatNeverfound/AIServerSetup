package com.example.aiserversetup.gui;

import com.example.aiserversetup.core.PluginCore;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;
import java.util.function.*;

/**
 * Full GUI framework — replaces raw Bukkit inventory calls everywhere.
 *
 * Features:
 * - Fluent builder API
 * - Paginated views
 * - Animated titles
 * - Confirmation dialogs
 * - Input forms
 * - Drag-and-drop handling
 * - Auto-close on disable
 * - Click sound effects
 */
public class GuiFramework implements PluginCore.PluginModule, Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final Map<UUID, GuiSession> sessions = new WeakHashMap<>();

    @Override public String name() { return "GuiFramework"; }

    @Override
    public void onEnable(PluginCore core) {
        Bukkit.getPluginManager().registerEvents(this, core.getPlugin());
    }

    @Override
    public void onDisable(PluginCore core) {
        new ArrayList<>(sessions.keySet()).stream()
                .map(Bukkit::getPlayer)
                .filter(Objects::nonNull)
                .forEach(Player::closeInventory);
    }

    // ── Builder factory ───────────────────────────────────────────────────────

    public GuiBuilder builder(String title, int rows) {
        return new GuiBuilder(this, title, rows);
    }

    public GuiBuilder chest(String title, int rows) { return builder(title, rows); }
    public GuiBuilder chest54(String title)          { return builder(title, 6); }
    public GuiBuilder chest45(String title)          { return builder(title, 5); }
    public GuiBuilder chest36(String title)          { return builder(title, 4); }
    public GuiBuilder chest27(String title)          { return builder(title, 3); }
    public GuiBuilder chest18(String title)          { return builder(title, 2); }

    // ── Page builder ──────────────────────────────────────────────────────────

    public <T> void openPaginated(Player player, String title, List<T> items,
                                   Function<T, ItemStack> itemRenderer,
                                   Consumer<T> onClick,
                                   int rowsPerPage) {
        int pageSize = rowsPerPage * 9;
        int[] page   = { 0 };
        int totalPages = Math.max(1, (int) Math.ceil((double) items.size() / pageSize));

        Runnable buildPage = new Runnable() {
            @Override public void run() {
                int start = page[0] * pageSize;
                int end   = Math.min(start + pageSize, items.size());

                GuiBuilder b = builder(title + " <gray>(" + (page[0]+1) + "/" + totalPages + ")", rowsPerPage + 1);
                for (int i = start; i < end; i++) {
                    T item    = items.get(i);
                    int slot  = i - start;
                    b.slot(slot, itemRenderer.apply(item), e -> onClick.accept(item));
                }

                // Navigation row
                int navRow = rowsPerPage * 9;
                if (page[0] > 0) {
                    b.slot(navRow + 0, icon(Material.ARROW, "<green>Previous", List.of("<gray>Page " + page[0])),
                            e -> { page[0]--; this.run(); });
                }
                b.slot(navRow + 4, icon(Material.PAPER,
                        "<white>Page <yellow>" + (page[0]+1) + "/" + totalPages, List.of()), null);
                if (page[0] < totalPages - 1) {
                    b.slot(navRow + 8, icon(Material.ARROW, "<green>Next", List.of("<gray>Page " + (page[0]+2))),
                            e -> { page[0]++; this.run(); });
                }
                b.fillEmpty(icon(Material.GRAY_STAINED_GLASS_PANE, " ", List.of()));
                b.open(player);
            }
        };
        buildPage.run();
    }

    // ── Confirmation dialog ───────────────────────────────────────────────────

    public void confirm(Player player, String question,
                        Runnable onConfirm, Runnable onCancel) {
        builder("<red>Confirm Action", 3)
                .slot(11, icon(Material.LIME_CONCRETE,  "<green>✔ Confirm",
                        List.of("<gray>" + question, "", "<green>Click to confirm")),
                        e -> { player.closeInventory(); onConfirm.run(); })
                .slot(13, icon(Material.PAPER, "<white>" + question, List.of()), null)
                .slot(15, icon(Material.RED_CONCRETE, "<red>✘ Cancel",
                        List.of("<gray>Click to cancel")),
                        e -> { player.closeInventory(); if (onCancel != null) onCancel.run(); })
                .fillEmpty(icon(Material.BLACK_STAINED_GLASS_PANE, " ", List.of()))
                .open(player);
    }

    // ── Session management ────────────────────────────────────────────────────

    void registerSession(Player player, GuiSession session) {
        sessions.put(player.getUniqueId(), session);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        GuiSession session = sessions.remove(p.getUniqueId());
        if (session != null && session.onClose() != null) session.onClose().run();
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        GuiSession session = sessions.get(p.getUniqueId());
        if (session == null) return;
        e.setCancelled(true);
        if (e.getCurrentItem() == null || e.getCurrentItem().getType() == Material.AIR) return;

        Consumer<InventoryClickEvent> handler = session.getSlotHandler(e.getSlot());
        if (handler != null) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.2f);
            handler.accept(e);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (sessions.containsKey(e.getWhoClicked().getUniqueId())) e.setCancelled(true);
    }

    // ── Helper ────────────────────────────────────────────────────────────────

    public ItemStack icon(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta  meta = item.getItemMeta();
        meta.displayName(MM.deserialize(name));
        meta.lore(lore.stream().map(MM::deserialize).toList());
        item.setItemMeta(meta);
        return item;
    }

    // ── Inner classes ─────────────────────────────────────────────────────────

    public class GuiBuilder {
        private final GuiFramework framework;
        private final String title;
        private final int rows;
        private final Map<Integer, ItemStack>                          items    = new HashMap<>();
        private final Map<Integer, Consumer<InventoryClickEvent>>      handlers = new HashMap<>();
        private Runnable onClose;
        private boolean  preventClose;

        GuiBuilder(GuiFramework f, String title, int rows) {
            this.framework = f;
            this.title     = title;
            this.rows      = rows;
        }

        public GuiBuilder slot(int slot, ItemStack item, Consumer<InventoryClickEvent> handler) {
            items.put(slot, item);
            if (handler != null) handlers.put(slot, handler);
            return this;
        }

        public GuiBuilder slot(int slot, Material mat, String name, List<String> lore,
                               Consumer<InventoryClickEvent> handler) {
            return slot(slot, framework.icon(mat, name, lore), handler);
        }

        public GuiBuilder border(ItemStack filler) {
            int size = rows * 9;
            for (int i = 0; i < 9; i++) { items.putIfAbsent(i, filler); items.putIfAbsent(size-9+i, filler); }
            for (int i = 0; i < rows; i++) { items.putIfAbsent(i*9, filler); items.putIfAbsent(i*9+8, filler); }
            return this;
        }

        public GuiBuilder fillEmpty(ItemStack filler) {
            for (int i = 0; i < rows * 9; i++) items.putIfAbsent(i, filler);
            return this;
        }

        public GuiBuilder row(int row, ItemStack filler) {
            for (int i = 0; i < 9; i++) items.put(row * 9 + i, filler);
            return this;
        }

        public GuiBuilder onClose(Runnable r) { this.onClose = r; return this; }
        public GuiBuilder preventClose()      { this.preventClose = true; return this; }

        public void open(Player player) {
            Inventory inv = Bukkit.createInventory(null, rows * 9, MM.deserialize(title));
            items.forEach(inv::setItem);
            GuiSession session = new GuiSession(inv, handlers, onClose, preventClose);
            framework.registerSession(player, session);
            player.openInventory(inv);
        }
    }

    public record GuiSession(
            Inventory inventory,
            Map<Integer, Consumer<InventoryClickEvent>> handlers,
            Runnable onClose,
            boolean preventClose
    ) {
        Consumer<InventoryClickEvent> getSlotHandler(int slot) { return handlers.get(slot); }
    }
}