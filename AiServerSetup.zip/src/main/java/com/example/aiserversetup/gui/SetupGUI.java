package com.example.aiserversetup.gui;

import com.example.aiserversetup.AIServerSetupPlugin;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/** Full paginated setup GUI with preset, tools, and stats pages. */
public class SetupGUI {

    public final AIServerSetupPlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    // Slots → preset key (page 0)
    public static final Map<Integer, String> PRESET_SLOTS = new LinkedHashMap<>();
    static {
        PRESET_SLOTS.put(10, "survival"); PRESET_SLOTS.put(12, "creative");
        PRESET_SLOTS.put(14, "skyblock"); PRESET_SLOTS.put(16, "hardcore");
        PRESET_SLOTS.put(20, "minigame"); PRESET_SLOTS.put(22, "rpg");
        PRESET_SLOTS.put(24, "anarchy");  PRESET_SLOTS.put(26, "prison");
    }

    public SetupGUI(AIServerSetupPlugin plugin) { this.plugin = plugin; }

    public void open(Player player) { openPage(player, 0); }

    public void openPage(Player player, int page) {
        Inventory inv = Bukkit.createInventory(null, 54,
                mm.deserialize("<gradient:#00c6ff:#0072ff>⚙ AI Server Setup — Page " + (page + 