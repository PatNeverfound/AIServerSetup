package com.example.aiserversetup.gui;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.command.CommandSender;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * AI-powered DeluxeMenus/ChestCommands YAML menu generator.
 * AI writes the YAML, we save it and reload the menu plugin.
 */
public class MenuBuilder {

    private final AIServerSetupPlugin plugin;

    public MenuBuilder(AIServerSetupPlugin plugin) { this.plugin = plugin; }

    /** Save a generated menu YAML and reload DeluxeMenus. */
    public boolean saveDeluxeMenu(String menuName, String yamlContent) {
        try {
            File menuDir = new File("plugins/DeluxeMenus/gui_menus");
            menuDir.mkdirs();
            File f = new File(menuDir, menuName + ".yml");
            Files.writeString(f.toPath(), yamlContent);
            // Reload DeluxeMenus
            org.bukkit.Bukkit.dispatchCommand(org.bukkit.Bukkit.getConsoleSender(), "dm reload");
            return true;
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to save menu: " + e.getMessage());
            return false;
        }
    }

    /** Delete a DeluxeMenus menu file. */
    public boolean deleteDeluxeMenu(String menuName) {
        File f = new File("plugins/DeluxeMenus/gui_menus/" + menuName + ".yml");
        if (!f.exists()) return false;
        boolean deleted = f.delete();
        if (deleted) org.bukkit.Bukkit.dispatchCommand(org.bukkit.Bukkit.getConsoleSender(), "dm reload");
        return deleted;
    }

    /** List existing DeluxeMenus menu files. */
    public List<String> listMenus() {
        File dir = new File("plugins/DeluxeMenus/gui_menus");
        String[] files = dir.list((d, n) -> n.endsWith(".yml"));
        return files == null ? List.of() : Arrays.asList(files);
    }

    /** Ask AI to generate a complete DeluxeMenus menu YAML. */
    public void generateMenu(String description, CommandSender sender) {
        plugin.getChatUtil().sendRaw(sender, "<yellow>⏳ AI is generating your menu...</yellow>");
        String prompt = """
                Generate a complete, valid DeluxeMenus menu YAML file for a Minecraft server.
                The menu should: """ + description + """
                
                Format requirements:
                - Use valid DeluxeMenus syntax (menu_title, open_command, size, items section)
                - Use PlaceholderAPI placeholders where relevant (%player_name%, %player_level%, etc.)
                - Include click_commands for interactivity
                - Add lore descriptions for every item
                - Use color codes with & prefix
                - Output ONLY the raw YAML, no explanation, no markdown fences
                """;

        plugin.getAiClient().chat(List.of(Map.of("role", "user", "content", prompt)))
                .thenAccept(response -> {
                    String yaml = response.content().strip();
                    // Strip markdown fences if AI added them
                    if (yaml.startsWith("```")) yaml = yaml.replaceAll("^```[a-z]*\\n?", "").replaceAll("```$", "").strip();
                    final String finalYaml = yaml;

                    // Extract menu name from YAML
                    String name = description.replaceAll("[^a-zA-Z0-9_]", "_").toLowerCase().substring(0, Math.min(30, description.length()));

                    org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
                        boolean ok = saveDeluxeMenu(name, finalYaml);
                        if (ok) {
                            plugin.getChatUtil().success(sender, "✔ Menu created: <aqua>" + name + ".yml</aqua>");
                            plugin.getChatUtil().info(sender, "Open with: <yellow>/" + extractOpenCommand(finalYaml));
                        } else {
                            plugin.getChatUtil().error(sender, "Failed to save menu. Check console.");
                        }
                    });
                });
    }

    private String extractOpenCommand(String yaml) {
        for (String line : yaml.split("\n")) {
            if (line.trim().startsWith("open_command:")) {
                return line.split(":")[1].trim().replace("'", "").replace("\"", "");
            }
        }
        return "menu";
    }
}