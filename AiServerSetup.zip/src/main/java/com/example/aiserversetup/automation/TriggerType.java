package com.example.aiserversetup.automation;

/**
 * All event triggers the Automation Engine can react to.
 */
public enum TriggerType {
    // Player events
    PLAYER_JOIN,
    PLAYER_QUIT,
    PLAYER_FIRST_JOIN,
    PLAYER_DEATH,
    PLAYER_KILL,
    PLAYER_LEVEL_UP,
    PLAYER_CHAT,
    PLAYER_COMMAND,
    PLAYER_REACH_KILLS,
    PLAYER_REACH_PLAYTIME,

    // World events
    BLOCK_BREAK,
    BLOCK_PLACE,
    ENTITY_KILL,

    // Server events
    SERVER_TICK_1MIN,
    SERVER_TPS_LOW,
    SERVER_EMPTY,
    SERVER_FULL,

    // Manual/API
    MANUAL
}