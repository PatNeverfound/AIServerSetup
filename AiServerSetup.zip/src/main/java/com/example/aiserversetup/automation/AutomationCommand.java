package com.example.aiserversetup.automation;

import com.example.aiserversetup.ai.AIClient;
import com.example.aiserversetup.core.PluginCore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * /automate — manage automation rules and cron jobs
 *
 * /automate list              — list all rules
 * /automate fire <id>         — manually fire a rule
 * /automate reload            — reload automations.yml
 * /automate create <desc>     — use AI to create a rule from plain English
 * /automate remove <id>       — remove a rule
 * /automate cron list         — list cron jobs
 * /automate cron fire <id>    — fire a cron job now
 * /automate cron reload       — reload crons.yml
 */
public class AutomationCommand implements CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("aiserversetup.automate")) {
            sender.sendMessage(MM.deserialize("<red>No permission."));
            return true;
        }

        AutomationEngine ae = PluginCore.get().serviceOpt(AutomationEngine.class).orElse(null);
        CronScheduler    cs = PluginCore.get().serviceOpt(CronScheduler.class).orElse(null);

        if (args.length == 0) { sendHelp(sender); return true; }

        switch (args[0].toLowerCase()) {
            case "list" -> {
                if (ae == null) { sender.sendMessage(MM.deserialize("<red>AutomationEngine not loaded.")); return true; }
                sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
                sender.sendMessage(MM.deserialize("<gold>Automation Rules (" + ae.getRules().size() + ")"));
                for (AutomationEngine.AutomationRule rule : ae.getRules()) {
                    sender.sendMessage(MM.deserialize(
                            "  <yellow>" + rule.id +
                            " <dark_gray>[" + rule.trigger + "]" +
                            " <gray>fires=" + rule.fireCount +
                            " actions=" + rule.actions.size()));
                }
                sender.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
            }
            case "reload" -> {
                if (ae != null) ae.reloadRules();
                if (cs != null) cs.reload();
                sender.sendMessage(MM.deserialize("<green>✔ Automation rules and cron jobs reloaded."));
            }
            case "fire" -> {
                if (args.length < 2) { sender.sendMessage(MM.deserialize("<red>Usage: /automate fire <id>")); return true; }
                String id = args[1];
                if (ae == null) return true;
                boolean found = ae.getRules().stream().anyMatch(r -> r.id.equals(id));
                if (!found) { sender.sendMessage(MM.deserialize("<red>Rule not found: " + id)); return true; }
                Player p = sender instanceof Player ? (Player) sender : null;
                ae.fireTrigger(TriggerType.MANUAL, p);
                sender.sendMessage(MM.deserialize("<green>✔ Fired trigger MANUAL for all matching rules."));
            }
            case "remove" -> {
                if (args.length < 2) { sender.sendMessage(MM.deserialize("<red>Usage: /automate remove <id>")); return true; }
                if (ae != null && ae.removeRule(args[1])) {
                    sender.sendMessage(MM.deserialize("<green>✔ Removed rule: " + args[1]));
                } else {
                    sender.sendMessage(MM.deserialize("<red>Rule not found: " + args[1]));
                }
            }
            case "create" -> {
                if (args.length < 2) { sender.sendMessage(MM.deserialize("<red>Usage: /automate create <description>")); return true; }
                String desc = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                sender.sendMessage(MM.deserialize("<aqua>⏳ Asking AI to create automation rule..."));
                createRuleWithAI(sender, desc, ae);
            }
            case "cron" -> {
                if (cs == null) { sender.sendMessage(MM.deserialize("<red>CronScheduler not loaded.")); return true; }
                if (args.length < 2) { sendCronHelp(sender); return true; }
                switch (args[1].toLowerCase()) {
                    case "list" -> {
                        sender.sendMessage(MM.deserialize("<gold>Cron Jobs (" + cs.getJobs().size() + ")"));
                        cs.getJobs().forEach(j -> sender.sendMessage(MM.deserialize(
                                "  <yellow>" + j.id + " <gray>" + j.cron +
                                (j.enabled ? " <green>[ON]" : " <red>[OFF]") +
                                " <dark_gray>" + j.actions.size() + " actions")));
                    }
                    case "reload" -> { cs.reload(); sender.sendMessage(MM.deserialize("<green>Cron jobs reloaded.")); }
                    default -> sendCronHelp(sender);
                }
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void createRuleWithAI(CommandSender sender, String description,
                                   AutomationEngine ae) {
        if (ae == null) { sender.sendMessage(MM.deserialize("<red>AutomationEngine not loaded.")); return; }
        PluginCore.get().serviceOpt(AIClient.class).ifPresentOrElse(ai -> {
            String prompt = """
                    Create a Minecraft Paper server automation rule in this exact YAML format:
                    
                    id: <snake_case_id>
                    event: <TRIGGER_TYPE>
                    conditions:
                      - "<condition>"
                    actions:
                      - "<action>"
                    cooldown-seconds: 0
                    enabled: true
                    
                    Available trigger types: PLAYER_JOIN, PLAYER_QUIT, PLAYER_FIRST_JOIN, PLAYER_DEATH,
                    PLAYER_KILL, PLAYER_LEVEL_UP, PLAYER_CHAT, PLAYER_COMMAND, BLOCK_BREAK, BLOCK_PLACE,
                    ENTITY_KILL, SERVER_TICK_1MIN, SERVER_TPS_LOW, SERVER_EMPTY, SERVER_FULL
                    
                    Available actions: console:<cmd>, msg:<msg>, broadcast:<msg>, give:<MATERIAL>:<amount>,
                    money+:<amount>, money-:<amount>, xp+:<amount>, effect:<TYPE>:<amp>:<secs>,
                    kick:<reason>, title:<Title>|<Subtitle>, sound:<SOUND_NAME>, log:<message>
                    
                    Available conditions: first_join, is_op, has_empty_inv, is_night, is_raining,
                    permission:<node>, gamemode:<mode>, kills>=<n>, level>=<n>, world:<name>,
                    tps<<n>, online>=<n>, var:<key>=<value>
                    
                    User request: """ + description + """
                    
                    Reply with ONLY the YAML block, no explanation, no markdown fences.
                    """;
            ai.chat(List.of(Map.of("role", "user", "content", prompt)))
                    .thenAccept(resp -> {
                        if (resp.isError()) {
                            Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(),
                                    () -> sender.sendMessage(MM.deserialize("<red>AI error: " + resp.content())));
                            return;
                        }
                        try {
                            // Parse the AI-generated YAML
                            org.bukkit.configuration.file.YamlConfiguration tmpCfg =
                                    new org.bukkit.configuration.file.YamlConfiguration();
                            tmpCfg.loadFromString(resp.content());

                            AutomationEngine.AutomationRule rule = new AutomationEngine.AutomationRule();
                            rule.id         = tmpCfg.getString("id", "ai_rule_" + System.currentTimeMillis());
                            rule.trigger    = TriggerType.valueOf(tmpCfg.getString("event", "PLAYER_JOIN").toUpperCase());
                            rule.conditions = tmpCfg.getStringList("conditions");
                            rule.actions    = tmpCfg.getStringList("actions");
                            rule.cooldownMs = tmpCfg.getLong("cooldown-seconds", 0L) * 1000;
                            rule.enabled    = tmpCfg.getBoolean("enabled", true);

                            ae.addRule(rule);
                            final String ruleId = rule.id;
                            Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () -> {
                                sender.sendMessage(MM.deserialize("<green>✔ Created rule: <white>" + ruleId));
                                sender.sendMessage(MM.deserialize("<gray>Trigger: <yellow>" + rule.trigger));
                                sender.sendMessage(MM.deserialize("<gray>Actions: <yellow>" + rule.actions.size()));
                                sender.sendMessage(MM.deserialize("<gray>Conditions: <yellow>" + rule.conditions.size()));
                            });
                        } catch (Exception e) {
                            Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () ->
                                    sender.sendMessage(MM.deserialize("<red>Failed to parse AI rule: " + e.getMessage() +
                                            "\n<gray>Raw output:\n<white>" + resp.content())));
                        }
                    })
                    .exceptionally(ex -> {
                        Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () ->
                                sender.sendMessage(MM.deserialize("<red>AI request failed: " + ex.getMessage())));
                        return null;
                    });
        }, () -> sender.sendMessage(MM.deserialize("<red>AI client not available.")));
    }

    private void sendHelp(CommandSender s) {
        s.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
        s.sendMessage(MM.deserialize("<gold>Automation Commands:"));
        s.sendMessage(MM.deserialize("  <yellow>/automate list <gray>— Show all rules"));
        s.sendMessage(MM.deserialize("  <yellow>/automate reload <gray>— Reload automations.yml + crons.yml"));
        s.sendMessage(MM.deserialize("  <yellow>/automate fire <id> <gray>— Manually fire a rule"));
        s.sendMessage(MM.deserialize("  <yellow>/automate remove <id> <gray>— Delete a rule"));
        s.sendMessage(MM.deserialize("  <yellow>/automate create <desc> <gray>— AI creates rule from English"));
        s.sendMessage(MM.deserialize("  <yellow>/automate cron list <gray>— List cron jobs"));
        s.sendMessage(MM.deserialize("  <yellow>/automate cron reload <gray>— Reload crons.yml"));
        s.sendMessage(MM.deserialize("<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"));
    }

    private void sendCronHelp(CommandSender s) {
        s.sendMessage(MM.deserialize("<gray>Usage: /automate cron <list|reload>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1)
            return List.of("list","reload","fire","remove","create","cron").stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase())).toList();
        if (args.length == 2 && args[0].equalsIgnoreCase("cron"))
            return List.of("list","reload").stream()
                    .filter(s -> s.startsWith(args[1].toLowerCase())).toList();
        if (args.length == 2 && (args[0].equalsIgnoreCase("fire") || args[0].equalsIgnoreCase("remove"))) {
            AutomationEngine ae = PluginCore.get().serviceOpt(AutomationEngine.class).orElse(null);
            if (ae != null) return ae.getRules().stream().map(r -> r.id)
                    .filter(id -> id.startsWith(args[1])).toList();
        }
        return List.of();
    }
}