package com.example.aiserversetup.automation;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.util.StructuredLogger;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Predicate;

/**
 * ╔═══════════════════════════════════════════════════════════╗
 * ║           YAML-Driven Automation Rule Engine             ║
 * ╠═══════════════════════════════════════════════════════════╣
 * ║  Define automation rules in automations.yml:             ║
 * ║                                                           ║
 * ║  rules:                                                   ║
 * ║    - id: welcome_gift                                     ║
 * ║      event: PLAYER_JOIN                                   ║
 * ║      conditions:                                          ║
 * ║        - "first_join"                                     ║
 * ║      actions:                                             ║
 * ║        - "give %player% DIAMOND 1"                       ║
 * ║        - "msg %player% Welcome to the server!"           ║
 * ║        - "broadcast %player% just joined for the first!" ║
 * ║                                                           ║
 * ║  Supported Triggers: PLAYER_JOIN, PLAYER_QUIT,           ║
 * ║    PLAYER_DEATH, PLAYER_KILL, PLAYER_LEVEL_UP,           ║
 * ║    PLAYER_FIRST_JOIN, PLAYER_CHAT, PLAYER_COMMAND,       ║
 * ║    BLOCK_BREAK, BLOCK_PLACE, ENTITY_KILL,                ║
 * ║    SERVER_TICK_1MIN, SERVER_TPS_LOW, SERVER_EMPTY,       ║
 * ║    SERVER_FULL, PLAYER_REACH_KILLS, PLAYER_REACH_PLAYTIME║
 * ╚═══════════════════════════════════════════════════════════╝
 */
public class AutomationEngine implements PluginCore.PluginModule, Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final List<AutomationRule>    rules        = new CopyOnWriteArrayList<>();
    private final Map<UUID, Long>         lastFired    = new ConcurrentHashMap<>();
    private final Map<String, Object>     serverVars   = new ConcurrentHashMap<>();

    private File rulesFile;
    private YamlConfiguration rulesConfig;

    @Override
    public String name() { return "AutomationEngine"; }

    @Override
    public void onEnable(PluginCore core) {
        rulesFile = new File(core.getPlugin().getDataFolder(), "automations.yml");
        if (!rulesFile.exists()) saveDefaultConfig(core);
        loadRules();
        Bukkit.getPluginManager().registerEvents(this, core.getPlugin());

        // Minute tick for time-based rules
        Bukkit.getScheduler().runTaskTimerAsynchronously(core.getPlugin(),
                this::runTimedRules, 20L * 60, 20L * 60);

        core.getPlugin().getLogger().info("[Automation] Loaded " + rules.size() + " rules.");
    }

    // ── Rule loading ──────────────────────────────────────────────────────────

    public void loadRules() {
        rules.clear();
        rulesConfig = YamlConfiguration.loadConfiguration(rulesFile);
        ConfigurationSection rulesSec = rulesConfig.getConfigurationSection("rules");
        if (rulesSec == null) return;

        for (String key : rulesSec.getKeys(false)) {
            ConfigurationSection rs = rulesSec.getConfigurationSection(key);
            if (rs == null) continue;
            try {
                AutomationRule rule = new AutomationRule();
                rule.id         = rs.getString("id", key);
                rule.trigger    = TriggerType.valueOf(rs.getString("event", "PLAYER_JOIN").toUpperCase());
                rule.conditions = rs.getStringList("conditions");
                rule.actions    = rs.getStringList("actions");
                rule.cooldownMs = rs.getLong("cooldown-seconds", 0L) * 1000;
                rule.permission = rs.getString("permission", null);
                rule.enabled    = rs.getBoolean("enabled", true);
                rule.maxFires   = rs.getInt("max-fires", -1);
                if (rule.enabled) rules.add(rule);
            } catch (Exception e) {
                log("Failed to load rule '" + key + "': " + e.getMessage());
            }
        }
    }

    public void reloadRules() {
        loadRules();
        log("Reloaded " + rules.size() + " automation rules.");
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  EVENT HOOKS — translate Bukkit events into rule triggers
    // ══════════════════════════════════════════════════════════════════════════

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        RuleContext ctx = new RuleContext(p, null, null);
        ctx.vars.put("player", p.getName());

        if (!p.hasPlayedBefore()) {
            ctx.vars.put("first_join", "true");
            fireRules(TriggerType.PLAYER_FIRST_JOIN, ctx);
        }
        fireRules(TriggerType.PLAYER_JOIN, ctx);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        RuleContext ctx = new RuleContext(e.getPlayer(), null, null);
        fireRules(TriggerType.PLAYER_QUIT, ctx);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Player killer = p.getKiller();
        RuleContext ctx = new RuleContext(p, killer, null);
        ctx.vars.put("killer", killer != null ? killer.getName() : "environment");

        fireRules(TriggerType.PLAYER_DEATH, ctx);
        if (killer != null) {
            RuleContext killerCtx = new RuleContext(killer, p, null);
            killerCtx.vars.put("victim", p.getName());
            killerCtx.vars.put("kills", String.valueOf(killer.getStatistic(Statistic.PLAYER_KILLS) + 1));
            fireRules(TriggerType.PLAYER_KILL, killerCtx);
        }
    }

    @EventHandler
    public void onLevelUp(PlayerExpChangeEvent e) {
        if (e.getPlayer().getLevel() > 0 && e.getAmount() > 0) {
            RuleContext ctx = new RuleContext(e.getPlayer(), null, null);
            ctx.vars.put("level", String.valueOf(e.getPlayer().getLevel()));
            fireRules(TriggerType.PLAYER_LEVEL_UP, ctx);
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        RuleContext ctx = new RuleContext(e.getPlayer(), null, null);
        ctx.vars.put("message", e.getMessage());
        fireRules(TriggerType.PLAYER_CHAT, ctx);
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e) {
        RuleContext ctx = new RuleContext(e.getPlayer(), null, null);
        ctx.vars.put("command", e.getMessage().substring(1));
        fireRules(TriggerType.PLAYER_COMMAND, ctx);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(org.bukkit.event.block.BlockBreakEvent e) {
        RuleContext ctx = new RuleContext(e.getPlayer(), null, null);
        ctx.vars.put("block",   e.getBlock().getType().name());
        ctx.vars.put("world",   e.getBlock().getWorld().getName());
        fireRules(TriggerType.BLOCK_BREAK, ctx);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(org.bukkit.event.block.BlockPlaceEvent e) {
        RuleContext ctx = new RuleContext(e.getPlayer(), null, null);
        ctx.vars.put("block", e.getBlockPlaced().getType().name());
        fireRules(TriggerType.BLOCK_PLACE, ctx);
    }

    @EventHandler
    public void onEntityKill(EntityDeathEvent e) {
        if (!(e.getEntity().getKiller() instanceof Player killer)) return;
        RuleContext ctx = new RuleContext(killer, null, e.getEntity());
        ctx.vars.put("mob",   e.getEntity().getType().name());
        ctx.vars.put("world", e.getEntity().getWorld().getName());
        fireRules(TriggerType.ENTITY_KILL, ctx);
    }

    // ── Timed rules ───────────────────────────────────────────────────────────

    private void runTimedRules() {
        double tps = Bukkit.getTPS()[0];
        int online  = Bukkit.getOnlinePlayers().size();

        RuleContext serverCtx = new RuleContext(null, null, null);
        serverCtx.vars.put("tps",    String.format("%.1f", tps));
        serverCtx.vars.put("online", String.valueOf(online));
        serverCtx.vars.put("time",   new java.text.SimpleDateFormat("HH:mm").format(new Date()));

        fireRules(TriggerType.SERVER_TICK_1MIN, serverCtx);

        if (tps < 16.0) fireRules(TriggerType.SERVER_TPS_LOW, serverCtx);
        if (online == 0) fireRules(TriggerType.SERVER_EMPTY, serverCtx);
        if (online >= Bukkit.getMaxPlayers()) fireRules(TriggerType.SERVER_FULL, serverCtx);
    }

    // ── Rule execution ────────────────────────────────────────────────────────

    private void fireRules(TriggerType trigger, RuleContext ctx) {
        for (AutomationRule rule : rules) {
            if (rule.trigger != trigger) continue;
            if (rule.maxFires >= 0 && rule.fireCount >= rule.maxFires) continue;

            // Permission check (player-scoped rules)
            if (rule.permission != null && ctx.player != null &&
                !ctx.player.hasPermission(rule.permission)) continue;

            // Cooldown (per player for player-scoped, global for server)
            String cooldownKey = rule.id + (ctx.player != null ? ":" + ctx.player.getUniqueId() : ":server");
            long lastFiredTime = lastFired.getOrDefault(cooldownKey.hashCode() + "",  0L);
            if (rule.cooldownMs > 0 && System.currentTimeMillis() - lastFiredTime < rule.cooldownMs) continue;

            // Condition evaluation
            if (!evaluateConditions(rule.conditions, ctx)) continue;

            // Execute
            lastFired.put(cooldownKey.hashCode() + "", System.currentTimeMillis());
            rule.fireCount++;
            executeActions(rule.actions, ctx);
        }
    }

    private boolean evaluateConditions(List<String> conditions, RuleContext ctx) {
        for (String cond : conditions) {
            if (!evaluateCondition(cond.trim(), ctx)) return false;
        }
        return true;
    }

    private boolean evaluateCondition(String cond, RuleContext ctx) {
        Player p = ctx.player;

        // Boolean context vars (e.g., "first_join")
        if (ctx.vars.containsKey(cond)) return "true".equalsIgnoreCase(ctx.vars.get(cond));

        // player-based conditions
        if (p != null) {
            return switch (cond) {
                case "has_permission"     -> p.isOp();
                case "is_online"          -> p.isOnline();
                case "is_op"              -> p.isOp();
                case "has_empty_inv"      -> Arrays.stream(p.getInventory().getContents())
                        .allMatch(item -> item == null || item.getType() == Material.AIR);
                case "is_low_health"      -> p.getHealth() < 5.0;
                case "is_night"           -> p.getWorld().getTime() > 12600;
                case "is_raining"         -> p.getWorld().hasStorm();
                case "has_no_kills"       -> p.getStatistic(Statistic.PLAYER_KILLS) == 0;
                default -> {
                    // permission: check
                    if (cond.startsWith("permission:"))
                        yield p.hasPermission(cond.substring(11));
                    // gamemode: SURVIVAL
                    if (cond.startsWith("gamemode:"))
                        yield p.getGameMode().name().equalsIgnoreCase(cond.substring(9));
                    // kills>=N
                    if (cond.startsWith("kills>="))
                        yield p.getStatistic(Statistic.PLAYER_KILLS) >=
                                Integer.parseInt(cond.substring(7));
                    // level>=N
                    if (cond.startsWith("level>="))
                        yield p.getLevel() >= Integer.parseInt(cond.substring(7));
                    // world: worldname
                    if (cond.startsWith("world:"))
                        yield p.getWorld().getName().equalsIgnoreCase(cond.substring(6));
                    // tps<N
                    if (cond.startsWith("tps<"))
                        yield Bukkit.getTPS()[0] < Double.parseDouble(cond.substring(4));
                    // online>=N
                    if (cond.startsWith("online>="))
                        yield Bukkit.getOnlinePlayers().size() >= Integer.parseInt(cond.substring(8));
                    // var:key=value
                    if (cond.startsWith("var:")) {
                        String[] parts = cond.substring(4).split("=", 2);
                        if (parts.length == 2) yield parts[1].equalsIgnoreCase(ctx.vars.get(parts[0]));
                    }
                    yield true; // Unknown condition — pass (non-strict mode)
                }
            };
        }

        // Server-only conditions
        if (cond.startsWith("tps<")) return Bukkit.getTPS()[0] < Double.parseDouble(cond.substring(4));
        if (cond.startsWith("online>=")) return Bukkit.getOnlinePlayers().size() >= Integer.parseInt(cond.substring(8));
        return true;
    }

    private void executeActions(List<String> actions, RuleContext ctx) {
        for (String rawAction : actions) {
            String action = resolvePlaceholders(rawAction, ctx);
            Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(),
                    () -> executeAction(action, ctx));
        }
    }

    private void executeAction(String action, RuleContext ctx) {
        Player p = ctx.player;

        if (action.startsWith("console:") || action.startsWith("cmd:")) {
            String cmd = action.substring(action.indexOf(':') + 1).trim();
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);

        } else if (action.startsWith("msg:") || action.startsWith("message:")) {
            String msg = action.substring(action.indexOf(':') + 1).trim();
            if (p != null) p.sendMessage(MM.deserialize(msg));

        } else if (action.startsWith("broadcast:")) {
            Bukkit.broadcast(MM.deserialize(action.substring(10).trim()));

        } else if (action.startsWith("title:")) {
            // title:Title|Subtitle
            String[] parts = action.substring(6).split("\\|", 2);
            if (p != null) p.showTitle(net.kyori.adventure.text.title.Title.title(
                    MM.deserialize(parts[0]),
                    parts.length > 1 ? MM.deserialize(parts[1]) : net.kyori.adventure.text.Component.empty(),
                    net.kyori.adventure.text.title.Title.Times.times(
                            java.time.Duration.ofMillis(200),
                            java.time.Duration.ofSeconds(3),
                            java.time.Duration.ofMillis(400))));

        } else if (action.startsWith("sound:")) {
            // sound:ENTITY_PLAYER_LEVELUP
            if (p != null) {
                try { p.playSound(p.getLocation(), Sound.valueOf(action.substring(6).trim()), 1f, 1f); }
                catch (Exception ignored) {}
            }

        } else if (action.startsWith("give:")) {
            // give:MATERIAL:AMOUNT
            if (p != null) {
                String[] parts = action.substring(5).split(":");
                try {
                    Material mat = Material.valueOf(parts[0].trim().toUpperCase());
                    int amount   = parts.length > 1 ? Integer.parseInt(parts[1].trim()) : 1;
                    p.getInventory().addItem(new org.bukkit.inventory.ItemStack(mat, amount));
                } catch (Exception e) { log("give action error: " + e.getMessage()); }
            }

        } else if (action.startsWith("money+:")) {
            // money+:AMOUNT
            if (p != null) {
                try {
                    double amount = Double.parseDouble(action.substring(7).trim());
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.integrations.IntegrationManager.class)
                            .ifPresent(im -> im.deposit(p, amount));
                } catch (NumberFormatException ignored) {}
            }

        } else if (action.startsWith("money-:")) {
            if (p != null) {
                try {
                    double amount = Double.parseDouble(action.substring(7).trim());
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.integrations.IntegrationManager.class)
                            .ifPresent(im -> im.withdraw(p, amount));
                } catch (NumberFormatException ignored) {}
            }

        } else if (action.startsWith("xp+:")) {
            if (p != null) {
                try { p.giveExp(Integer.parseInt(action.substring(4).trim())); }
                catch (NumberFormatException ignored) {}
            }

        } else if (action.startsWith("effect:")) {
            // effect:SPEED:1:60  (type:amp:seconds)
            if (p != null) {
                String[] parts = action.substring(7).split(":");
                try {
                    org.bukkit.potion.PotionEffectType type =
                            org.bukkit.potion.PotionEffectType.getByName(parts[0].trim());
                    int amp  = parts.length > 1 ? Integer.parseInt(parts[1]) : 0;
                    int secs = parts.length > 2 ? Integer.parseInt(parts[2]) : 30;
                    if (type != null) p.addPotionEffect(new org.bukkit.potion.PotionEffect(type, secs * 20, amp));
                } catch (Exception ignored) {}
            }

        } else if (action.startsWith("kick:")) {
            if (p != null) p.kick(MM.deserialize(action.substring(5).trim()));

        } else if (action.startsWith("ban:")) {
            // ban:REASON:DURATION_HOURS
            if (p != null) {
                String[] parts = action.substring(4).split(":");
                String reason   = parts[0].trim();
                long   hours    = parts.length > 1 ? Long.parseLong(parts[1]) : 72;
                java.util.Date expiry = java.util.Date.from(
                        java.time.Instant.now().plusSeconds(hours * 3600));
                Bukkit.getBanList(BanList.Type.PROFILE)
                        .addBan(p.getPlayerProfile(), reason, expiry, "AutomationEngine");
                p.kickPlayer("§c" + reason);
            }

        } else if (action.startsWith("tp:")) {
            // tp:world,x,y,z or tp:spawn
            if (p != null) {
                String dest = action.substring(3).trim();
                if (dest.equalsIgnoreCase("spawn")) {
                    p.teleport(p.getWorld().getSpawnLocation());
                } else {
                    String[] parts = dest.split(",");
                    if (parts.length == 4) {
                        try {
                            World w = Bukkit.getWorld(parts[0]);
                            if (w != null) p.teleport(new Location(w,
                                    Double.parseDouble(parts[1]),
                                    Double.parseDouble(parts[2]),
                                    Double.parseDouble(parts[3])));
                        } catch (Exception ignored) {}
                    }
                }
            }

        } else if (action.startsWith("gamemode:")) {
            if (p != null) {
                try { p.setGameMode(GameMode.valueOf(action.substring(9).trim().toUpperCase())); }
                catch (Exception ignored) {}
            }

        } else if (action.startsWith("log:")) {
            log(resolvePlaceholders(action.substring(4), ctx));

        } else if (action.startsWith("ai:")) {
            // ai:Ask AI a question and broadcast response
            String question = action.substring(3).trim();
            PluginCore.get().serviceOpt(com.example.aiserversetup.ai.AIClient.class)
                    .ifPresent(ai -> ai.chat(List.of(Map.of("role", "user", "content", question)))
                            .thenAccept(resp -> Bukkit.getScheduler().runTask(
                                    PluginCore.get().getPlugin(),
                                    () -> Bukkit.broadcast(MM.deserialize("<aqua>[AI] " + resp.content()))))
                            .exceptionally(ex -> null));

        } else if (action.startsWith("wait:")) {
            // wait:TICKS — delay subsequent actions (NOTE: only delays this action, not the list)
            try {
                long ticks = Long.parseLong(action.substring(5).trim());
                // Implemented as a no-op; real delay requires splitting action lists
                Thread.sleep(ticks * 50);
            } catch (Exception ignored) {}

        } else {
            // Fallback: treat as raw console command
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), action);
        }
    }

    // ── Placeholder resolution ────────────────────────────────────────────────

    private String resolvePlaceholders(String text, RuleContext ctx) {
        if (ctx.player != null) {
            text = text.replace("%player%",      ctx.player.getName())
                       .replace("%player_uuid%", ctx.player.getUniqueId().toString())
                       .replace("%world%",       ctx.player.getWorld().getName())
                       .replace("%health%",      String.format("%.1f", ctx.player.getHealth()))
                       .replace("%level%",       String.valueOf(ctx.player.getLevel()))
                       .replace("%ping%",        String.valueOf(ctx.player.getPing()));
        }
        if (ctx.secondary instanceof Player secondary) {
            text = text.replace("%killer%", secondary.getName())
                       .replace("%victim%", secondary.getName());
        }
        text = text.replace("%online%",   String.valueOf(Bukkit.getOnlinePlayers().size()))
                   .replace("%tps%",      String.format("%.1f", Bukkit.getTPS()[0]))
                   .replace("%date%",     new java.text.SimpleDateFormat("yyyy-MM-dd").format(new Date()))
                   .replace("%time%",     new java.text.SimpleDateFormat("HH:mm:ss").format(new Date()));
        // Also replace from dynamic ctx vars
        for (Map.Entry<String, String> e : ctx.vars.entrySet()) {
            text = text.replace("%" + e.getKey() + "%", e.getValue());
        }
        // PlaceholderAPI
        if (ctx.player != null) {
            boolean hasPAPI = PluginCore.get().serviceOpt(
                    com.example.aiserversetup.integrations.IntegrationManager.class)
                    .map(im -> im.hasPlaceholderAPI()).orElse(false);
            if (hasPAPI) {
                try { text = me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(ctx.player, text); }
                catch (Exception ignored) {}
            }
        }
        return text;
    }

    // ── Default config ────────────────────────────────────────────────────────

    private void saveDefaultConfig(PluginCore core) {
        try (InputStream is = core.getPlugin().getResource("automations.yml")) {
            if (is != null) {
                java.nio.file.Files.copy(is, rulesFile.toPath());
            } else {
                // Generate default
                String defaults = """
                        # AI Server Setup — Automation Rules
                        # Full documentation: https://github.com/PatNeverfoundAdd/AIServerSetup/wiki/Automation
                        
                        rules:
                          first_join_welcome:
                            id: first_join_welcome
                            event: PLAYER_FIRST_JOIN
                            conditions: []
                            actions:
                              - "title:§6Welcome to the Server!|§7We're glad you're here."
                              - "give:COOKED_BEEF:16"
                              - "give:BREAD:8"
                              - "money+:500"
                              - "sound:ENTITY_PLAYER_LEVELUP"
                              - "broadcast:<gold>✦ <white>%player% <gray>has joined for the first time!"
                            enabled: true
                        
                          daily_login_reward:
                            id: daily_login_reward
                            event: PLAYER_JOIN
                            cooldown-seconds: 86400
                            conditions: []
                            actions:
                              - "money+:100"
                              - "msg:<green>✔ Daily login reward: +$100"
                            enabled: true
                        
                          pvp_kill_reward:
                            id: pvp_kill_reward
                            event: PLAYER_KILL
                            conditions: []
                            actions:
                              - "money+:50"
                              - "msg:<red>⚔ +$50 for killing %victim%!"
                              - "sound:ENTITY_PLAYER_LEVELUP"
                            enabled: true
                        
                          low_tps_alert:
                            id: low_tps_alert
                            event: SERVER_TPS_LOW
                            cooldown-seconds: 300
                            conditions:
                              - "tps<15"
                            actions:
                              - "broadcast:<red>[Server] <white>The server is experiencing lag. TPS: %tps%"
                              - "log:TPS drop detected: %tps%"
                            enabled: true
                        
                          mob_kill_bounty:
                            id: mob_kill_bounty
                            event: ENTITY_KILL
                            conditions:
                              - "var:mob=ELDER_GUARDIAN"
                            actions:
                              - "money+:1000"
                              - "broadcast:<gold>⭐ <white>%player% <gray>defeated an Elder Guardian! (+$1000)"
                            enabled: true
                        
                          diamond_find_reward:
                            id: diamond_find_reward
                            event: BLOCK_BREAK
                            conditions:
                              - "var:block=DIAMOND_ORE"
                            cooldown-seconds: 60
                            actions:
                              - "msg:<aqua>💎 Found diamond! +$25 bonus!"
                              - "money+:25"
                            enabled: true
                        
                          night_warning:
                            id: night_warning
                            event: PLAYER_JOIN
                            conditions:
                              - "is_night"
                            actions:
                              - "msg:<gray>It is currently nighttime. Be careful of mobs!"
                            enabled: true
                        
                          empty_server:
                            id: empty_server
                            event: SERVER_EMPTY
                            cooldown-seconds: 3600
                            conditions: []
                            actions:
                              - "log:Server has been empty for over an hour."
                            enabled: false
                        """;
                java.nio.file.Files.writeString(rulesFile.toPath(), defaults);
            }
        } catch (Exception e) {
            log("Could not save default automations.yml: " + e.getMessage());
        }
    }

    // ── Programmatic API ──────────────────────────────────────────────────────

    /**
     * Add a rule programmatically (e.g., from AI suggestions).
     */
    public void addRule(AutomationRule rule) {
        rules.add(rule);
    }

    /**
     * Remove a rule by ID.
     */
    public boolean removeRule(String id) {
        return rules.removeIf(r -> r.id.equals(id));
    }

    /**
     * Get all loaded rules.
     */
    public List<AutomationRule> getRules() {
        return Collections.unmodifiableList(rules);
    }

    /**
     * Fire a trigger manually (for testing or API use).
     */
    public void fireTrigger(TriggerType trigger, Player player) {
        RuleContext ctx = new RuleContext(player, null, null);
        if (player != null) ctx.vars.put("player", player.getName());
        fireRules(trigger, ctx);
    }

    private void log(String msg) {
        PluginCore.get().serviceOpt(StructuredLogger.class)
                .ifPresentOrElse(l -> l.info("Automation", msg),
                        () -> PluginCore.get().getPlugin().getLogger().info("[Automation] " + msg));
    }

    // ── Data classes ──────────────────────────────────────────────────────────

    public static class AutomationRule {
        public String           id;
        public TriggerType      trigger;
        public List<String>     conditions = new ArrayList<>();
        public List<String>     actions    = new ArrayList<>();
        public long             cooldownMs = 0;
        public String           permission = null;
        public boolean          enabled    = true;
        public int              maxFires   = -1;
        public int              fireCount  = 0;
    }

    public static class RuleContext {
        public final Player                 player;
        public final Object                 secondary; // killer, entity, etc.
        public final org.bukkit.entity.Entity entity;
        public final Map<String, String>    vars = new HashMap<>();

        public RuleContext(Player p, Object secondary, org.bukkit.entity.Entity entity) {
            this.player    = p;
            this.secondary = secondary;
            this.entity    = entity;
        }
    }
}