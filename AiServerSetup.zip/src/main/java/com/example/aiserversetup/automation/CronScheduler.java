package com.example.aiserversetup.automation;

import com.example.aiserversetup.core.PluginCore;
import org.bukkit.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.scheduler.BukkitTask;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

/**
 * Real-time cron-based scheduler.
 * Runs scheduled jobs based on wall-clock time — not server ticks.
 *
 * Config (crons.yml):
 *
 *   jobs:
 *     daily_restart:
 *       cron: "0 4 * * *"       # At 04:00 every day
 *       actions:
 *         - "broadcast: Server restarting in 1 minute!"
 *         - "console: restart"
 *       enabled: true
 *
 *     peak_hours_announce:
 *       cron: "0 18 * * 5"       # Fridays at 6pm
 *       actions:
 *         - "broadcast: It's Friday! Double XP weekend starts now!"
 *
 * Cron format: "MINUTE HOUR DAY_OF_MONTH MONTH DAY_OF_WEEK"
 *   * = every, 0-59 for minutes, 0-23 for hours, 0-6 for day of week (0=Sunday)
 */
public class CronScheduler implements PluginCore.PluginModule {

    private final List<CronJob> jobs = new CopyOnWriteArrayList<>();
    private BukkitTask checkTask;
    private java.io.File jobsFile;

    @Override
    public String name() { return "CronScheduler"; }

    @Override
    public void onEnable(PluginCore core) {
        jobsFile = new java.io.File(core.getPlugin().getDataFolder(), "crons.yml");
        if (!jobsFile.exists()) saveDefaults(core);
        loadJobs();

        // Check every minute (real time)
        checkTask = Bukkit.getScheduler().runTaskTimerAsynchronously(
                core.getPlugin(), this::tick, 20L * 30, 20L * 60);

        core.getPlugin().getLogger().info("[CronScheduler] Loaded " + jobs.size() + " cron jobs.");
    }

    @Override
    public void onDisable(PluginCore core) {
        if (checkTask != null) checkTask.cancel();
    }

    // ── Tick ─────────────────────────────────────────────────────────────────

    private void tick() {
        LocalDateTime now = LocalDateTime.now();
        for (CronJob job : jobs) {
            if (!job.enabled) continue;
            if (job.lastRun != null && job.lastRun.getMinute() == now.getMinute() &&
                job.lastRun.getHour() == now.getHour() &&
                job.lastRun.getDayOfYear() == now.getDayOfYear()) continue; // Already ran this minute

            if (matches(job.cron, now)) {
                job.lastRun = now;
                PluginCore.get().getPlugin().getLogger().info("[Cron] Running job: " + job.id);
                for (String action : job.actions) {
                    Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () ->
                            executeAction(action, now));
                }
            }
        }
    }

    // ── Cron matching ─────────────────────────────────────────────────────────

    /**
     * Matches a 5-field cron expression against a LocalDateTime.
     * Fields: MINUTE HOUR DAY_OF_MONTH MONTH DAY_OF_WEEK
     */
    private boolean matches(String cron, LocalDateTime dt) {
        String[] fields = cron.trim().split("\\s+");
        if (fields.length != 5) return false;
        return matchField(fields[0], dt.getMinute(), 0, 59)
            && matchField(fields[1], dt.getHour(),   0, 23)
            && matchField(fields[2], dt.getDayOfMonth(), 1, 31)
            && matchField(fields[3], dt.getMonthValue(),  1, 12)
            && matchField(fields[4], dt.getDayOfWeek().getValue() % 7, 0, 6);
    }

    private boolean matchField(String field, int value, int min, int max) {
        if ("*".equals(field)) return true;
        if (field.contains("/")) {
            String[] parts = field.split("/");
            int step = Integer.parseInt(parts[1]);
            int start = "*".equals(parts[0]) ? min : Integer.parseInt(parts[0]);
            return value >= start && (value - start) % step == 0;
        }
        if (field.contains(",")) {
            for (String part : field.split(",")) {
                if (matchField(part.trim(), value, min, max)) return true;
            }
            return false;
        }
        if (field.contains("-")) {
            String[] parts = field.split("-");
            return value >= Integer.parseInt(parts[0]) && value <= Integer.parseInt(parts[1]);
        }
        try { return Integer.parseInt(field) == value; }
        catch (NumberFormatException e) { return false; }
    }

    // ── Action execution ──────────────────────────────────────────────────────

    private void executeAction(String action, LocalDateTime dt) {
        String resolved = action
                .replace("%time%", dt.format(DateTimeFormatter.ofPattern("HH:mm")))
                .replace("%date%", dt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
                .replace("%online%", String.valueOf(Bukkit.getOnlinePlayers().size()));

        if (resolved.startsWith("broadcast:")) {
            Bukkit.broadcast(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                    .deserialize(resolved.substring(10).trim()));
        } else if (resolved.startsWith("console:") || resolved.startsWith("cmd:")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    resolved.substring(resolved.indexOf(':') + 1).trim());
        } else if (resolved.startsWith("log:")) {
            PluginCore.get().getPlugin().getLogger().info("[Cron] " + resolved.substring(4));
        } else if (resolved.startsWith("warn-all:")) {
            String msg = resolved.substring(9).trim();
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                            .deserialize(msg)));
        } else {
            // Raw command
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), resolved);
        }
    }

    // ── Job loading ───────────────────────────────────────────────────────────

    private void loadJobs() {
        jobs.clear();
        var cfg = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(jobsFile);
        ConfigurationSection jobSec = cfg.getConfigurationSection("jobs");
        if (jobSec == null) return;
        for (String key : jobSec.getKeys(false)) {
            ConfigurationSection js = jobSec.getConfigurationSection(key);
            if (js == null) continue;
            CronJob job   = new CronJob();
            job.id        = js.getString("id", key);
            job.cron      = js.getString("cron", "0 0 * * *");
            job.actions   = js.getStringList("actions");
            job.enabled   = js.getBoolean("enabled", true);
            jobs.add(job);
        }
    }

    public void reload() { loadJobs(); }
    public List<CronJob> getJobs() { return Collections.unmodifiableList(jobs); }

    public void addJob(String id, String cron, List<String> actions) {
        CronJob job = new CronJob();
        job.id      = id;
        job.cron    = cron;
        job.actions = new ArrayList<>(actions);
        job.enabled = true;
        jobs.add(job);
    }

    public boolean removeJob(String id) { return jobs.removeIf(j -> j.id.equals(id)); }

    // ── Default config ────────────────────────────────────────────────────────

    private void saveDefaults(PluginCore core) {
        String defaults = """
                # AI Server Setup — Cron Scheduler
                # Format: "MINUTE HOUR DAY_OF_MONTH MONTH DAY_OF_WEEK"
                # Use * for "every", / for step, - for range, , for list
                
                jobs:
                  daily_restart:
                    cron: "0 4 * * *"
                    actions:
                      - "broadcast:<red>[Server] <white>Server restarting in 1 minute!"
                      - "console:say Restarting in 60 seconds..."
                    enabled: false
                
                  hourly_announce:
                    cron: "0 * * * *"
                    actions:
                      - "broadcast:<gold>[Server] <gray>%online% players online | TPS will be shown in /status"
                    enabled: true
                
                  friday_double_xp:
                    cron: "0 18 * * 5"
                    actions:
                      - "broadcast:<gold>⭐ <white>It's Friday! Double XP weekend has begun!"
                    enabled: false
                
                  peak_player_reward:
                    cron: "0 20 * * 6"
                    actions:
                      - "broadcast:<green>🎁 Saturday night peak hours! All players get a reward!"
                      - "console:give @a GOLDEN_APPLE 3"
                    enabled: false
                
                  midnight_world_save:
                    cron: "0 0 * * *"
                    actions:
                      - "console:save-all"
                      - "log:Midnight world save completed."
                    enabled: true
                
                  low_memory_warn:
                    cron: "*/10 * * * *"
                    actions:
                      - "log:Scheduled memory check at %time%"
                    enabled: false
                """;
        try { java.nio.file.Files.writeString(jobsFile.toPath(), defaults); }
        catch (Exception e) { core.getPlugin().getLogger().warning("[Cron] Could not save crons.yml: " + e.getMessage()); }
    }

    // ── Data ──────────────────────────────────────────────────────────────────

    public static class CronJob {
        public String        id;
        public String        cron;
        public List<String>  actions = new ArrayList<>();
        public boolean       enabled = true;
        public LocalDateTime lastRun;
    }
}