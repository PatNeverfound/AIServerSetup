package com.example.aiserversetup.web;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.diagnostics.ServerDiagnostics;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.net.httpserver.*;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Optional lightweight HTTP REST API for the web dashboard.
 * Disabled by default — enable in config.yml with web-dashboard.enabled=true.
 *
 * Endpoints:
 *   GET /api/status       — server status snapshot
 *   GET /api/players      — online player list
 *   GET /api/gamemodes    — gamemode player counts
 */
public class WebDashboardAPI implements PluginCore.PluginModule {

    private HttpServer server;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    @Override
    public String name() { return "WebDashboardAPI"; }

    @Override
    public void onEnable(PluginCore core) {
        boolean enabled = core.getPlugin().getConfig().getBoolean("web-dashboard.enabled", false);
        if (!enabled) {
            core.getPlugin().getLogger().info("[WebDashboard] Disabled in config.");
            return;
        }
        int port     = core.getPlugin().getConfig().getInt("web-dashboard.port", 8765);
        String token = core.getPlugin().getConfig().getString("web-dashboard.token", "CHANGE_ME");

        try {
            server = HttpServer.create(new InetSocketAddress(port), 10);
            server.createContext("/api/status",    ex -> handle(ex, token, this::statusHandler));
            server.createContext("/api/players",   ex -> handle(ex, token, this::playersHandler));
            server.createContext("/api/gamemodes", ex -> handle(ex, token, this::gamemodesHandler));
            server.setExecutor(PluginCore.get().getExecutor());
            server.start();
            core.getPlugin().getLogger().info("[WebDashboard] HTTP API started on port " + port);
        } catch (Exception e) {
            core.getPlugin().getLogger().warning("[WebDashboard] Failed to start: " + e.getMessage());
        }
    }

    @Override
    public void onDisable(PluginCore core) {
        if (server != null) server.stop(0);
    }

    private void handle(HttpExchange ex, String token, ThrowingHandler handler) throws IOException {
        // Auth check
        String auth = ex.getRequestHeaders().getFirst("X-API-Token");
        if (!token.equals(auth)) {
            respond(ex, 401, "{\"error\":\"Unauthorized\"}");
            return;
        }
        try {
            String body = handler.handle();
            respond(ex, 200, body);
        } catch (Exception e) {
            respond(ex, 500, "{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    private String statusHandler() {
        var snap = PluginCore.get().serviceOpt(ServerDiagnostics.class)
                .map(ServerDiagnostics::collect)
                .orElse(null);
        if (snap == null) return "{\"error\":\"diagnostics unavailable\"}";
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("tps",            snap.tps());
        m.put("online_players", snap.onlinePlayers());
        m.put("memory_used_mb", snap.memUsedMB());
        m.put("memory_max_mb",  snap.memMaxMB());
        m.put("entities",       snap.totalEntities());
        m.put("chunks",         snap.loadedChunks());
        m.put("timestamp",      snap.timestamp());
        return gson.toJson(m);
    }

    private String playersHandler() {
        List<Map<String, Object>> players = new ArrayList<>();
        org.bukkit.Bukkit.getOnlinePlayers().forEach(p -> {
            Map<String, Object> pm = new LinkedHashMap<>();
            pm.put("name",      p.getName());
            pm.put("uuid",      p.getUniqueId().toString());
            pm.put("world",     p.getWorld().getName());
            pm.put("ping",      p.getPing());
            players.add(pm);
        });
        return gson.toJson(players);
    }

    private String gamemodesHandler() {
        Map<String, Integer> counts = new LinkedHashMap<>();
        PluginCore.get().serviceOpt(com.example.aiserversetup.gamemodes.GamemodeManager.class)
                .ifPresent(gm -> gm.getGamemodes().forEach((id, mode) ->
                        counts.put(id, mode.getPlayerCount())));
        return gson.toJson(counts);
    }

    private void respond(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    @FunctionalInterface
    interface ThrowingHandler {
        String handle() throws Exception;
    }
}