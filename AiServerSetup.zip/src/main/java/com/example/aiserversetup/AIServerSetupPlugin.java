package com.example.aiserversetup;

import com.example.aiserversetup.ai.*;
import com.example.aiserversetup.analytics.*;
import com.example.aiserversetup.broadcast.*;
import com.example.aiserversetup.cache.CacheService;
import com.example.aiserversetup.chat.*;
import com.example.aiserversetup.command.CommandFramework;
import com.example.aiserversetup.config.TypedConfig;
import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.customitems.*;
import com.example.aiserversetup.customitems.abilities.AbilityExecutor;
import com.example.aiserversetup.customitems.gui.ItemCreatorGUI;
import com.example.aiserversetup.customitems.texture.ResourcePackGenerator;
import com.example.aiserversetup.customitems.upgrades.UpgradeSystem;
import com.example.aiserversetup.database.*;
import com.example.aiserversetup.diagnostics.ServerDiagnostics;
import com.example.aiserversetup.gamemodes.GamemodeManager;
import com.example.aiserversetup.gui.GuiFramework;
import com.example.aiserversetup.integrations.*;
import com.example.aiserversetup.moderation.AutoModerator;
import com.example.aiserversetup.permissions.PermissionWizard;
import com.example.aiserversetup.rewards.RewardEngine;
import com.example.aiserversetup.scheduler.TaskScheduler;
import com.example.aiserversetup.util.*;
import com.example.aiserversetup.web.WebDashboardAPI;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * AIServerSetupPlugin v6.0 — "Titanium"
 *
 * Complete architectural rewrite:
 * - PluginCore service locator (no more God class)
 * - HikariCP database with 12 migrations
 * - Streaming AI with tool-calling
 * - Full GUI framework
 * - Typed config with hot reload
 * - Structured logger
 * - Result<T,E> error handling
 * - TTL cache
 * - 15 gamemodes
 * - 35 custom item abilities
 */
public class AIServerSetupPlugin extends JavaPlugin {

    private PluginCore core;

    @Override
    public void onLoad() {
        // Save default config before anything else
        saveDefaultConfig();
    }

    @Override
    public void onEnable() {
        // 1. Boot core
        core = PluginCore.init(this);

        // 2. Register all services
        core
            // ── Foundation ───────────────────────────────────────────────────
            .register(TypedConfig.class,        new TypedConfig())
            .register(StructuredLogger.class,   new StructuredLogger())
            .register(CacheService.class,       new CacheService(50_000))

            // ── Database (with all migrations) ────────────────────────────────
            .register(DatabaseService.class, buildDatabase())

            // ── GUI Framework ─────────────────────────────────────────────────
            .register(GuiFramework.class,       new GuiFramework())

            // ── AI ────────────────────────────────────────────────────────────
            .register(AIClient.class,           new AIClient())
            .register(ConversationStore.class,  new ConversationStore())
            .register(ApplyProcessor.class,     new ApplyProcessor())

            // ── Integrations ──────────────────────────────────────────────────
            .register(IntegrationManager.class, new IntegrationManager())

            // ── Chat utility ──────────────────────────────────────────────────
            .register(ChatUtil.class,           new ChatUtil())

            // ── Analytics ─────────────────────────────────────────────────────
            .register(PlayerAnalyticsEngine.class, new PlayerAnalyticsEngine())

            // ── Moderation ────────────────────────────────────────────────────
            .register(AutoModerator.class,      new AutoModerator())

            // ── Diagnostics ───────────────────────────────────────────────────
            .register(ServerDiagnostics.class,  new ServerDiagnostics())

            // ── Scheduler ─────────────────────────────────────────────────────
            .register(TaskScheduler.class,      new TaskScheduler())

            // ── Rewards ───────────────────────────────────────────────────────
            .register(RewardEngine.class,       new RewardEngine())

            // ── Broadcasts ────────────────────────────────────────────────────
            .register(BroadcastScheduler.class, new BroadcastScheduler())

            // ── Custom items ──────────────────────────────────────────────────
            .register(CustomItemRegistry.class,   new CustomItemRegistry())
            .register(ResourcePackGenerator.class,new ResourcePackGenerator())
            .register(CustomItemManager.class,    new CustomItemManager())
            .register(UpgradeSystem.class,        new UpgradeSystem())
            .register(ItemCreatorGUI.class,       new ItemCreatorGUI())
            .register(AbilityExecutor.class,      new AbilityExecutor())

            // ── Permissions wizard ────────────────────────────────────────────
            .register(PermissionWizard.class,   new PermissionWizard())

            // ── Gamemodes ─────────────────────────────────────────────────────
            .register(GamemodeManager.class,    new GamemodeManager())

            // ── Web dashboard ─────────────────────────────────────────────────
            .register(WebDashboardAPI.class,    new WebDashboardAPI())

            // ── AI tool registration (after all services exist) ───────────────
            .onEnable(this::registerAITools)

            // ── Commands ──────────────────────────────────────────────────────
            .onEnable(this::registerCommands)

            // ── Startup message ───────────────────────────────────────────────
            .onEnable(this::printBanner);

        // 3. Boot all modules
        core.enable();
    }

    @Override
    public void onDisable() {
        if (core != null) core.disable();
    }

    // ── Service accessors (convenience) ──────────────────────────────────────

    public <T> T get(Class<T> type)          { return core.service(type); }
    public PluginCore core()                 { return core; }

    // Commonly accessed — direct shortcuts
    public DatabaseService      db()         { return core.service(DatabaseService.class); }
    public CacheService         cache()      { return core.service(CacheService.class); }
    public AIClient             ai()         { return core.service(AIClient.class); }
    public ChatUtil             chat()       { return core.service(ChatUtil.class); }
    public StructuredLogger     log()        { return core.service(StructuredLogger.class); }
    public TypedConfig          cfg()        { return core.service(TypedConfig.class); }
    public GuiFramework         gui()        { return core.service(GuiFramework.class); }
    public GamemodeManager      gamemodes()  { return core.service(GamemodeManager.class); }
    public PlayerAnalyticsEngine analytics() { return core.service(PlayerAnalyticsEngine.class); }
    public CustomItemRegistry   items()      { return core.service(CustomItemRegistry.class); }

    // ── Database factory ──────────────────────────────────────────────────────

    private DatabaseService buildDatabase() {
        DatabaseService db = new DatabaseService();
        CoreMigrations.register(db);
        return db;
    }

    // ── AI tool registration ──────────────────────────────────────────────────

    private void registerAITools() {
        AIClient ai = core.service(AIClient.class);

        // Give item tool
        ai.registerTool(new AIClient.AITool() {
            @Override public String name()        { return "give_item"; }
            @Override public String description() { return "Give a Minecraft item to a player"; }
            @Override public Map<String, Object> parameters() {
                return Map.of("type","object","properties",Map.of(
                        "player",Map.of("type","string","description","Player name"),
                        "item",  Map.of("type","string","description","Material name e.g. DIAMOND_SWORD"),
                        "amount",Map.of("type","integer","description","Amount 1-64")),"required",List.of("player","item"));
            }
            @Override public String execute(com.google.gson.JsonObject args) {
                String player = args.get("player").getAsString();
                String item   = args.has("item")   ? args.get("item").getAsString() : "APPLE";
                int amount    = args.has("amount")  ? args.get("amount").getAsInt() : 1;
                boolean ok = org.bukkit.Bukkit.dispatchCommand(
                        org.bukkit.Bukkit.getConsoleSender(), "give " + player + " " + item + " " + amount);
                return "{\"success\":" + ok + ",\"message\":\"" + (ok ? "Item given" : "Failed") + "\"}";
            }
        });

        // Execute command tool
        ai.registerTool(new AIClient.AITool() {
            @Override public String name()        { return "run_command"; }
            @Override public String description() { return "Execute a console command on the server"; }
            @Override public Map<String, Object> parameters() {
                return Map.of("type","object","properties",Map.of(
                        "command",Map.of("type","string","description","Full console command to run")),
                        "required",List.of("command"));
            }
            @Override public String execute(com.google.gson.JsonObject args) {
                String cmd = args.get("command").getAsString();
                boolean ok = org.bukkit.Bukkit.dispatchCommand(org.bukkit.Bukkit.getConsoleSender(), cmd);
                core.service(StructuredLogger.class).audit("AI", "run_command", cmd, null);
                return "{\"success\":" + ok + "}";
            }
        });

        // Server info tool
        ai.registerTool(new AIClient.AITool() {
            @Override public String name()        { return "get_server_info"; }
            @Override public String description() { return "Get current server status, TPS, player list, memory usage"; }
            @Override public Map<String, Object> parameters() {
                return Map.of("type","object","properties",Map.of());
            }
            @Override public String execute(com.google.gson.JsonObject args) {
                var diag = core.service(ServerDiagnostics.class).collect();
                return new com.google.gson.GsonBuilder().create().toJson(Map.of(
                        "tps", diag.tps(), "online", diag.onlinePlayers(),
                        "memory_mb", diag.memUsedMB(), "max_memory_mb", diag.memMaxMB(),
                        "entities", diag.totalEntities(), "chunks", diag.loadedChunks()));
            }
        });

        // Player info tool
        ai.registerTool(new AIClient.AITool() {
            @Override public String name()        { return "get_player_info"; }
            @Override public String description() { return "Get analytics data for a specific player"; }
            @Override public Map<String, Object> parameters() {
                return Map.of("type","object","properties",Map.of(
                        "player",Map.of("type","string","description","Player name")),
                        "required",List.of("player"));
            }
            @Override public String execute(com.google.gson.JsonObject args) {
                String name = args.get("player").getAsString();
                Map<String, Object> stats = core.service(PlayerAnalyticsEngine.class)
                        .getPlayerStats(name).join();
                return new com.google.gson.GsonBuilder().create().toJson(stats);
            }
        });

        // Gamemode switch tool
        ai.registerTool(new AIClient.AITool() {
            @Override public String name()        { return "switch_gamemode"; }
            @Override public String description() { return "Switch a player to a different gamemode"; }
            @Override public Map<String, Object> parameters() {
                return Map.of("type","object","properties",Map.of(
                        "player",  Map.of("type","string"),
                        "gamemode",Map.of("type","string","enum",core.service(GamemodeManager.class)
                                .getGamemodes().keySet().stream().toList())),
                        "required",List.of("player","gamemode"));
            }
            @Override public String execute(com.google.gson.JsonObject args) {
                String playerName = args.get("player").getAsString();
                String mode       = args.get("gamemode").getAsString();
                org.bukkit.entity.Player p = org.bukkit.Bukkit.getPlayerExact(playerName);
                if (p == null) return "{\"error\":\"Player not online\"}";
                boolean ok = core.service(GamemodeManager.class).setPlayerMode(p, mode);
                return "{\"success\":" + ok + "}";
            }
        });
    }

    // ── Command registration ──────────────────────────────────────────────────

    private void registerCommands() {
        // Main AI command
        new CommandFramework("aisetup")
                .permission("aiserversetup.use")
                .sub("reload",   "Reload all configs",     "aiserversetup.admin",
                        (s, a) -> { core.service(TypedConfig.class).reloadAll(); chat().success(s, "All configs reloaded."); },
                        null, false)
                .sub("status",   "Show plugin status",     null,
                        (s, a) -> showStatus(s), null, false)
                .sub("debug",    "Toggle debug mode",       "aiserversetup.admin",
                        (s, a) -> chat().info(s, "Debug toggled."), null, false)
                .sub("tokens",   "Show AI token usage",    null,
                        (s, a) -> chat().info(s, "Total tokens used: " + core.service(AIClient.class).getTotalTokensUsed()),
                        null, false)
                .register(core);

        // Shorthand AI chat command
        new CommandFramework("ai")
                .sub("ask",     "Ask AI a question",  null,
                        (s, a) -> {
                            if (a.length == 0) { chat().error(s, "Usage: /ai ask <question>"); return; }
                            String q = String.join(" ", a);
                            chat().sendRaw(s, "<aqua>⏳ Asking AI...</aqua>");
                            core.service(AIClient.class).chat(List.of(Map.of("role","user","content",q)))
                                    .thenAccept(r -> core.sync(() -> chat().sendMultiline(s, r.content())));
                        },
                        null, false)
                .register(core);
    }

    private void showStatus(org.bukkit.command.CommandSender s) {
        chat().header(s, "AIServerSetup v6.0 Status");
        chat().sendRaw(s, "<gray>Core: <green>" + core.getPhase());
        chat().sendRaw(s, "<gray>AI: <white>" + core.service(AIClient.class).getProvider()
                + " / " + core.service(AIClient.class).getModel());
        chat().sendRaw(s, "<gray>DB: <white>" + core.service(DatabaseService.class).getType());
        chat().sendRaw(s, "<gray>Cache: <white>" + core.service(CacheService.class).size() + " entries");
        chat().sendRaw(s, "<gray>Gamemodes: <white>" + core.service(GamemodeManager.class).getGamemodes().size());
        chat().sendRaw(s, "<gray>Custom Items: <white>" + core.service(CustomItemRegistry.class).size());
        chat().sendRaw(s, "<gray>Tokens Used: <yellow>" + core.service(AIClient.class).getTotalTokensUsed());
    }

    private void printBanner() {
        String[] banner = {
                "§5  ╔═══════════════════════════════════════╗",
                "§5  ║  §dAI Server Setup §5v6.0 §7— Titanium   §5║",
                "§5  ║  §7HikariDB · Streaming AI · 15 Modes  §5║",
                "§5  ║  §7GUI Framework · Tool Calling         §5║",
                "§5  ╚═══════════════════════════════════════╝"
        };
        for (String line : banner) getLogger().info(line);
    }
}