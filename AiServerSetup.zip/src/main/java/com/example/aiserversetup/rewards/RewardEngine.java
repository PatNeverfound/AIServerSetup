package com.example.aiserversetup.rewards;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.database.DatabaseService;
import com.example.aiserversetup.integrations.IntegrationManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerJoinEvent;

import java.time.*;
import java.util.*;

/**
 * Daily/weekly/monthly reward system.
 * Players claim rewards once per period; rewards are persisted in DB.
 */
public class RewardEngine implements PluginCore.PluginModule, Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    public enum RewardType { DAILY, WEEKLY, MONTHLY }

    public record Reward(
            String id,
            RewardType type,
            String displayName,
            double money,
            List<String> commands,
            List<String> items
    ) {}

    private final List<Reward> rewards = new ArrayList<>();

    @Override
    public String name() { return "RewardEngine"; }

    @Override
    public void onEnable(PluginCore core) {
        Bukkit.getPluginManager().registerEvents(this, core.getPlugin());
        loadDefaultRewards();
        core.getPlugin().getLogger().info("[RewardEngine] Loaded " + rewards.size() + " rewards.");
    }

    private void loadDefaultRewards() {
        rewards.add(new Reward("daily_login",  RewardType.DAILY,   "Daily Login Reward",  500,
                List.of(), List.of("COOKED_BEEF:8")));
        rewards.add(new Reward("weekly_bonus", RewardType.WEEKLY,  "Weekly Bonus",       2500,
                List.of(), List.of("DIAMOND:3")));
        rewards.add(new Reward("monthly_gift", RewardType.MONTHLY, "Monthly Gift",      10000,
                List.of("give %player% netherite_ingot 1"), List.of()));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        // Auto-notify player of available rewards
        Bukkit.getScheduler().runTaskLater(PluginCore.get().getPlugin(), () -> {
            for (Reward reward : rewards) {
                if (!hasClaimed(e.getPlayer().getUniqueId(), reward.id())) {
                    e.getPlayer().sendMessage(MM.deserialize(
                            "<gold>🎁 You have an unclaimed reward: <white>" + reward.displayName() +
                            " <gold>— use <yellow>/rewards claim " + reward.id()));
                }
            }
        }, 40L);
    }

    public boolean claim(Player player, String rewardId) {
        Reward reward = rewards.stream().filter(r -> r.id().equals(rewardId)).findFirst().orElse(null);
        if (reward == null) return false;
        if (hasClaimed(player.getUniqueId(), rewardId)) return false;

        // Apply money
        if (reward.money() > 0) {
            PluginCore.get().serviceOpt(IntegrationManager.class)
                    .ifPresent(im -> im.deposit(player, reward.money()));
        }

        // Apply item rewards
        for (String itemStr : reward.items()) {
            String[] parts = itemStr.split(":");
            try {
                Material mat = Material.valueOf(parts[0]);
                int amount   = parts.length > 1 ? Integer.parseInt(parts[1]) : 1;
                player.getInventory().addItem(new org.bukkit.inventory.ItemStack(mat, amount));
            } catch (Exception ignored) {}
        }

        // Run commands
        for (String cmd : reward.commands()) {
            String resolved = cmd.replace("%player%", player.getName());
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), resolved);
        }

        // Mark as claimed
        markClaimed(player.getUniqueId(), rewardId);

        player.sendMessage(MM.deserialize("<gold>🎁 Claimed: <white>" + reward.displayName() +
                (reward.money() > 0 ? " <gray>(+$" + String.format("%.0f", reward.money()) + ")" : "")));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        return true;
    }

    public boolean hasClaimed(UUID uuid, String rewardId) {
        DatabaseService db = PluginCore.get().serviceOpt(DatabaseService.class).orElse(null);
        if (db == null) return false;
        try {
            return db.query(
                    "SELECT 1 FROM reward_claims WHERE uuid=? AND reward_id=? AND claimed_at > ?",
                    ps -> {
                        ps.setString(1, uuid.toString());
                        ps.setString(2, rewardId);
                        ps.setLong(3,   getWindowStart(rewardId));
                    },
                    rs -> rs.next()
            ).join();
        } catch (Exception e) { return false; }
    }

    private void markClaimed(UUID uuid, String rewardId) {
        PluginCore.get().serviceOpt(DatabaseService.class).ifPresent(db ->
                db.update(
                        "INSERT OR REPLACE INTO reward_claims(uuid,reward_id,claimed_at) VALUES(?,?,?)",
                        ps -> {
                            ps.setString(1, uuid.toString());
                            ps.setString(2, rewardId);
                            ps.setLong(3,   System.currentTimeMillis() / 1000);
                        })
                .exceptionally(ex -> { return 0; })
        );
    }

    private long getWindowStart(String rewardId) {
        Reward r = rewards.stream().filter(rw -> rw.id().equals(rewardId)).findFirst().orElse(null);
        if (r == null) return 0;
        LocalDate now = LocalDate.now();
        return switch (r.type()) {
            case DAILY   -> now.atStartOfDay(ZoneOffset.UTC).toEpochSecond();
            case WEEKLY  -> now.with(java.time.DayOfWeek.MONDAY).atStartOfDay(ZoneOffset.UTC).toEpochSecond();
            case MONTHLY -> now.withDayOfMonth(1).atStartOfDay(ZoneOffset.UTC).toEpochSecond();
        };
    }

    public List<Reward> getRewards() { return Collections.unmodifiableList(rewards); }
    public void addReward(Reward r)  { rewards.add(r); }
}