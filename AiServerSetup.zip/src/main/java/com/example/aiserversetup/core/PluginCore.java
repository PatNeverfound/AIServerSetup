package com.example.aiserversetup.core;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Central service locator and lifecycle manager.
 *
 * Replaces the "God class" main plugin with a clean module system.
 * All services register themselves here and are retrieved by type.
 *
 * Lifecycle: BOOT → ENABLE → RUNNING → DISABLE → STOPPED
 */
public class PluginCore {

    public enum Phase { BOOT, ENABLE, RUNNING, DISABLE, STOPPED }

    private static PluginCore instance;

    private final AIServerSetupPlugin plugin;
    private final Map<Class<?>, Object> services = new LinkedHashMap<>();
    private final List<PluginModule>    modules  = new ArrayList<>();
    private final ExecutorService       executor;
    private final ScheduledExecutorService scheduler;
    private Phase phase = Phase.BOOT;

    // Startup/shutdown hooks
    private final List<Runnable> enableHooks  = new ArrayList<>();
    private final List<Runnable> disableHooks = new ArrayList<>();

    private PluginCore(AIServerSetupPlugin plugin) {
        this.plugin    = plugin;
        this.executor  = Executors.newFixedThreadPool(
                Math.max(2, Runtime.getRuntime().availableProcessors()),
                r -> { Thread t = new Thread(r, "AISetup-Worker"); t.setDaemon(true); return t; });
        this.scheduler = Executors.newScheduledThreadPool(2,
                r -> { Thread t = new Thread(r, "AISetup-Scheduler"); t.setDaemon(true); return t; });
    }

    public static PluginCore init(AIServerSetupPlugin plugin) {
        instance = new PluginCore(plugin);
        return instance;
    }

    public static PluginCore get() {
        if (instance == null) throw new IllegalStateException("PluginCore not initialised");
        return instance;
    }

    // ── Service registry ───────────────────────��──────────────────────────────

    public <T> PluginCore register(Class<T> type, T impl) {
        services.put(type, impl);
        if (impl instanceof PluginModule m) modules.add(m);
        return this;
    }

    @SuppressWarnings("unchecked")
    public <T> T service(Class<T> type) {
        T svc = (T) services.get(type);
        if (svc == null) throw new NoSuchElementException("Service not found: " + type.getSimpleName());
        return svc;
    }

    @SuppressWarnings("unchecked")
    public <T> Optional<T> serviceOpt(Class<T> type) {
        return Optional.ofNullable((T) services.get(type));
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    public void enable() {
        phase = Phase.ENABLE;
        plugin.getLogger().info("[Core] Enabling " + modules.size() + " modules...");
        long start = System.currentTimeMillis();

        for (PluginModule m : modules) {
            try {
                m.onEnable(this);
                plugin.getLogger().info("[Core] ✔ " + m.name());
            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "[Core] ✘ Failed to enable module: " + m.name(), e);
            }
        }

        enableHooks.forEach(this::runSafely);
        phase = Phase.RUNNING;
        long ms = System.currentTimeMillis() - start;
        plugin.getLogger().info("[Core] All modules enabled in " + ms + "ms.");
    }

    public void disable() {
        phase = Phase.DISABLE;
        disableHooks.forEach(this::runSafely);

        ListIterator<PluginModule> it = modules.listIterator(modules.size());
        while (it.hasPrevious()) {
            try { it.previous().onDisable(this); } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "[Core] Module disable error", e);
            }
        }

        executor.shutdownNow();
        scheduler.shutdownNow();
        phase = Phase.STOPPED;
    }

    public PluginCore onEnable(Runnable r)  { enableHooks.add(r);  return this; }
    public PluginCore onDisable(Runnable r) { disableHooks.add(r); return this; }

    // ── Async utilities ───────────────────────────────────────────────────────

    public CompletableFuture<Void> async(Runnable r) {
        return CompletableFuture.runAsync(r, executor);
    }

    public <T> CompletableFuture<T> async(java.util.concurrent.Callable<T> c) {
        return CompletableFuture.supplyAsync(() -> {
            try { return c.call(); }
            catch (Exception e) { throw new CompletionException(e); }
        }, executor);
    }

    public void sync(Runnable r) {
        org.bukkit.Bukkit.getScheduler().runTask(plugin, r);
    }

    public ScheduledFuture<?> schedule(Runnable r, long delayMs, long periodMs) {
        return scheduler.scheduleAtFixedRate(r, delayMs, periodMs, TimeUnit.MILLISECONDS);
    }

    private void runSafely(Runnable r) {
        try { r.run(); } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "[Core] Hook error", e);
        }
    }

    public Phase getPhase()                    { return phase; }
    public boolean isRunning()                 { return phase == Phase.RUNNING; }
    public AIServerSetupPlugin getPlugin()     { return plugin; }
    public ExecutorService getExecutor()       { return executor; }
    public ScheduledExecutorService getSchedulerService() { return scheduler; }

    /** Interface all plugin modules implement. */
    public interface PluginModule {
        String name();
        void onEnable(PluginCore core) throws Exception;
        default void onDisable(PluginCore core) {}
    }
}