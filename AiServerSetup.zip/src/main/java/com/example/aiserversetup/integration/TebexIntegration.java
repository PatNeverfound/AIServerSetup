package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;

import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

public class TebexIntegration {

    private final AIServerSetupPlugin plugin;
    private final String secret;
    private final HttpClient http = HttpClient.newHttpClient();

    public TebexIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        // Read secret from Tebex config
        java.io.File cfg = new java.io.File("plugins/Tebex/config.properties");
        String key = "";
        if (cfg.exists()) {
            try (java.io.InputStream in = new java.io.FileInputStream(cfg)) {
                java.util.Properties p = new java.util.Properties();
                p.load(in);
                key = p.getProperty("secret-key", "");
            } catch (Exception ignored) {}
        }
        this.secret = key;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("Tebex"))
            throw new IllegalStateException("Tebex not found");
    }

    /** Fetch pending command queue from Tebex API */
    public CompletableFuture<String> getQueue() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create("https://plugin.tebex.io/queue"))
                        .header("X-Tebex-Secret", secret)
                        .GET().build();
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
                return resp.body();
            } catch (Exception e) { return "{\"error\":\"" + e.getMessage() + "\"}"; }
        });
    }

    /** Get store information */
    public CompletableFuture<String> getStoreInfo() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create("https://plugin.tebex.io/information"))
                        .header("X-Tebex-Secret", secret)
                        .GET().build();
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
                return resp.body();
            } catch (Exception e) { return "{\"error\":\"" + e.getMessage() + "\"}"; }
        });
    }

    /** Force-check the queue now (run Tebex's check command) */
    public boolean forceCheck() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tebex:forcecheck");
    }

    /** Get recent payments summary */
    public CompletableFuture<String> getPayments() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create("https://plugin.tebex.io/payments"))
                        .header("X-Tebex-Secret", secret)
                        .GET().build();
                HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
                return resp.body();
            } catch (Exception e) { return "{\"error\":\"" + e.getMessage() + "\"}"; }
        });
    }

    public boolean hasSecret() { return !secret.isBlank(); }

    public String buildContext() {
        return "=== Tebex ===\nStore connected: " + hasSecret() + "\n";
    }
}