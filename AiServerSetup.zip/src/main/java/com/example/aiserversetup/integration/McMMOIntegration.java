package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.gmail.nossr50.api.*;
import com.gmail.nossr50.datatypes.player.McMMOPlayer;
import com.gmail.nossr50.datatypes.skills.PrimarySkillType;
import com.gmail.nossr50.mcMMO;
import com.gmail.nossr50.util.player.UserManager;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * mcMMO integration — skill levels, XP, parties.
 */
public class McMMOIntegration {

    private final AIServerSetupPlugin plugin;

    public McMMOIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        // Verify mcMMO is accessible
        if (plugin.getServer().getPluginManager().getPlugin("mcMMO") == null)
            throw new IllegalStateException("mcMMO not found");
    }

    public int getSkillLevel(Player player, String skillName) {
        try {
            PrimarySkillType skill = PrimarySkillType.valueOf(skillName.toUpperCase());
            return ExperienceAPI.getLevel(player, skill);
        } catch (Exception e) { return 0; }
    }

    public boolean setSkillLevel(Player player, String skillName, int level) {
        try {
            PrimarySkillType skill = PrimarySkillType.valueOf(skillName.toUpperCase());
            ExperienceAPI.setLevel(player, level, skill);
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean addSkillXP(Player player, String skillName, int xp) {
        try {
            PrimarySkillType skill = PrimarySkillType.valueOf(skillName.toUpperCase());
            ExperienceAPI.addRawXP(player, skill, xp);
            return true;
        } catch (Exception e) { return false; }
    }

    public Map<String, Integer> getAllSkills(Player player) {
        Map<String, Integer> skills = new LinkedHashMap<>();
        for (PrimarySkillType skill : PrimarySkillType.values()) {
            try {
                skills.put(skill.name(), ExperienceAPI.getLevel(player, skill));
            } catch (Exception ignored) {}
        }
        return skills;
    }

    public int getPowerLevel(Player player) {
        McMMOPlayer mp = UserManager.getPlayer(player);
        return mp == null ? 0 : mp.getPowerLevel();
    }

    public List<String> getSkillNames() {
        List<String> names = new ArrayList<>();
        for (PrimarySkillType s : PrimarySkillType.values()) names.add(s.name());
        return names;
    }

    public String buildContext() {
        return "=== mcMMO ===\nSkills available: " + String.join(", ", getSkillNames()) + "\n";
    }
}