package com.example.aiserversetup.integration;

import com.Zrips.CMI.CMI;
import com.Zrips.CMI.Containers.CMIUser;
import com.Zrips.CMI.Modules.Economy.EconomyManager;
import com.Zrips.CMI.Modules.Homes.CMIHome;
import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class CMIIntegration {

    private final AIServerSetupPlugin plugin;
    private final CMI cmi;

    public CMIIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.cmi    = CMI.getInstance();
        if (cmi == null) throw new IllegalStateException("CMI not available");
    }

    // ── Economy ──────────────────────────────────────────────────────────────

    public double getBalance(Player player) {
        CMIUser u = cmi.getPlayerManager().getUser(player);
        return u == null ? 0 : EconomyManager.getBalance(u);
    }

    public boolean deposit(Player player, double amount) {
        CMIUser u = cmi.getPlayerManager().getUser(player);
        if (u == null) return false;
        EconomyManager.add(u, amount);
        return true;
    }

    public boolean withdraw(Player player, double amount) {
        CMIUser u = cmi.getPlayerManager().getUser(player);
        if (u == null) return false;
        EconomyManager.take(u, amount);
        return true;
    }

    public boolean setBalance(Player player, double amount) {
        CMIUser u = cmi.getPlayerManager().getUser(player);
        if (u == null) return false;
        double cur = EconomyManager.getBalance(u);
        if (cur > amount) EconomyManager.take(u, cur - amount);
        else              EconomyManager.add(u, amount - cur);
        return true;
    }

    // ── Homes ────────────────────────────────────────────────────────────────

    public List<String> getHomes(Player player) {
        CMIUser u = cmi.getPlayerManager().getUser(player);
        if (u == null) return List.of();
        return u.getHomes().stream().map(CMIHome::getName).collect(Collectors.toList());
    }

    public boolean deleteHome(Player player, String name) {
        CMIUser u = cmi.getPlayerManager().getUser(player);
        if (u == null) return false;
        u.removeHome(name);
        return true;
    }

    // ── Teleports / Warps ────────────────────────────────────────────────────

    public boolean teleportToWarp(Player player, String warp) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "cmi warp " + player.getName() + " " + warp);
    }

    // ── Mute / Jail / Freeze ────────────────────────────────────────��─────────

    public boolean mutePlayer(Player player, String duration, String reason) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "cmi mute " + player.getName() + " " + duration + " " + reason);
    }

    public boolean jailPlayer(Player player, String jailName, String duration) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "cmi jail " + player.getName() + " " + jailName + " " + duration);
    }

    public boolean freezePlayer(Player player, boolean freeze) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "cmi freeze " + player.getName() + (freeze ? "" : " off"));
    }

    // ── Nicknames ─────────────────────────────────────────────────────────────

    public boolean setNick(Player player, String nick) {
        CMIUser u = cmi.getPlayerManager().getUser(player);
        if (u == null) return false;
        u.setNickName(nick);
        return true;
    }

    // ── Kits ─────────────────────────────────────────────────────────────────

    public boolean giveKit(Player player, String kitName) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "cmi givekit " + player.getName() + " " + kitName);
    }

    // ── Fly ────��─────────────────────────────────────────────────────────────

    public boolean setFly(Player player, boolean fly) {
        CMIUser u = cmi.getPlayerManager().getUser(player);
        if (u == null) return false;
        player.setAllowFlight(fly);
        player.setFlying(fly);
        return true;
    }

    public String buildContext() {
        return "=== CMI ===\nCMI is active (economy, homes, warps, kits, jail, freeze, nick available)\n";
    }
}