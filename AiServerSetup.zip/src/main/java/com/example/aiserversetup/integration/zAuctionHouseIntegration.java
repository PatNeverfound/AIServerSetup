package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class zAuctionHouseIntegration {

    private final AIServerSetupPlugin plugin;

    public zAuctionHouseIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("zAuctionHouse"))
            throw new IllegalStateException("zAuctionHouse not found");
    }

    public boolean openAH(Player player) {
        return Bukkit.dispatchCommand(player, "ah");
    }

    public boolean clearExpired() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ah clearexpired");
    }

    public boolean clearAll() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ah clearall");
    }

    public boolean reloadAH() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ah reload");
    }

    public String buildContext() {
        return "=== zAuctionHouse ===\nAuction house active.\n";
    }
}