package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;

public class MaintenanceIntegration {

    private final AIServerSetupPlugin plugin;

    public MaintenanceIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("Maintenance"))
            throw new IllegalStateException("Maintenance not found");
    }

    public boolean enableMaintenance(String reason) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "maintenance on " + (reason.isBlank() ? "" : reason));
    }

    public boolean disableMaintenance() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "maintenance off");
    }

    public boolean addWhitelisted(String playerName) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "maintenance add " + playerName);
    }

    public boolean removeWhitelisted(String playerName) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "maintenance remove " + playerName);
    }

    public boolean setMotd(String motd) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "maintenance setmotd " + motd);
    }

    public boolean isInMaintenance() {
        try {
            Class<?> clz = Class.forName("eu.kennytv.maintenance.core.MaintenancePlugin");
            Object   inst = clz.getMethod("getInstance").invoke(null);
            return (boolean) inst.getClass().getMethod("isMaintenance").invoke(inst);
        } catch (Exception e) { return false; }
    }

    public String buildContext() {
        return "=== Maintenance ===\nMaintenance mode: " + isInMaintenance() + "\n";
    }
}