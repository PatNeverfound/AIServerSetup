package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PhoenixCratesIntegration {

    private final AIServerSetupPlugin plugin;

    public PhoenixCratesIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("PhoenixCrates"))
            throw new IllegalStateException("PhoenixCrates not found");
    }

    public boolean giveKey(Player player, String crateId, int amount) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "crates give " + player.getName() + " " + crateId + " " + amount);
    }

    public boolean openCrate(Player player, String crateId) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "crates open " + crateId + " " + player.getName());
    }

    public boolean previewCrate(Player player, String crateId) {
        return Bukkit.dispatchCommand(player, "crates preview " + crateId);
    }

    public boolean reloadCrates() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "crates reload");
    }
}