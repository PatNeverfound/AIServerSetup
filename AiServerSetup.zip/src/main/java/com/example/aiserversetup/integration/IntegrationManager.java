package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;

import java.util.*;
import java.util.logging.Logger;

public class IntegrationManager {

    private final AIServerSetupPlugin plugin;
    private final Logger log;

    // All integration instances (null = plugin not installed)
    private LuckPermsIntegration        luckPerms;
    private VaultIntegration            vault;
    private EssentialsIntegration       essentials;
    private WorldGuardIntegration       worldGuard;
    private WorldEditIntegration        worldEdit;
    private PAPIIntegration             papi;
    private DiscordSRVIntegration       discordSRV;
    private CitizensIntegration         citizens;
    private TABIntegration              tab;
    private CoreProtectIntegration      coreProtect;
    private McMMOIntegration            mcMMO;
    private MultiverseIntegration       multiverse;
    private TownyIntegration            towny;
    private CMIIntegration              cmi;
    private AdvancedEnchantmentsIntegration advEnchants;
    private ItemsAdderIntegration       itemsAdder;
    private OraxenIntegration           oraxen;
    private LibsDisguisesIntegration    libsDisguises;
    private LiteBanIntegration          liteBan;
    private GriefPreventionIntegration  griefPrevention;
    private VulcanIntegration           vulcan;
    private TebexIntegration            tebex;
    private DecentHologramsIntegration  decentHolograms;
    private ProtocolLibIntegration      protocolLib;
    private MarriageMasterIntegration   marriageMaster;
    private SkriptIntegration           skript;
    private MaintenanceIntegration      maintenance;
    private UltimateAutoRestartIntegration autoRestart;
    private TempFlyIntegration          tempFly;
    private SimpleRTPIntegration        simpleRTP;
    private zAuctionHouseIntegration    auctionHouse;
    private AxBoosterIntegration        axBooster;
    private AxGensIntegration           axGens;
    private AxVaultsIntegration         axVaults;
    private PhoenixCratesIntegration    phoenixCrates;
    private PlayerKits2Integration      playerKits2;
    private TrollBossIntegration        trollBoss;

    public IntegrationManager(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.log    = plugin.getLogger();
    }

    public void loadAll() {
        luckPerms       = tryLoad("LuckPerms",              () -> new LuckPermsIntegration(plugin));
        vault           = tryLoad("Vault",                  () -> new VaultIntegration(plugin));
        essentials      = tryLoad("EssentialsX",            () -> new EssentialsIntegration(plugin));
        worldGuard      = tryLoad("WorldGuard",             () -> new WorldGuardIntegration(plugin));
        worldEdit       = tryLoad("WorldEdit",              () -> new WorldEditIntegration(plugin));
        papi            = tryLoad("PlaceholderAPI",         () -> new PAPIIntegration(plugin));
        discordSRV      = tryLoad("DiscordSRV",             () -> new DiscordSRVIntegration(plugin));
        citizens        = tryLoad("Citizens",               () -> new CitizensIntegration(plugin));
        tab             = tryLoad("TAB",                    () -> new TABIntegration(plugin));
        coreProtect     = tryLoad("CoreProtect",            () -> new CoreProtectIntegration(plugin));
        mcMMO           = tryLoad("mcMMO",                  () -> new McMMOIntegration(plugin));
        multiverse      = tryLoad("Multiverse-Core",        () -> new MultiverseIntegration(plugin));
        towny           = tryLoad("Towny",                  () -> new TownyIntegration(plugin));
        cmi             = tryLoad("CMI",                    () -> new CMIIntegration(plugin));
        advEnchants     = tryLoad("AdvancedEnchantments",   () -> new AdvancedEnchantmentsIntegration(plugin));
        itemsAdder      = tryLoad("ItemsAdder",             () -> new ItemsAdderIntegration(plugin));
        oraxen          = tryLoad("Oraxen",                 () -> new OraxenIntegration(plugin));
        libsDisguises   = tryLoad("LibsDisguises",          () -> new LibsDisguisesIntegration(plugin));
        liteBan         = tryLoad("LiteBans",               () -> new LiteBanIntegration(plugin));
        griefPrevention = tryLoad("GriefPrevention",        () -> new GriefPreventionIntegration(plugin));
        vulcan          = tryLoad("Vulcan",                 () -> new VulcanIntegration(plugin));
        tebex           = tryLoad("Tebex",                  () -> new TebexIntegration(plugin));
        decentHolograms = tryLoad("DecentHolograms",        () -> new DecentHologramsIntegration(plugin));
        protocolLib     = tryLoad("ProtocolLib",            () -> new ProtocolLibIntegration(plugin));
        marriageMaster  = tryLoad("MarriageMaster",         () -> new MarriageMasterIntegration(plugin));
        skript          = tryLoad("Skript",                 () -> new SkriptIntegration(plugin));
        maintenance     = tryLoad("Maintenance",            () -> new MaintenanceIntegration(plugin));
        autoRestart     = tryLoad("UltimateAutoRestart",    () -> new UltimateAutoRestartIntegration(plugin));
        tempFly         = tryLoad("Tempfly",                () -> new TempFlyIntegration(plugin));
        simpleRTP       = tryLoad("SimpleRTP",              () -> new SimpleRTPIntegration(plugin));
        auctionHouse    = tryLoad("zAuctionHouse",          () -> new zAuctionHouseIntegration(plugin));
        axBooster       = tryLoad("AxBooster",              () -> new AxBoosterIntegration(plugin));
        axGens          = tryLoad("AxGens",                 () -> new AxGensIntegration(plugin));
        axVaults        = tryLoad("AxVaults",               () -> new AxVaultsIntegration(plugin));
        phoenixCrates   = tryLoad("PhoenixCrates",          () -> new PhoenixCratesIntegration(plugin));
        playerKits2     = tryLoad("PlayerKits2",            () -> new PlayerKits2Integration(plugin));
        trollBoss       = tryLoad("TrollBoss",              () -> new TrollBossIntegration(plugin));

        log.info("Loaded integrations: " + getLoadedList());
    }

    private <T> T tryLoad(String name, java.util.function.Supplier<T> factory) {
        if (plugin.getServer().getPluginManager().isPluginEnabled(name)) {
            try {
                T inst = factory.get();
                log.info("  ✔ " + name);
                return inst;
            } catch (Exception e) {
                log.warning("  ✘ " + name + ": " + e.getMessage());
            }
        }
        return null;
    }

    public String buildAIContext() {
        StringBuilder sb = new StringBuilder();
        ifNotNull(cmi,             sb, CMIIntegration::buildContext);
        ifNotNull(luckPerms,       sb, LuckPermsIntegration::buildContext);
        ifNotNull(vault,           sb, VaultIntegration::buildContext);
        ifNotNull(essentials,      sb, EssentialsIntegration::buildContext);
        ifNotNull(worldGuard,      sb, WorldGuardIntegration::buildContext);
        ifNotNull(papi,            sb, PAPIIntegration::buildContext);
        ifNotNull(mcMMO,           sb, McMMOIntegration::buildContext);
        ifNotNull(multiverse,      sb, MultiverseIntegration::buildContext);
        ifNotNull(towny,           sb, TownyIntegration::buildContext);
        ifNotNull(skript,          sb, SkriptIntegration::buildContext);
        ifNotNull(maintenance,     sb, MaintenanceIntegration::buildContext);
        ifNotNull(autoRestart,     sb, UltimateAutoRestartIntegration::buildContext);
        ifNotNull(decentHolograms, sb, DecentHologramsIntegration::buildContext);
        ifNotNull(griefPrevention, sb, GriefPreventionIntegration::buildContext);
        ifNotNull(vulcan,          sb, VulcanIntegration::buildContext);
        ifNotNull(tebex,           sb, TebexIntegration::buildContext);
        ifNotNull(auctionHouse,    sb, zAuctionHouseIntegration::buildContext);
        ifNotNull(oraxen,          sb, OraxenIntegration::buildContext);
        ifNotNull(itemsAdder,      sb, ItemsAdderIntegration::buildContext);
        ifNotNull(advEnchants,     sb, AdvancedEnchantmentsIntegration::buildContext);
        ifNotNull(protocolLib,     sb, ProtocolLibIntegration::buildContext);
        ifNotNull(marriageMaster,  sb, MarriageMasterIntegration::buildContext);
        return sb.toString();
    }

    private <T> void ifNotNull(T obj, StringBuilder sb, java.util.function.Function<T, String> fn) {
        if (obj != null) sb.append(fn.apply(obj));
    }

    public String getLoadedList() {
        List<String> loaded = new ArrayList<>();
        if (luckPerms       != null) loaded.add("LuckPerms");
        if (vault           != null) loaded.add("Vault");
        if (essentials      != null) loaded.add("EssentialsX");
        if (worldGuard      != null) loaded.add("WorldGuard");
        if (worldEdit       != null) loaded.add("WorldEdit");
        if (papi            != null) loaded.add("PAPI");
        if (discordSRV      != null) loaded.add("DiscordSRV");
        if (citizens        != null) loaded.add("Citizens");
        if (tab             != null) loaded.add("TAB");
        if (coreProtect     != null) loaded.add("CoreProtect");
        if (mcMMO           != null) loaded.add("mcMMO");
        if (multiverse      != null) loaded.add("Multiverse");
        if (towny           != null) loaded.add("Towny");
        if (cmi             != null) loaded.add("CMI");
        if (advEnchants     != null) loaded.add("AdvancedEnchantments");
        if (itemsAdder      != null) loaded.add("ItemsAdder");
        if (oraxen          != null) loaded.add("Oraxen");
        if (libsDisguises   != null) loaded.add("LibsDisguises");
        if (liteBan         != null) loaded.add("LiteBans");
        if (griefPrevention != null) loaded.add("GriefPrevention");
        if (vulcan          != null) loaded.add("Vulcan");
        if (tebex           != null) loaded.add("Tebex");
        if (decentHolograms != null) loaded.add("DecentHolograms");
        if (protocolLib     != null) loaded.add("ProtocolLib");
        if (marriageMaster  != null) loaded.add("MarriageMaster");
        if (skript          != null) loaded.add("Skript");
        if (maintenance     != null) loaded.add("Maintenance");
        if (autoRestart     != null) loaded.add("AutoRestart");
        if (tempFly         != null) loaded.add("TempFly");
        if (simpleRTP       != null) loaded.add("SimpleRTP");
        if (auctionHouse    != null) loaded.add("zAuctionHouse");
        if (axBooster       != null) loaded.add("AxBooster");
        if (axGens          != null) loaded.add("AxGens");
        if (axVaults        != null) loaded.add("AxVaults");
        if (phoenixCrates   != null) loaded.add("PhoenixCrates");
        if (playerKits2     != null) loaded.add("PlayerKits2");
        if (trollBoss       != null) loaded.add("TrollBoss");
        return String.join(", ", loaded);
    }

    // ── Getters ──────────────────────────────────────────────────────────────
    public LuckPermsIntegration            getLuckPerms()       { return luckPerms; }
    public VaultIntegration                getVault()           { return vault; }
    public EssentialsIntegration           getEssentials()      { return essentials; }
    public WorldGuardIntegration           getWorldGuard()      { return worldGuard; }
    public WorldEditIntegration            getWorldEdit()       { return worldEdit; }
    public PAPIIntegration                 getPapi()            { return papi; }
    public DiscordSRVIntegration           getDiscordSRV()      { return discordSRV; }
    public CitizensIntegration             getCitizens()        { return citizens; }
    public TABIntegration                  getTab()             { return tab; }
    public CoreProtectIntegration          getCoreProtect()     { return coreProtect; }
    public McMMOIntegration                getMcMMO()           { return mcMMO; }
    public MultiverseIntegration           getMultiverse()      { return multiverse; }
    public TownyIntegration                getTowny()           { return towny; }
    public CMIIntegration                  getCmi()             { return cmi; }
    public AdvancedEnchantmentsIntegration getAdvEnchants()     { return advEnchants; }
    public ItemsAdderIntegration           getItemsAdder()      { return itemsAdder; }
    public OraxenIntegration               getOraxen()          { return oraxen; }
    public LibsDisguisesIntegration        getLibsDisguises()   { return libsDisguises; }
    public LiteBanIntegration              getLiteBan()         { return liteBan; }
    public GriefPreventionIntegration      getGriefPrevention() { return griefPrevention; }
    public VulcanIntegration               getVulcan()          { return vulcan; }
    public TebexIntegration                getTebex()           { return tebex; }
    public DecentHologramsIntegration      getDecentHolograms() { return decentHolograms; }
    public ProtocolLibIntegration          getProtocolLib()     { return protocolLib; }
    public MarriageMasterIntegration       getMarriageMaster()  { return marriageMaster; }
    public SkriptIntegration               getSkript()          { return skript; }
    public MaintenanceIntegration          getMaintenance()     { return maintenance; }
    public UltimateAutoRestartIntegration  getAutoRestart()     { return autoRestart; }
    public TempFlyIntegration              getTempFly()         { return tempFly; }
    public SimpleRTPIntegration            getSimpleRTP()       { return simpleRTP; }
    public zAuctionHouseIntegration        getAuctionHouse()    { return auctionHouse; }
    public AxBoosterIntegration            getAxBooster()       { return axBooster; }
    public AxGensIntegration               getAxGens()          { return axGens; }
    public AxVaultsIntegration             getAxVaults()        { return axVaults; }
    public PhoenixCratesIntegration        getPhoenixCrates()   { return phoenixCrates; }
    public PlayerKits2Integration          getPlayerKits2()     { return playerKits2; }
    public TrollBossIntegration            getTrollBoss()       { return trollBoss; }
    public boolean has(String name) { return plugin.getServer().getPluginManager().isPluginEnabled(name); }
}