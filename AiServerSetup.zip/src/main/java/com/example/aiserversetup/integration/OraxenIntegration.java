package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import io.th0rgal.oraxen.api.OraxenItems;
import io.th0rgal.oraxen.items.ItemBuilder;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.stream.Collectors;

public class OraxenIntegration {

    private final AIServerSetupPlugin plugin;

    public OraxenIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("Oraxen"))
            throw new IllegalStateException("Oraxen not found");
    }

    public boolean giveItem(Player player, String itemId, int amount) {
        try {
            ItemBuilder builder = OraxenItems.getItemById(itemId);
            if (builder == null) return false;
            ItemStack item = builder.build();
            item.setAmount(amount);
            player.getInventory().addItem(item);
            return true;
        } catch (Exception e) { return false; }
    }

    public List<String> getItemIds() {
        try {
            return OraxenItems.getItems().stream()
                    .map(b -> b.getOraxenMeta().getItemId())
                    .collect(Collectors.toList());
        } catch (Exception e) { return List.of(); }
    }

    public boolean isOraxenItem(ItemStack item) {
        try {
            return OraxenItems.exists(item);
        } catch (Exception e) { return false; }
    }

    public String getOraxenId(ItemStack item) {
        try {
            return OraxenItems.getIdByItem(item);
        } catch (Exception e) { return null; }
    }

    public String buildContext() {
        return "=== Oraxen ===\nCustom items available. " + getItemIds().size() + " item(s) registered.\n";
    }
}