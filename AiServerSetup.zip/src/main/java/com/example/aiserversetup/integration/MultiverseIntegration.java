package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.onarandombox.MultiverseCore.MultiverseCore;
import com.onarandombox.MultiverseCore.api.*;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Multiverse-Core integration — world management, import, info.
 */
public class MultiverseIntegration {

    private final AIServerSetupPlugin plugin;
    private final MultiverseCore mv;
    private final MVWorldManager wm;

    public MultiverseIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.mv     = (MultiverseCore) plugin.getServer().getPluginManager().getPlugin("Multiverse-Core");
        if (mv == null) throw new IllegalStateException("Multiverse-Core not found");
        this.wm = mv.getMVWorldManager();
    }

    public List<String> getMVWorlds() {
        return wm.getMVWorlds().stream().map(MultiverseWorld::getName).collect(Collectors.toList());
    }

    public Map<String, String> getWorldInfo(String worldName) {
        MultiverseWorld w = wm.getMVWorld(worldName);
        if (w == null) return Map.of("error", "World not found");
        Map<String, String> info = new LinkedHashMap<>();
        info.put("name",       w.getName());
        info.put("alias",      w.getAlias());
        info.put("gamemode",   w.getGameMode().name());
        info.put("difficulty", w.getDifficulty().name());
        info.put("pvp",        String.valueOf(w.isPVPEnabled()));
        info.put("players",    String.valueOf(w.getCBWorld().getPlayers().size()));
        info.put("environment",w.getEnvironment().name());
        return info;
    }

    public boolean createWorld(String name, World.Environment env) {
        return wm.addWorld(name, env, null, null, null, null);
    }

    public boolean importWorld(String name, World.Environment env) {
        return wm.addWorld(name, env, null, null, null, null);
    }

    public boolean removeWorld(String name) {
        return wm.removeWorldFromConfig(name);
    }

    public boolean setWorldGameMode(String name, org.bukkit.GameMode mode) {
        MultiverseWorld w = wm.getMVWorld(name);
        if (w == null) return false;
        w.setGameMode(mode);
        return true;
    }

    public String buildContext() {
        StringBuilder sb = new StringBuilder("=== Multiverse-Core ===\n");
        sb.append("Worlds: ").append(String.join(", ", getMVWorlds())).append("\n");
        return sb.toString();
    }
}