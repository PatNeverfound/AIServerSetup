package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PlayerKits2Integration {

    private final AIServerSetupPlugin plugin;

    public PlayerKits2Integration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("PlayerKits2"))
            throw new IllegalStateException("PlayerKits2 not found");
    }

    public boolean giveKit(Player player, String kitName) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "pkits give " + player.getName() + " " + kitName);
    }

    public boolean resetKitCooldown(Player player, String kitName) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "pkits resetcooldown " + player.getName() + " " + kitName);
    }

    public boolean openKitsMenu(Player player) {
        return Bukkit.dispatchCommand(player, "kits");
    }

    public boolean reloadKits() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pkits reload");
    }
}