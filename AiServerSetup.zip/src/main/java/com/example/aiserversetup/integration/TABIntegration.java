package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import me.neznamy.tab.api.*;
import me.neznamy.tab.api.placeholder.PlaceholderManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * TAB plugin integration — set header/footer, scoreboard, nametags per player.
 */
public class TABIntegration {

    private final AIServerSetupPlugin plugin;
    private final TabAPI tabAPI;

    public TABIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.tabAPI = TabAPI.getInstance();
    }

    public void setHeaderFooter(Player player, String header, String footer) {
        TabPlayer tp = tabAPI.getPlayer(player.getUniqueId());
        if (tp == null) return;
        tabAPI.getHeaderFooterManager().setHeader(tp, header);
        tabAPI.getHeaderFooterManager().setFooter(tp, footer);
    }

    public void setGlobalHeaderFooter(String header, String footer) {
        for (Player player : Bukkit.getOnlinePlayers()) setHeaderFooter(player, header, footer);
    }

    public void setNametagPrefix(Player player, String prefix) {
        TabPlayer tp = tabAPI.getPlayer(player.getUniqueId());
        if (tp == null) return;
        tabAPI.getNameTagManager().setPrefix(tp, prefix);
    }

    public void setNametagSuffix(Player player, String suffix) {
        TabPlayer tp = tabAPI.getPlayer(player.getUniqueId());
        if (tp == null) return;
        tabAPI.getNameTagManager().setSuffix(tp, suffix);
    }

    public void resetPlayer(Player player) {
        TabPlayer tp = tabAPI.getPlayer(player.getUniqueId());
        if (tp == null) return;
        tabAPI.getHeaderFooterManager().resetHeader(tp);
        tabAPI.getHeaderFooterManager().resetFooter(tp);
    }
}