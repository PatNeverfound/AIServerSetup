package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class AxGensIntegration {

    private final AIServerSetupPlugin plugin;

    public AxGensIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("AxGens"))
            throw new IllegalStateException("AxGens not found");
    }

    public boolean giveGenerator(Player player, String genId, int amount) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "axgens give " + player.getName() + " " + genId + " " + amount);
    }

    public boolean openGensMenu(Player player) {
        return Bukkit.dispatchCommand(player, "gens");
    }

    public boolean reloadGens() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "axgens reload");
    }
}