package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.*;

/**
 * Full Vault Economy integration — balances, deposits, withdrawals, top balances.
 */
public class VaultIntegration {

    private final AIServerSetupPlugin plugin;
    private Economy economy;
    private boolean available = false;

    public VaultIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        setup();
    }

    private void setup() {
        RegisteredServiceProvider<Economy> rsp =
                plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) {
            economy   = rsp.getProvider();
            available = economy != null;
        }
    }

    public boolean isAvailable()  { return available; }
    public Economy getEconomy()   { return economy; }
    public String getCurrencyName(){ return available ? economy.currencyNameSingular() : "coins"; }

    public double getBalance(OfflinePlayer player) {
        return available ? economy.getBalance(player) : 0;
    }

    public boolean deposit(OfflinePlayer player, double amount) {
        return available && economy.depositPlayer(player, amount).transactionSuccess();
    }

    public boolean withdraw(OfflinePlayer player, double amount) {
        return available && economy.withdrawPlayer(player, amount).transactionSuccess();
    }

    public boolean setBalance(OfflinePlayer player, double amount) {
        if (!available) return false;
        double current = getBalance(player);
        if (current > amount) return economy.withdrawPlayer(player, current - amount).transactionSuccess();
        else                  return economy.depositPlayer(player, amount - current).transactionSuccess();
    }

    public List<Map.Entry<String, Double>> getTopBalances(int limit) {
        List<Map.Entry<String, Double>> list = new ArrayList<>();
        if (!available) return list;
        for (OfflinePlayer p : Bukkit.getOfflinePlayers()) {
            if (p.getName() != null) list.add(Map.entry(p.getName(), economy.getBalance(p)));
        }
        list.sort(Map.Entry.<String, Double>comparingByValue().reversed());
        return list.subList(0, Math.min(limit, list.size()));
    }

    public String buildContext() {
        if (!available) return "";
        return "=== Vault Economy ===\nCurrency: " + getCurrencyName() + "\nEconomy Provider: "
                + economy.getName() + "\n";
    }
}