package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class TempFlyIntegration {

    private final AIServerSetupPlugin plugin;

    public TempFlyIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("Tempfly"))
            throw new IllegalStateException("Tempfly not found");
    }

    public boolean grantFly(Player player, int seconds) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "tempfly add " + player.getName() + " " + seconds);
    }

    public boolean revokeFly(Player player) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tempfly remove " + player.getName());
    }

    public boolean setFlyTime(Player player, int seconds) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "tempfly set " + player.getName() + " " + seconds);
    }

    public boolean checkTime(Player player) {
        return Bukkit.dispatchCommand(player, "tempfly check");
    }
}