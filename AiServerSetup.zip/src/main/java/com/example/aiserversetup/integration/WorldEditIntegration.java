package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.*;
import org.bukkit.*;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

/**
 * WorldEdit integration — schematic listing, selection info, command dispatch.
 */
public class WorldEditIntegration {

    private final AIServerSetupPlugin plugin;

    public WorldEditIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        // Verify WE is accessible
        WorldEdit.getInstance();
    }

    public List<String> listSchematics() {
        File schematicDir = new File(plugin.getServer().getWorldContainer(),
                "config/WorldEdit/schematics");
        if (!schematicDir.exists()) {
            schematicDir = new File("plugins/WorldEdit/schematics");
        }
        String[] files = schematicDir.list((d, n) -> n.endsWith(".schem") || n.endsWith(".schematic"));
        return files == null ? List.of() : Arrays.asList(files);
    }

    public String getSelectionInfo(Player player) {
        try {
            var session = WorldEdit.getInstance().getSessionManager()
                    .getIfPresent(BukkitAdapter.adapt(player));
            if (session == null) return "No active selection.";
            var region = session.getSelectionRegion();
            BlockVector3 min = region.getMinimumPoint();
            BlockVector3 max = region.getMaximumPoint();
            return String.format("Selection: (%d,%d,%d) to (%d,%d,%d) — %d blocks",
                    min.x(), min.y(), min.z(), max.x(), max.y(), max.z(), region.getVolume());
        } catch (Exception e) { return "No selection or error: " + e.getMessage(); }
    }

    public boolean runCommand(Player player, String command) {
        return Bukkit.dispatchCommand(player, "worldedit:" + command);
    }
}