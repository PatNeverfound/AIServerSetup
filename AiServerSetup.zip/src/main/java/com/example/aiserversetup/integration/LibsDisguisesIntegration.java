package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import me.libraryaddict.disguise.DisguiseAPI;
import me.libraryaddict.disguise.disguisetypes.*;
import org.bukkit.entity.*;

public class LibsDisguisesIntegration {

    private final AIServerSetupPlugin plugin;

    public LibsDisguisesIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("LibsDisguises"))
            throw new IllegalStateException("LibsDisguises not found");
    }

    public boolean disguiseAsMob(Player player, EntityType type) {
        try {
            MobDisguise disguise = new MobDisguise(DisguiseType.getType(type));
            DisguiseAPI.disguiseToAll(player, disguise);
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean disguiseAsPlayer(Player player, String targetName) {
        try {
            PlayerDisguise disguise = new PlayerDisguise(targetName);
            DisguiseAPI.disguiseToAll(player, disguise);
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean undisguise(Player player) {
        try {
            DisguiseAPI.undisguiseToAll(player);
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean isDisguised(Player player) {
        return DisguiseAPI.isDisguised(player);
    }

    public String getDisguiseName(Player player) {
        try {
            Disguise d = DisguiseAPI.getDisguise(player, player);
            return d == null ? "None" : d.getType().name();
        } catch (Exception e) { return "Unknown"; }
    }
}