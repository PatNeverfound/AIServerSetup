package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.*;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.*;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.util.*;
import java.util.stream.Collectors;

/**
 * WorldGuard integration — list/create/delete regions, get/set flags, manage members.
 */
public class WorldGuardIntegration {

    private final AIServerSetupPlugin plugin;
    private final com.sk89q.worldguard.WorldGuard wg;

    public WorldGuardIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.wg     = WorldGuard.getInstance();
    }

    public List<String> getRegions(String worldName) {
        World w = Bukkit.getWorld(worldName);
        if (w == null) return List.of();
        RegionManager rm = wg.getPlatform().getRegionContainer()
                .get(BukkitAdapter.adapt(w));
        if (rm == null) return List.of();
        return new ArrayList<>(rm.getRegions().keySet());
    }

    public Map<String, String> getRegionInfo(String worldName, String regionId) {
        World w = Bukkit.getWorld(worldName);
        if (w == null) return Map.of();
        RegionManager rm = wg.getPlatform().getRegionContainer().get(BukkitAdapter.adapt(w));
        if (rm == null) return Map.of();
        ProtectedRegion r = rm.getRegion(regionId);
        if (r == null) return Map.of();

        Map<String, String> info = new LinkedHashMap<>();
        info.put("id",       r.getId());
        info.put("type",     r.getType().name());
        info.put("priority", String.valueOf(r.getPriority()));
        info.put("owners",   r.getOwners().toUserFriendlyString());
        info.put("members",  r.getMembers().toUserFriendlyString());
        info.put("flags",    r.getFlags().entrySet().stream()
                .map(e -> e.getKey().getName() + "=" + e.getValue())
                .collect(Collectors.joining(", ")));
        return info;
    }

    public boolean setFlag(String worldName, String regionId, String flagName, String value) {
        try {
            World w = Bukkit.getWorld(worldName);
            if (w == null) return false;
            RegionManager rm = wg.getPlatform().getRegionContainer().get(BukkitAdapter.adapt(w));
            if (rm == null) return false;
            ProtectedRegion r = rm.getRegion(regionId);
            if (r == null) return false;
            Flag<?> flag = Flags.fuzzyMatchFlag(wg.getFlagRegistry(), flagName);
            if (flag == null) return false;
            setFlagTyped(r, flag, value);
            rm.save();
            return true;
        } catch (Exception e) { return false; }
    }

    @SuppressWarnings("unchecked")
    private <T> void setFlagTyped(ProtectedRegion r, Flag<T> flag, String value) throws Exception {
        r.setFlag(flag, flag.parseInput(FlagContext.create().setSenderFacade(null).setInput(value).build()));
    }

    public boolean deleteRegion(String worldName, String regionId) {
        try {
            World w = Bukkit.getWorld(worldName);
            if (w == null) return false;
            RegionManager rm = wg.getPlatform().getRegionContainer().get(BukkitAdapter.adapt(w));
            if (rm == null) return false;
            rm.removeRegion(regionId);
            rm.save();
            return true;
        } catch (Exception e) { return false; }
    }

    public String buildContext() {
        StringBuilder sb = new StringBuilder("=== WorldGuard ===\n");
        for (World w : Bukkit.getWorlds()) {
            List<String> regions = getRegions(w.getName());
            if (!regions.isEmpty())
                sb.append("Regions in ").append(w.getName()).append(": ")
                  .append(String.join(", ", regions)).append("\n");
        }
        return sb.toString();
    }
}