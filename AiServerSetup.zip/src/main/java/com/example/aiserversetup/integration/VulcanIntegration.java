package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import me.frep.vulcan.api.VulcanAPI;
import me.frep.vulcan.api.data.VulcanData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

public class VulcanIntegration {

    private final AIServerSetupPlugin plugin;
    private final VulcanAPI api;

    public VulcanIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("Vulcan"))
            throw new IllegalStateException("Vulcan not found");
        this.api = VulcanAPI.Factory.getApi();
    }

    public int getViolations(Player player, String check) {
        try {
            VulcanData data = api.getVulcanData(player);
            return data == null ? 0 : data.getVl(check);
        } catch (Exception e) { return 0; }
    }

    public boolean isFlagged(Player player) {
        try {
            VulcanData data = api.getVulcanData(player);
            return data != null && data.isFlagged();
        } catch (Exception e) { return false; }
    }

    public Map<String, Integer> getAllViolations(Player player) {
        Map<String, Integer> map = new LinkedHashMap<>();
        try {
            VulcanData data = api.getVulcanData(player);
            if (data == null) return map;
            for (String check : List.of("KILLAURA", "AIM", "REACH", "SCAFFOLD", "SPEED",
                    "FLY", "NOFALL", "TIMER", "BADPACKETS", "INVENTORY")) {
                int vl = data.getVl(check);
                if (vl > 0) map.put(check, vl);
            }
        } catch (Exception ignored) {}
        return map;
    }

    public boolean kickFlaggedPlayers() {
        int kicked = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (isFlagged(p)) {
                p.kickPlayer("§cSuspected cheating detected.");
                kicked++;
            }
        }
        return kicked > 0;
    }

    public String buildContext() {
        StringBuilder sb = new StringBuilder("=== Vulcan AntiCheat ===\n");
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (isFlagged(p)) sb.append("FLAGGED: ").append(p.getName()).append("\n");
        }
        return sb.toString();
    }
}