package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import litebans.api.Database;
import litebans.api.*;
import org.bukkit.Bukkit;

import java.util.UUID;

public class LiteBanIntegration {

    private final AIServerSetupPlugin plugin;

    public LiteBanIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("LiteBans"))
            throw new IllegalStateException("LiteBans not found");
    }

    public boolean banPlayer(String playerName, String reason, String duration) {
        String cmd = "litebans:ban " + playerName + " " + duration + " " + reason;
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
    }

    public boolean unbanPlayer(String playerName) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "litebans:unban " + playerName);
    }

    public boolean mutePlayer(String playerName, String reason, String duration) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "litebans:mute " + playerName + " " + duration + " " + reason);
    }

    public boolean unmutePlayer(String playerName) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "litebans:unmute " + playerName);
    }

    public boolean kickPlayer(String playerName, String reason) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "litebans:kick " + playerName + " " + reason);
    }

    public boolean warnPlayer(String playerName, String reason) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "litebans:warn " + playerName + " " + reason);
    }

    public boolean isBanned(UUID uuid) {
        try {
            return Database.get().isVPNBanned(uuid.toString(), null);
        } catch (Exception e) { return false; }
    }
}