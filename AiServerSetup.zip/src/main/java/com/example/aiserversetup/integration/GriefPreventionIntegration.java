package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import me.ryanhamshire.GriefPrevention.*;
import org.bukkit.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class GriefPreventionIntegration {

    private final AIServerSetupPlugin plugin;
    private final GriefPrevention gp;

    public GriefPreventionIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.gp     = (GriefPrevention) plugin.getServer().getPluginManager().getPlugin("GriefPrevention");
        if (gp == null) throw new IllegalStateException("GriefPrevention not found");
    }

    public int getClaimCount(Player player) {
        return gp.dataStore.getPlayerData(player.getUniqueId()).getClaims().size();
    }

    public int getClaimBlocks(Player player) {
        PlayerData pd = gp.dataStore.getPlayerData(player.getUniqueId());
        return pd.getAccruedClaimBlocks() + pd.getBonusClaimBlocks();
    }

    public boolean giveClaimBlocks(Player player, int amount) {
        PlayerData pd = gp.dataStore.getPlayerData(player.getUniqueId());
        pd.setBonusClaimBlocks(pd.getBonusClaimBlocks() + amount);
        gp.dataStore.savePlayerData(player.getUniqueId(), pd);
        return true;
    }

    public boolean deleteAllClaims(Player player) {
        try {
            gp.dataStore.deleteClaimsForPlayer(player.getUniqueId(), true);
            return true;
        } catch (Exception e) { return false; }
    }

    public List<String> getClaimList(Player player) {
        return gp.dataStore.getPlayerData(player.getUniqueId()).getClaims().stream()
                .map(c -> c.getID() + " @ " + c.getLesserBoundaryCorner().getBlockX()
                        + "," + c.getLesserBoundaryCorner().getBlockZ())
                .collect(Collectors.toList());
    }

    public String buildContext() {
        return "=== GriefPrevention ===\nClaim system active.\n";
    }
}