package com.example.aiserversetup.integration;

import com.earth2me.essentials.*;
import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * EssentialsX integration — homes, kits, warps, mutes, jails, nicknames.
 */
public class EssentialsIntegration {

    private final AIServerSetupPlugin plugin;
    private final Essentials ess;

    public EssentialsIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.ess    = (Essentials) plugin.getServer().getPluginManager().getPlugin("Essentials");
        if (ess == null) throw new IllegalStateException("Essentials not found");
    }

    // ── Warps ────────────────────────────────────────────────────────────────

    public List<String> getWarps() {
        try {
            return new ArrayList<>(ess.getWarps().getList());
        } catch (Exception e) { return List.of(); }
    }

    public boolean deleteWarp(String name) {
        try {
            ess.getWarps().removeWarp(name);
            return true;
        } catch (Exception e) { return false; }
    }

    // ── Homes ────────────────────────────────────────────────────────────────

    public List<String> getPlayerHomes(Player player) {
        try {
            IUser u = ess.getUser(player);
            return new ArrayList<>(u.getHomes());
        } catch (Exception e) { return List.of(); }
    }

    public boolean deleteHome(Player player, String home) {
        try {
            IUser u = ess.getUser(player);
            u.delHome(home);
            return true;
        } catch (Exception e) { return false; }
    }

    // ── Nicknames ─────────────────────────────────────────────────────────────

    public boolean setNickname(Player player, String nickname) {
        try {
            IUser u = ess.getUser(player);
            u.setNickname(nickname);
            return true;
        } catch (Exception e) { return false; }
    }

    public String getNickname(Player player) {
        try {
            IUser u = ess.getUser(player);
            return u.getNickname();
        } catch (Exception e) { return player.getName(); }
    }

    // ── Mute/Jail ─────────────────────────────────────────────────────────────

    public boolean mutePlayer(Player player, boolean muted) {
        try {
            IUser u = ess.getUser(player);
            u.setMuted(muted);
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean jailPlayer(Player player, String jailName) {
        try {
            IUser u = ess.getUser(player);
            u.setJailName(jailName);
            u.setJailed(true);
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean unjailPlayer(Player player) {
        try {
            IUser u = ess.getUser(player);
            u.setJailed(false);
            return true;
        } catch (Exception e) { return false; }
    }

    // ── Balance ───────────────────────────────────────────────────────────────

    public double getBalance(Player player) {
        try {
            IUser u = ess.getUser(player);
            return u.getMoney().doubleValue();
        } catch (Exception e) { return 0; }
    }

    // ── AFK ──────────────────────────────────────────────────────────────────

    public boolean isAfk(Player player) {
        try {
            return ess.getUser(player).isAfk();
        } catch (Exception e) { return false; }
    }

    public List<String> getAfkPlayers() {
        return Bukkit.getOnlinePlayers().stream()
                .filter(this::isAfk)
                .map(Player::getName)
                .collect(Collectors.toList());
    }

    // ── Kits ─────────────────────────────────────────────────────────────────

    public List<String> getKits() {
        try {
            return new ArrayList<>(ess.getKits().getKitKeys());
        } catch (Exception e) { return List.of(); }
    }

    public String buildContext() {
        StringBuilder sb = new StringBuilder("=== EssentialsX ===\n");
        sb.append("Warps: ").append(getWarps().size()).append(" defined\n");
        sb.append("Kits: ").append(String.join(", ", getKits())).append("\n");
        List<String> afk = getAfkPlayers();
        if (!afk.isEmpty()) sb.append("AFK: ").append(String.join(", ", afk)).append("\n");
        return sb.toString();
    }
}