package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class AxBoosterIntegration {

    private final AIServerSetupPlugin plugin;

    public AxBoosterIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("AxBooster"))
            throw new IllegalStateException("AxBooster not found");
    }

    public boolean addBooster(Player player, String boosterType, double multiplier, int durationSeconds) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "axbooster add " + player.getName() + " " + boosterType + " " + multiplier + " " + durationSeconds);
    }

    public boolean removeBooster(Player player, String boosterType) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "axbooster remove " + player.getName() + " " + boosterType);
    }

    public boolean addGlobalBooster(String type, double multiplier, int seconds) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "axbooster addglobal " + type + " " + multiplier + " " + seconds);
    }
}