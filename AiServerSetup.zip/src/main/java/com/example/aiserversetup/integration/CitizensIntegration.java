package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.*;
import net.citizensnpcs.api.trait.TraitInfo;
import org.bukkit.*;
import org.bukkit.entity.EntityType;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Citizens NPC integration — list, create, remove, and configure NPCs.
 */
public class CitizensIntegration {

    private final AIServerSetupPlugin plugin;
    private final NPCRegistry registry;

    public CitizensIntegration(AIServerSetupPlugin plugin) {
        this.plugin   = plugin;
        this.registry = CitizensAPI.getNPCRegistry();
    }

    public List<String> listNPCs() {
        List<String> list = new ArrayList<>();
        for (NPC npc : registry) {
            list.add(npc.getId() + ": " + npc.getName()
                    + " (" + npc.getEntityType().name() + ")"
                    + (npc.isSpawned() ? " [spawned at " + locationStr(npc.getEntity().getLocation()) + "]"
                                       : " [despawned]"));
        }
        return list;
    }

    public NPC createNPC(String name, EntityType type, Location location) {
        NPC npc = registry.createNPC(type, name);
        npc.spawn(location);
        return npc;
    }

    public boolean removeNPC(int id) {
        NPC npc = registry.getById(id);
        if (npc == null) return false;
        npc.destroy();
        return true;
    }

    public boolean setNPCName(int id, String name) {
        NPC npc = registry.getById(id);
        if (npc == null) return false;
        npc.setName(name);
        return true;
    }

    public boolean teleportNPC(int id, Location loc) {
        NPC npc = registry.getById(id);
        if (npc == null || !npc.isSpawned()) return false;
        npc.teleport(loc, org.bukkit.event.player.PlayerTeleportEvent.TeleportCause.PLUGIN);
        return true;
    }

    public int getNPCCount() {
        int count = 0;
        for (NPC ignored : registry) count++;
        return count;
    }

    private String locationStr(Location l) {
        return l == null ? "unknown" :
                String.format("%s(%.0f,%.0f,%.0f)", l.getWorld().getName(), l.getX(), l.getY(), l.getZ());
    }
}