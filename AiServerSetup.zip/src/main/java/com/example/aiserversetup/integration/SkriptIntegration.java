package com.example.aiserversetup.integration;

import ch.njol.skript.Skript;
import ch.njol.skript.lang.function.Functions;
import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class SkriptIntegration {

    private final AIServerSetupPlugin plugin;

    public SkriptIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("Skript"))
            throw new IllegalStateException("Skript not found");
    }

    /** List all loaded skript files. */
    public List<String> getLoadedScripts() {
        File dir = new File("plugins/Skript/scripts");
        if (!dir.exists()) return List.of();
        String[] files = dir.list((d, n) -> n.endsWith(".sk") && !n.startsWith("-"));
        return files == null ? List.of() : Arrays.asList(files);
    }

    /** Write and load an AI-generated skript file. */
    public boolean createScript(String filename, String content) {
        try {
            File f = new File("plugins/Skript/scripts/" + filename + ".sk");
            Files.writeString(f.toPath(), content);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "skript reload " + filename);
            return true;
        } catch (Exception e) { return false; }
    }

    /** Delete a skript file. */
    public boolean deleteScript(String filename) {
        File f = new File("plugins/Skript/scripts/" + filename + ".sk");
        if (!f.exists()) return false;
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "skript disable " + filename);
        return f.delete();
    }

    /** Reload a specific script. */
    public boolean reloadScript(String filename) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "skript reload " + filename);
    }

    /** Reload all scripts. */
    public boolean reloadAll() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "skript reload all");
    }

    public String buildContext() {
        return "=== Skript ===\nLoaded scripts: " + String.join(", ", getLoadedScripts()) + "\n";
    }
}