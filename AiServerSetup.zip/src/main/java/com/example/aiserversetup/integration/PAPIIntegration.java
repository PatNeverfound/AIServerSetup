package com/example/aiserversetup/integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import me.clip.placeholderapi.PlaceholderAPI;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * PlaceholderAPI integration — parse placeholders, list/download expansions,
 * and register a custom AIServerSetup placeholder expansion.
 */
public class PAPIIntegration {

    private final AIServerSetupPlugin plugin;

    public PAPIIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        registerExpansion();
    }

    /** Parse PAPI placeholders for a player. */
    public String parse(Player player, String text) {
        return PlaceholderAPI.setPlaceholders(player, text);
    }

    /** Parse offline/static placeholders. */
    public String parseBracketed(Player player, String text) {
        return PlaceholderAPI.setBracketPlaceholders(player, text);
    }

    /** List all registered expansions. */
    public List<String> getRegisteredExpansions() {
        return PlaceholderAPI.getRegisteredIdentifiers().stream().sorted().collect(Collectors.toList());
    }

    /** Download an expansion from eCloud. */
    public boolean downloadExpansion(String name) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "papi ecloud download " + name);
    }

    /** Reload all expansions. */
    public boolean reloadExpansions() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "papi reload");
    }

    /** Download recommended expansions for all installed plugins. */
    public void downloadRecommendedExpansions() {
        String[] recommended = {
            "LuckPerms", "Vault", "EssentialsX", "Server", "Player",
            "Math", "Statistic", "Javascript", "CheckPermission",
            "BungeeCord", "MVdWPlaceholderAPI", "mcMMO", "Towny",
            "WorldGuard", "Jobs", "DiscordSRV", "Citizens"
        };
        for (String exp : recommended) {
            downloadExpansion(exp);
        }
    }

    /** Register AIServerSetup as its own PAPI expansion. */
    private void registerExpansion() {
        new PlaceholderExpansion() {
            @Override public String getIdentifier() { return "aiserversetup"; }
            @Override public String getAuthor()     { return "PatNeverfound"; }
            @Override public String getVersion()    { return "3.0.0"; }
            @Override public boolean persist()      { return true; }

            @Override
            public String onPlaceholderRequest(Player player, String params) {
                return switch (params.toLowerCase()) {
                    case "model"          -> plugin.getAiClient().getModel();
                    case "total_tokens"   -> String.valueOf(plugin.getTokenTracker().getTotalTokens());
                    case "total_cost"     -> String.format("$%.4f", plugin.getTokenTracker().estimateCostUSD());
                    case "requests"       -> String.valueOf(plugin.getTokenTracker().getRequestCount());
                    case "history_size"   -> player == null ? "0" :
                            String.valueOf(plugin.getConversations().historySize(player.getName()));
                    case "integrations"   -> plugin.getIntegrations().getLoadedList();
                    default               -> null;
                };
            }
        }.register();
    }

    public String buildContext() {
        return "=== PlaceholderAPI ===\nExpansions: " + String.join(", ", getRegisteredExpansions()) + "\n";
    }
}