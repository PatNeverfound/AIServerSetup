package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.palmergames.bukkit.towny.*;
import com.palmergames.bukkit.towny.object.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Towny Advanced integration — towns, nations, residents, plots.
 */
public class TownyIntegration {

    private final AIServerSetupPlugin plugin;
    private final TownyAPI api;

    public TownyIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.api    = TownyAPI.getInstance();
    }

    public List<String> getTowns() {
        return TownyUniverse.getInstance().getTowns().stream()
                .map(Town::getName).sorted().collect(Collectors.toList());
    }

    public List<String> getNations() {
        return TownyUniverse.getInstance().getNations().stream()
                .map(Nation::getName).sorted().collect(Collectors.toList());
    }

    public Map<String, String> getTownInfo(String townName) {
        try {
            Town t = TownyUniverse.getInstance().getTown(townName);
            if (t == null) return Map.of("error", "Town not found");
            Map<String, String> info = new LinkedHashMap<>();
            info.put("name",       t.getName());
            info.put("mayor",      t.getMayor().getName());
            info.put("residents",  String.valueOf(t.getNumResidents()));
            info.put("plots",      String.valueOf(t.getTownBlocks().size()));
            info.put("balance",    String.valueOf(t.getAccount().getHoldingBalance()));
            info.put("open",       String.valueOf(t.isOpen()));
            info.put("nation",     t.hasNation() ? t.getNation().getName() : "None");
            return info;
        } catch (Exception e) { return Map.of("error", e.getMessage()); }
    }

    public String getPlayerTown(Player player) {
        try {
            Resident res = TownyUniverse.getInstance().getResident(player.getUniqueId());
            return res != null && res.hasTown() ? res.getTownOrNull().getName() : "No town";
        } catch (Exception e) { return "Unknown"; }
    }

    public boolean deleteTown(String name) {
        try {
            Town t = TownyUniverse.getInstance().getTown(name);
            if (t == null) return false;
            TownyUniverse.getInstance().removeTown(t);
            return true;
        } catch (Exception e) { return false; }
    }

    public String buildContext() {
        return "=== Towny ===\nTowns: " + getTowns().size()
                + " | Nations: " + getNations().size() + "\n";
    }
}