package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class AdvancedEnchantmentsIntegration {

    private final AIServerSetupPlugin plugin;

    public AdvancedEnchantmentsIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!isPresent()) throw new IllegalStateException("AdvancedEnchantments not available");
    }

    public boolean isPresent() {
        return plugin.getServer().getPluginManager().isPluginEnabled("AdvancedEnchantments");
    }

    /** Get list of registered custom enchant names via console command reflection. */
    public List<String> getEnchantNames() {
        // AE does not expose a stable public API; we use command delegation
        // Real implementations should hook via their API jar
        try {
            Class<?> ae = Class.forName("me.egg82.ae.api.AdvancedEnchantmentAPI");
            Object api = ae.getMethod("getAPI").invoke(null);
            Object set = api.getClass().getMethod("getEnchantments").invoke(api);
            return new ArrayList<>(((Collection<?>) set).stream()
                    .map(Object::toString).toList());
        } catch (Exception e) {
            return List.of("(Enchants listed via /ae list)");
        }
    }

    /** Apply a custom enchant to the item in the player's hand. */
    public boolean addEnchant(Player player, String enchantName, int level) {
        try {
            Class<?> ae  = Class.forName("me.egg82.ae.api.AdvancedEnchantmentAPI");
            Object   api = ae.getMethod("getAPI").invoke(null);
            Object   enc = api.getClass().getMethod("getEnchantment", String.class)
                    .invoke(api, enchantName);
            if (enc == null) return false;
            ItemStack item = player.getInventory().getItemInMainHand();
            api.getClass().getMethod("addEnchant", ItemStack.class, enc.getClass(), int.class)
                    .invoke(api, item, enc, level);
            return true;
        } catch (Exception e) {
            return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    "ae enchant " + player.getName() + " " + enchantName + " " + level);
        }
    }

    public String buildContext() {
        return "=== AdvancedEnchantments ===\nCustom enchantments available. Use enchant/remove via AI.\n";
    }
}