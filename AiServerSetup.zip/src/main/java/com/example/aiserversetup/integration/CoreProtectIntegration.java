package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import net.coreprotect.CoreProtect;
import net.coreprotect.CoreProtectAPI;
import org.bukkit.Location;
import org.bukkit.block.Block;

import java.util.*;
import java.util.stream.Collectors;

/**
 * CoreProtect integration — block history lookup, rollback, restore.
 */
public class CoreProtectIntegration {

    private final AIServerSetupPlugin plugin;
    private final CoreProtectAPI api;

    public CoreProtectIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        CoreProtect cp = (CoreProtect) plugin.getServer().getPluginManager().getPlugin("CoreProtect");
        if (cp == null) throw new IllegalStateException("CoreProtect not found");
        this.api = cp.getAPI();
        if (!api.isEnabled()) throw new IllegalStateException("CoreProtect API disabled");
    }

    /** Look up the block change history for a location. */
    public List<String> lookupBlock(Location location) {
        List<String[]> raw = api.blockLookup(location.getBlock(), 0);
        if (raw == null) return List.of();
        return raw.stream().map(arr ->
                String.format("[%s] %s %s block %s",
                        api.parseTime(Long.parseLong(arr[0])),
                        arr[6], arr[1].equals("1") ? "placed" : "broke", arr[2]))
                .collect(Collectors.toList());
    }

    /** Rollback all actions by a player in the last N seconds. */
    public boolean rollback(String playerName, int seconds, Location center, int radius) {
        try {
            String[] user = { playerName };
            int[] action  = { 0, 1 }; // 0=block break, 1=block place
            return api.performRollback(seconds, Arrays.asList(user), null, null,
                    action, null, radius, center) > 0;
        } catch (Exception e) { return false; }
    }

    /** Restore (undo a rollback) for a player. */
    public boolean restore(String playerName, int seconds, Location center, int radius) {
        try {
            String[] user = { playerName };
            int[] action  = { 0, 1 };
            return api.performRestore(seconds, Arrays.asList(user), null, null,
                    action, null, radius, center) > 0;
        } catch (Exception e) { return false; }
    }

    public boolean isEnabled() { return api.isEnabled(); }
}