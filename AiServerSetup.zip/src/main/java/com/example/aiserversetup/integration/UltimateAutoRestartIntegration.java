package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;

public class UltimateAutoRestartIntegration {

    private final AIServerSetupPlugin plugin;

    public UltimateAutoRestartIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("UltimateAutoRestart"))
            throw new IllegalStateException("UltimateAutoRestart not found");
    }

    public boolean scheduleRestart(int seconds) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "uar restart " + seconds);
    }

    public boolean cancelRestart() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "uar cancel");
    }

    public boolean setRestartTime(String time) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "uar settime " + time);
    }

    public boolean forceRestart() {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "uar forcerestart");
    }

    public String buildContext() {
        return "=== UltimateAutoRestart ===\nAuto-restart scheduler active.\n";
    }
}