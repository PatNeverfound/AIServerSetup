package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import eu.decentsoftware.holograms.api.DHAPI;
import eu.decentsoftware.holograms.api.holograms.Hologram;
import org.bukkit.Location;

import java.util.*;

public class DecentHologramsIntegration {

    private final AIServerSetupPlugin plugin;

    public DecentHologramsIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("DecentHolograms"))
            throw new IllegalStateException("DecentHolograms not found");
    }

    public boolean createHologram(String name, Location loc, List<String> lines) {
        try {
            Hologram h = DHAPI.createHologram(name, loc, lines);
            return h != null;
        } catch (Exception e) { return false; }
    }

    public boolean deleteHologram(String name) {
        try {
            return DHAPI.removeHologram(name);
        } catch (Exception e) { return false; }
    }

    public boolean setLine(String name, int line, String content) {
        try {
            DHAPI.setHologramLine(DHAPI.getHologram(name), line, content);
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean addLine(String name, String content) {
        try {
            DHAPI.addHologramLine(DHAPI.getHologram(name), content);
            return true;
        } catch (Exception e) { return false; }
    }

    public List<String> listHolograms() {
        try {
            return new ArrayList<>(DHAPI.getHolograms().stream()
                    .map(h -> h.getName() + " @ " + locStr(h.getLocation()))
                    .toList());
        } catch (Exception e) { return List.of(); }
    }

    private String locStr(Location l) {
        if (l == null) return "unknown";
        return l.getWorld().getName() + " " + l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ();
    }

    public String buildContext() {
        return "=== DecentHolograms ===\nHolograms: " + listHolograms().size() + " active.\n";
    }
}