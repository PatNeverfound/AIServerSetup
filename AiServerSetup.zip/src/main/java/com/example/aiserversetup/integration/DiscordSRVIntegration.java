package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import github.scarsz.discordsrv.DiscordSRV;
import github.scarsz.discordsrv.dependencies.jda.api.entities.*;
import org.bukkit.Bukkit;

import java.util.*;

/**
 * DiscordSRV integration — send messages to channels, get channel mappings,
 * check player link status.
 */
public class DiscordSRVIntegration {

    private final AIServerSetupPlugin plugin;
    private final DiscordSRV discordSRV;

    public DiscordSRVIntegration(AIServerSetupPlugin plugin) {
        this.plugin    = plugin;
        this.discordSRV= DiscordSRV.getPlugin();
    }

    /** Send a message to a Discord channel by game-channel name. */
    public boolean sendToChannel(String gameChannelName, String message) {
        try {
            discordSRV.sendMessage(discordSRV.getDestinationGameChannelNameForTextChannel(
                    discordSRV.getMainTextChannel()), message);
            return true;
        } catch (Exception e) { return false; }
    }

    /** Send to the main linked channel. */
    public boolean sendToMain(String message) {
        try {
            TextChannel ch = discordSRV.getMainTextChannel();
            if (ch == null) return false;
            ch.sendMessage(message).queue();
            return true;
        } catch (Exception e) { return false; }
    }

    /** Get channel mappings: game channel → discord channel ID. */
    public Map<String, String> getChannelMappings() {
        Map<String, String> map = new LinkedHashMap<>();
        try {
            discordSRV.getChannels().forEach((k, v) -> map.put(k, v.getId()));
        } catch (Exception ignored) {}
        return map;
    }

    /** Check if a player is linked to Discord. */
    public boolean isLinked(java.util.UUID uuid) {
        try {
            return discordSRV.getAccountLinkManager().isLinked(uuid);
        } catch (Exception e) { return false; }
    }

    /** Get Discord tag for a linked player. */
    public String getDiscordTag(java.util.UUID uuid) {
        try {
            String id = discordSRV.getAccountLinkManager().getDiscordId(uuid);
            if (id == null) return "Not linked";
            User user = discordSRV.getJda().getUserById(id);
            return user == null ? "Unknown" : user.getAsTag();
        } catch (Exception e) { return "Error"; }
    }

    /** Get count of linked players online. */
    public long getLinkedPlayerCount() {
        return Bukkit.getOnlinePlayers().stream()
                .filter(p -> isLinked(p.getUniqueId())).count();
    }
}