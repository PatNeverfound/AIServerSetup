package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class TrollBossIntegration {

    private final AIServerSetupPlugin plugin;

    public TrollBossIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("TrollBoss"))
            throw new IllegalStateException("TrollBoss not found");
    }

    public boolean trollPlayer(Player target, String trollType) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "troll " + target.getName() + " " + trollType);
    }

    public boolean openTrollMenu(Player staff, Player target) {
        return Bukkit.dispatchCommand(staff, "troll " + target.getName());
    }

    public boolean fakeBan(Player target) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "troll " + target.getName() + " fakeban");
    }

    public boolean lightning(Player target) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "troll " + target.getName() + " lightning");
    }
}