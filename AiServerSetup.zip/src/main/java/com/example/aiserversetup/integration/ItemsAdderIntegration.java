package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import dev.lone.itemsadder.api.CustomStack;
import dev.lone.itemsadder.api.ItemsAdder;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class ItemsAdderIntegration {

    private final AIServerSetupPlugin plugin;

    public ItemsAdderIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("ItemsAdder"))
            throw new IllegalStateException("ItemsAdder not found");
    }

    /** Give a player an ItemsAdder custom item by namespace:id */
    public boolean giveItem(Player player, String namespaceId, int amount) {
        try {
            CustomStack cs = CustomStack.getInstance(namespaceId);
            if (cs == null) return false;
            ItemStack item = cs.getItemStack().clone();
            item.setAmount(amount);
            player.getInventory().addItem(item);
            return true;
        } catch (Exception e) { return false; }
    }

    /** Check if an item in hand is a specific IA item. */
    public boolean isCustomItem(ItemStack item, String namespaceId) {
        try {
            CustomStack cs = CustomStack.byItemStack(item);
            return cs != null && cs.getNamespacedID().equals(namespaceId);
        } catch (Exception e) { return false; }
    }

    /** List all registered custom item IDs. */
    public List<String> getRegisteredItems() {
        try {
            return new ArrayList<>(ItemsAdder.getAllItems().keySet());
        } catch (Exception e) { return List.of("(use /iaget to list)"); }
    }

    /** Spawn a custom furniture/entity. */
    public boolean spawnFurniture(org.bukkit.Location loc, String namespaceId) {
        try {
            dev.lone.itemsadder.api.CustomFurniture.spawn(namespaceId, loc);
            return true;
        } catch (Exception e) { return false; }
    }

    public String buildContext() {
        return "=== ItemsAdder ===\nCustom items/blocks/furniture loaded. Namespace items available.\n";
    }
}