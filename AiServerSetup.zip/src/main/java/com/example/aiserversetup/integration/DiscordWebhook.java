package com.example.aiserversetup.integration;

import org.bukkit.configuration.file.FileConfiguration;

import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;

/** Sends Discord webhook notifications for AI actions. */
public class DiscordWebhook {

    private final boolean enabled;
    private final String webhookUrl;
    private final boolean notifyApply;
    private final HttpClient http = HttpClient.newHttpClient();

    public DiscordWebhook(FileConfiguration config) {
        this.enabled      = config.getBoolean("discord.enabled", false);
        this.webhookUrl   = config.getString("discord.webhook-url", "");
        this.notifyApply  = config.getBoolean("discord.notify-on-apply", true);
    }

    public void sendIfEnabled(String message) {
        if (!enabled || webhookUrl.isBlank()) return;
        send(message);
    }

    public void send(String message) {
        if (webhookUrl.isBlank()) return;
        String body = "{\"content\":\"" + escape(message) + "\"}";
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(webhookUrl))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();
        http.sendAsync(req, HttpResponse.BodyHandlers.discarding());
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "");
    }
}