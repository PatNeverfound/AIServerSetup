package com.example.aiserversetup.integration;

import com.comphenix.protocol.*;
import com.comphenix.protocol.events.*;
import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.entity.Player;

import java.util.*;

public class ProtocolLibIntegration {

    private final AIServerSetupPlugin plugin;
    private final ProtocolManager pm;

    public ProtocolLibIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("ProtocolLib"))
            throw new IllegalStateException("ProtocolLib not found");
        this.pm = ProtocolLibrary.getProtocolManager();
    }

    /** Add a packet listener. */
    public void addListener(PacketType type, PacketAdapter adapter) {
        pm.addPacketListener(adapter);
    }

    /** Remove all listeners for this plugin. */
    public void removeAllListeners() {
        pm.removePacketListeners(plugin);
    }

    /** Send a fake chat message to a player. */
    public boolean sendFakeChat(Player player, String message) {
        try {
            PacketContainer packet = pm.createPacket(PacketType.Play.Server.CHAT);
            packet.getStrings().write(0, message);
            pm.sendServerPacket(player, packet);
            return true;
        } catch (Exception e) { return false; }
    }

    /** Get list of registered packet listener types for our plugin. */
    public List<String> getRegisteredListeners() {
        List<String> types = new ArrayList<>();
        try {
            for (PacketListener l : pm.getPacketListeners()) {
                if (l.getPlugin().equals(plugin)) {
                    l.getSendingWhitelist().getTypes().forEach(t -> types.add("SEND:" + t));
                    l.getReceivingWhitelist().getTypes().forEach(t -> types.add("RECV:" + t));
                }
            }
        } catch (Exception ignored) {}
        return types;
    }

    public String buildContext() {
        return "=== ProtocolLib ===\nPacket interception available.\n";
    }
}