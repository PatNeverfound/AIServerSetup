package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import at.pcgamingfreaks.MarriageMaster.API.*;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class MarriageMasterIntegration {

    private final AIServerSetupPlugin plugin;
    private final MarriageMasterAPI api;

    public MarriageMasterIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        if (!plugin.getServer().getPluginManager().isPluginEnabled("MarriageMaster"))
            throw new IllegalStateException("MarriageMaster not found");
        this.api = MarriageMasterAPI.getAPI();
    }

    public boolean isMarried(Player player) {
        return api.isMarried(plugin.getServer().getOfflinePlayer(player.getUniqueId()));
    }

    public String getPartner(Player player) {
        try {
            MarriagePlayer mp = api.getPlayerData(plugin.getServer().getOfflinePlayer(player.getUniqueId()));
            if (mp == null || !mp.isMarried()) return "None";
            return mp.getPartner(mp).getName();
        } catch (Exception e) { return "Unknown"; }
    }

    public boolean divorce(Player player) {
        return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "marry divorce " + player.getName() + " force");
    }

    public String buildContext() {
        return "=== MarriageMaster ===\nMarriage system active.\n";
    }
}