package com.example.aiserversetup.integration;

import com.example.aiserversetup.AIServerSetupPlugin;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.model.user.User;
import net.luckperms.api.node.Node;
import net.luckperms.api.node.types.*;
import net.luckperms.api.track.Track;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Full LuckPerms integration — groups, tracks, permissions, prefixes, promotions.
 */
public class LuckPermsIntegration {

    private final AIServerSetupPlugin plugin;
    private final LuckPerms api;

    public LuckPermsIntegration(AIServerSetupPlugin plugin) {
        this.plugin = plugin;
        this.api    = plugin.getServer().getServicesManager().load(LuckPerms.class);
        if (api == null) throw new IllegalStateException("LuckPerms service not available.");
    }

    // ── Groups ───────────────────────────────────────────────────────────────

    public List<String> getGroups() {
        return api.getGroupManager().getLoadedGroups()
                .stream().map(Group::getName).sorted().collect(Collectors.toList());
    }

    public boolean createGroup(String name) {
        try {
            api.getGroupManager().createAndLoadGroup(name).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean deleteGroup(String name) {
        try {
            Group g = api.getGroupManager().getGroup(name);
            if (g == null) return false;
            api.getGroupManager().deleteGroup(g).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean setGroupPrefix(String groupName, int weight, String prefix) {
        try {
            Group g = api.getGroupManager().loadGroup(groupName).join().orElse(null);
            if (g == null) return false;
            g.data().add(PrefixNode.builder(prefix, weight).build());
            api.getGroupManager().saveGroup(g).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean setGroupSuffix(String groupName, int weight, String suffix) {
        try {
            Group g = api.getGroupManager().loadGroup(groupName).join().orElse(null);
            if (g == null) return false;
            g.data().add(SuffixNode.builder(suffix, weight).build());
            api.getGroupManager().saveGroup(g).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean addGroupPermission(String groupName, String permission) {
        try {
            Group g = api.getGroupManager().loadGroup(groupName).join().orElse(null);
            if (g == null) return false;
            g.data().add(Node.builder(permission).build());
            api.getGroupManager().saveGroup(g).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean removeGroupPermission(String groupName, String permission) {
        try {
            Group g = api.getGroupManager().loadGroup(groupName).join().orElse(null);
            if (g == null) return false;
            g.data().remove(Node.builder(permission).build());
            api.getGroupManager().saveGroup(g).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean setGroupWeight(String groupName, int weight) {
        try {
            Group g = api.getGroupManager().loadGroup(groupName).join().orElse(null);
            if (g == null) return false;
            g.data().add(WeightNode.builder(weight).build());
            api.getGroupManager().saveGroup(g).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean setGroupParent(String childGroup, String parentGroup) {
        try {
            Group child = api.getGroupManager().loadGroup(childGroup).join().orElse(null);
            if (child == null) return false;
            child.data().add(InheritanceNode.builder(parentGroup).build());
            api.getGroupManager().saveGroup(child).join();
            return true;
        } catch (Exception e) { return false; }
    }

    // ── Users ────────────────────────────────────────────────────────────────

    public boolean addPlayerToGroup(UUID uuid, String groupName) {
        try {
            User user = api.getUserManager().loadUser(uuid).join();
            user.data().add(InheritanceNode.builder(groupName).build());
            api.getUserManager().saveUser(user).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean removePlayerFromGroup(UUID uuid, String groupName) {
        try {
            User user = api.getUserManager().loadUser(uuid).join();
            user.data().remove(InheritanceNode.builder(groupName).build());
            api.getUserManager().saveUser(user).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean setPrimaryGroup(UUID uuid, String groupName) {
        try {
            User user = api.getUserManager().loadUser(uuid).join();
            user.setPrimaryGroup(groupName);
            api.getUserManager().saveUser(user).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public String getPrimaryGroup(UUID uuid) {
        try {
            User user = api.getUserManager().loadUser(uuid).join();
            return user.getPrimaryGroup();
        } catch (Exception e) { return "default"; }
    }

    public List<String> getPlayerGroups(UUID uuid) {
        try {
            User user = api.getUserManager().loadUser(uuid).join();
            return user.getInheritedGroups(api.getContextManager().getStaticQueryOptions())
                    .stream().map(Group::getName).collect(Collectors.toList());
        } catch (Exception e) { return List.of(); }
    }

    public boolean addPlayerPermission(UUID uuid, String permission) {
        try {
            User user = api.getUserManager().loadUser(uuid).join();
            user.data().add(Node.builder(permission).build());
            api.getUserManager().saveUser(user).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean setPlayerPrefix(UUID uuid, int weight, String prefix) {
        try {
            User user = api.getUserManager().loadUser(uuid).join();
            user.data().add(PrefixNode.builder(prefix, weight).build());
            api.getUserManager().saveUser(user).join();
            return true;
        } catch (Exception e) { return false; }
    }

    // ── Tracks ───────────────────────────────────────────────────────────────

    public List<String> getTracks() {
        return api.getTrackManager().getLoadedTracks()
                .stream().map(Track::getName).sorted().collect(Collectors.toList());
    }

    public boolean createTrack(String name) {
        try {
            api.getTrackManager().createAndLoadTrack(name).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean addGroupToTrack(String trackName, String groupName) {
        try {
            Track t = api.getTrackManager().loadTrack(trackName).join().orElse(null);
            if (t == null) return false;
            t.appendGroup(groupName);
            api.getTrackManager().saveTrack(t).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public List<String> getTrackGroups(String trackName) {
        try {
            Track t = api.getTrackManager().loadTrack(trackName).join().orElse(null);
            return t == null ? List.of() : t.getGroups();
        } catch (Exception e) { return List.of(); }
    }

    public boolean promotePlayer(UUID uuid, String trackName) {
        try {
            User user  = api.getUserManager().loadUser(uuid).join();
            Track track = api.getTrackManager().loadTrack(trackName).join().orElse(null);
            if (track == null) return false;
            track.promote(user, api.getContextManager().getStaticQueryOptions());
            api.getUserManager().saveUser(user).join();
            return true;
        } catch (Exception e) { return false; }
    }

    public boolean demotePlayer(UUID uuid, String trackName) {
        try {
            User user  = api.getUserManager().loadUser(uuid).join();
            Track track = api.getTrackManager().loadTrack(trackName).join().orElse(null);
            if (track == null) return false;
            track.demote(user, api.getContextManager().getStaticQueryOptions());
            api.getUserManager().saveUser(user).join();
            return true;
        } catch (Exception e) { return false; }
    }

    // ── Context ───────────────────────────────────────────────────────────────

    public String buildContext() {
        StringBuilder sb = new StringBuilder("=== LuckPerms ===\n");
        sb.append("Groups: ").append(String.join(", ", getGroups())).append("\n");
        sb.append("Tracks: ").append(String.join(", ", getTracks())).append("\n");
        return sb.toString();
    }
}