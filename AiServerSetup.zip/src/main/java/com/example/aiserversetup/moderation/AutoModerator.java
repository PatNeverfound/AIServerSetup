package com.example.aiserversetup.moderation;

import com.example.aiserversetup.ai.AIClient;
import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.database.DatabaseService;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.*;
import java.util.concurrent.*;

/**
 * AI-powered auto-moderation system.
 * Analyses chat messages and takes configurable action on violations.
 */
public class AutoModerator implements PluginCore.PluginModule, Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    // Player warning counts (in-memory, reset on restart)
    private final Map<UUID, Integer> warnings = new ConcurrentHashMap<>();

    private boolean enabled;
    private boolean aiAnalysis;
    private int     muteThreshold;
    private int     kickThreshold;
    private int     banThreshold;
    private long    banDurationMs;

    // Simple regex-based filters (fast path, no API call)
    private static final List<String> BLOCKED_PATTERNS = List.of(
            "(?i)\\b(nigger|faggot)\\b",
            "(?i)\\b(kys|kill yourself)\\b",
            "(?i)(https?://\\S+)",          // Links (configurable)
            "(?i)\\b(hack|cheater|cheat)\\b"
    );

    @Override
    public String name() { return "AutoModerator"; }

    @Override
    public void onEnable(PluginCore core) {
        var cfg    = core.getPlugin().getConfig();
        enabled        = cfg.getBoolean("automod.enabled", true);
        aiAnalysis     = cfg.getBoolean("automod.ai-analysis", false); // Default off — costs tokens
        muteThreshold  = cfg.getInt("automod.mute-on-warnings",  3);
        kickThreshold  = cfg.getInt("automod.kick-on-warnings",  5);
        banThreshold   = cfg.getInt("automod.ban-on-warnings",   8);
        String banDur  = cfg.getString("automod.ban-duration",  "7d");
        banDurationMs  = parseDuration(banDur);

        if (enabled) {
            Bukkit.getPluginManager().registerEvents(this, core.getPlugin());
            core.getPlugin().getLogger().info("[AutoMod] Enabled. AI=" + aiAnalysis);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent event) {
        if (!enabled) return;
        Player p = event.getPlayer();
        if (p.hasPermission("aiserversetup.automod.exempt")) return;

        String message = event.getMessage();

        // Fast path: regex check
        for (String pattern : BLOCKED_PATTERNS) {
            if (message.matches(".*" + pattern + ".*")) {
                event.setCancelled(true);
                Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(),
                        () -> handleViolation(p, message, "Blocked pattern"));
                logToDb(p, message, true, "regex_match");
                return;
            }
        }

        // Slow path: AI analysis (only if enabled and not throttled)
        if (aiAnalysis) {
            PluginCore.get().serviceOpt(AIClient.class).ifPresent(ai -> {
                String prompt = "Is this Minecraft chat message toxic, harmful, or violating community rules? " +
                        "Reply with ONLY 'SAFE' or 'TOXIC: <reason>'. Message: \"" + message + "\"";
                ai.chat(List.of(Map.of("role", "user", "content", prompt)))
                        .thenAccept(resp -> {
                            if (resp.content().startsWith("TOXIC")) {
                                String reason = resp.content().contains(":") ?
                                        resp.content().split(":", 2)[1].trim() : "AI flagged";
                                Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(),
                                        () -> handleViolation(p, message, reason));
                                logToDb(p, message, true, "ai_flagged: " + reason);
                            }
                        })
                        .exceptionally(ex -> null); // Never crash for automod
            });
        }

        logToDb(p, message, false, null);
    }

    private void handleViolation(Player player, String message, String reason) {
        int count = warnings.merge(player.getUniqueId(), 1, Integer::sum);

        player.sendMessage(MM.deserialize(
                "<red>⚠ Warning " + count + ": <white>" + reason +
                ". Continued violations will result in punishment."));

        // Notify staff
        PluginCore.get().serviceOpt(com.example.aiserversetup.chat.ChatUtil.class)
                .ifPresent(cu -> cu.broadcastToPermission(
                        "<red>[AutoMod] <white>" + player.getName() +
                        " <gray>warned (" + count + "): " + reason,
                        "aiserversetup.alerts"));

        if (count >= banThreshold) {
            long expiry = System.currentTimeMillis() + banDurationMs;
            player.ban("Banned by AutoMod: " + reason,
                    new java.util.Date(expiry), "AutoModerator", true);
        } else if (count >= kickThreshold) {
            player.kick(MM.deserialize("<red>You have been kicked by AutoModerator.<br><gray>Reason: " + reason));
        } else if (count >= muteThreshold) {
            player.sendMessage(MM.deserialize("<red>You have been muted for excessive violations."));
            // Mute via EssentialsX if available — otherwise just warn
        }
    }

    private void logToDb(Player p, String message, boolean flagged, String reason) {
        PluginCore.get().serviceOpt(DatabaseService.class).ifPresent(db ->
                db.update(
                        "INSERT INTO chat_log(uuid,name,message,timestamp,flagged,flag_reason) VALUES(?,?,?,?,?,?)",
                        ps -> {
                            ps.setString(1, p.getUniqueId().toString());
                            ps.setString(2, p.getName());
                            ps.setString(3, message);
                            ps.setLong(4,   System.currentTimeMillis() / 1000);
                            ps.setInt(5,    flagged ? 1 : 0);
                            ps.setString(6, reason);
                        })
                .exceptionally(ex -> { return 0; })
        );
    }

    public Map<UUID, Integer> getWarnings() { return Collections.unmodifiableMap(warnings); }
    public int getWarnings(UUID uuid)       { return warnings.getOrDefault(uuid, 0); }
    public void clearWarnings(UUID uuid)    { warnings.remove(uuid); }
    public void addWarning(UUID uuid)       { warnings.merge(uuid, 1, Integer::sum); }

    private long parseDuration(String s) {
        if (s.endsWith("d")) return Long.parseLong(s.replace("d","")) * 86_400_000L;
        if (s.endsWith("h")) return Long.parseLong(s.replace("h","")) * 3_600_000L;
        if (s.endsWith("m")) return Long.parseLong(s.replace("m","")) * 60_000L;
        return 7 * 86_400_000L; // default 7 days
    }
}