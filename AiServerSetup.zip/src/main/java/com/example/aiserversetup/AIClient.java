package com.example.aiserversetup;

import com.google.gson.*;

import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Handles communication with the OpenAI Chat Completions API.
 */
public class AIClient {

    private static final String API_URL = "https://api.openai.com/v1/chat/completions";

    private final String apiKey;
    private final String model;
    private final HttpClient httpClient;
    private final Gson gson;

    public AIClient(String apiKey, String model) {
        this.apiKey = apiKey;
        this.model = model;
        this.httpClient = HttpClient.newHttpClient();
        this.gson = new Gson();
    }

    /**
     * Sends the full message history to OpenAI and returns the assistant reply asynchronously.
     */
    public CompletableFuture<String> chat(List<Map<String, String>> messages) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                JsonObject body = new JsonObject();
                body.addProperty("model", model);

                JsonArray msgArray = new JsonArray();
                for (Map<String, String> msg : messages) {
                    JsonObject m = new JsonObject();
                    m.addProperty("role", msg.get("role"));
                    m.addProperty("content", msg.get("content"));
                    msgArray.add(m);
                }
                body.add("messages", msgArray);
                body.addProperty("max_tokens", 1024);
                body.addProperty("temperature", 0.7);

                String requestBody = gson.toJson(body);

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(API_URL))
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + apiKey)
                        .POST(HttpRequest.BodyPublishers.ofString(requestBody, StandardCharsets.UTF_8))
                        .build();

                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

                if (response.statusCode() != 200) {
                    return "§c[AI Error] HTTP " + response.statusCode() + ": " + response.body();
                }

                JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                return json.getAsJsonArray("choices")
                        .get(0).getAsJsonObject()
                        .getAsJsonObject("message")
                        .get("content").getAsString();

            } catch (Exception e) {
                return "§c[AI Error] " + e.getMessage();
            }
        });
    }
}