package com.example.aiserversetup.chat;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Answers player questions in chat when they mention a configurable trigger keyword.
 * e.g. "@ai How do I claim land?" → AI responds in chat
 */
public class AIChatResponder implements Listener {

    private final AIServerSetupPlugin plugin;
    private final String trigger;
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private final long cooldownMs;
    private boolean enabled;

    public AIChatResponder(AIServerSetupPlugin plugin) {
        this.plugin     = plugin;
        this.trigger    = plugin.getConfig().getString("chat-ai.trigger", "@ai");
        this.cooldownMs = plugin.getConfig().getLong("chat-ai.cooldown-ms", 10000L);
        this.enabled    = plugin.getConfig().getBoolean("chat-ai.enabled", true);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        if (!enabled) return;
        String msg = e.getMessage().trim();
        if (!msg.toLowerCase().startsWith(trigger.toLowerCase())) return;

        Player player = e.getPlayer();
        String question = msg.substring(trigger.length()).trim();
        if (question.isBlank()) return;

        // Cooldown check
        long now = System.currentTimeMillis();
        Long lastUsed = cooldowns.get(player.getUniqueId());
        if (lastUsed != null && now - lastUsed < cooldownMs) {
            long wait = (cooldownMs - (now - lastUsed)) / 1000;
            player.sendMessage("§7[AI] Please wait §f" + wait + "s§7 before asking again.");
            return;
        }
        cooldowns.put(player.getUniqueId(), now);

        player.sendMessage("§b[AI] §7Thinking...");

        // Build a server-specific system prompt for player questions
        String systemPrompt = "You are a helpful assistant for a Minecraft server. " +
                "Keep answers SHORT (2-4 sentences max). Use simple language. " +
                "Answer questions about server rules, gameplay, commands, and features. " +
                "Server context: " + buildPlayerContext(player);

        List<Map<String, String>> messages = List.of(
                Map.of("role", "system", "content", systemPrompt),
                Map.of("role", "user", "content", question)
        );

        plugin.getAiClient().chat(messages).thenAccept(response ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    String answer = response.content().strip();
                    // Send response to the player
                    player.sendMessage("§b[AI] §f" + answer);
                    // Optionally broadcast to nearby players
                    if (plugin.getConfig().getBoolean("chat-ai.public", false)) {
                        for (Player nearby : Bukkit.getOnlinePlayers()) {
                            if (!nearby.equals(player) && nearby.getWorld().equals(player.getWorld())
                                    && nearby.getLocation().distance(player.getLocation()) < 50) {
                                nearby.sendMessage("§7[" + player.getName() + " asked AI] §f" + answer);
                            }
                        }
                    }
                }));
    }

    private String buildPlayerContext(Player player) {
        return "Player name: " + player.getName() + ", " +
                "World: " + player.getWorld().getName() + ", " +
                "Online players: " + Bukkit.getOnlinePlayers().size() + ", " +
                "Integrations: " + plugin.getIntegrations().getLoadedList();
    }

    public void setEnabled(boolean e) { this.enabled = e; }
    public boolean isEnabled()         { return enabled; }
}