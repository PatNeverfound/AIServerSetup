package com.example.aiserversetup.chat;

import com.example.aiserversetup.core.PluginCore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

/**
 * Utility for sending formatted messages to players and the console.
 * Also handles chat input listeners (for GUI-driven text input).
 */
public class ChatUtil implements PluginCore.PluginModule, Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    // Pending chat input listeners: uuid → callback
    private final Map<UUID, Consumer<String>> pendingInputs = new ConcurrentHashMap<>();

    // Prefix templates
    private static final String PREFIX_SUCCESS = "<dark_gray>[<green>✔<dark_gray>] <reset>";
    private static final String PREFIX_ERROR   = "<dark_gray>[<red>✘<dark_gray>] <reset>";
    private static final String PREFIX_INFO    = "<dark_gray>[<aqua>ℹ<dark_gray>] <reset>";
    private static final String PREFIX_WARN    = "<dark_gray>[<yellow>⚠<dark_gray>] <reset>";
    private static final String HEADER_BAR     = "<dark_gray>▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

    @Override
    public String name() { return "ChatUtil"; }

    @Override
    public void onEnable(PluginCore core) {
        Bukkit.getPluginManager().registerEvents(this, core.getPlugin());
    }

    // ── Send methods ──────────────────────────────────────────────────────────

    public void success(CommandSender sender, String msg) {
        send(sender, PREFIX_SUCCESS + "<green>" + msg);
    }

    public void error(CommandSender sender, String msg) {
        send(sender, PREFIX_ERROR + "<red>" + msg);
    }

    public void info(CommandSender sender, String msg) {
        send(sender, PREFIX_INFO + "<gray>" + msg);
    }

    public void warn(CommandSender sender, String msg) {
        send(sender, PREFIX_WARN + "<yellow>" + msg);
    }

    public void header(CommandSender sender, String title) {
        send(sender, HEADER_BAR);
        send(sender, "  <gold><bold>" + title + "</bold></gold>");
        send(sender, HEADER_BAR);
    }

    public void sendRaw(CommandSender sender, String miniMessage) {
        send(sender, miniMessage);
    }

    /** Send raw text to the console without MiniMessage. */
    public void console(String message) {
        Bukkit.getConsoleSender().sendMessage("[AISetup] " + message);
    }

    /**
     * Conditional result message.
     * @param ok      if true, sends success; otherwise sends error
     * @param success success message
     * @param failure error message
     */
    public void result(CommandSender sender, boolean ok, String success, String failure) {
        if (ok) success(sender, success);
        else    error(sender, failure);
    }

    /**
     * Send a multi-line message, splitting on newlines and respecting MiniMessage.
     * Useful for AI responses.
     */
    public void sendMultiline(CommandSender sender, String text) {
        if (text == null || text.isBlank()) return;
        String[] lines = text.split("\n");
        for (String line : lines) {
            if (!line.isBlank()) send(sender, "<gray>" + line);
        }
    }

    /**
     * Send a message as a title + subtitle to a player.
     */
    public void title(Player player, String title, String subtitle) {
        player.showTitle(net.kyori.adventure.text.title.Title.title(
                MM.deserialize(title),
                MM.deserialize(subtitle),
                net.kyori.adventure.text.title.Title.Times.times(
                        java.time.Duration.ofMillis(200),
                        java.time.Duration.ofMillis(2500),
                        java.time.Duration.ofMillis(400))));
    }

    /**
     * Send an action bar message to a player.
     */
    public void actionBar(Player player, String msg) {
        player.sendActionBar(MM.deserialize(msg));
    }

    // ── Chat input listener ───────────────────────────────────────────────────

    /**
     * Listen for the next chat message from a player.
     * The callback is fired once and then removed.
     *
     * @param player   player to listen to
     * @param callback called with the player's next chat message
     */
    public void listenNextMessage(Player player, Consumer<String> callback) {
        pendingInputs.put(player.getUniqueId(), callback);
        player.sendMessage(MM.deserialize("<yellow>⌨ Type your message in chat <gray>(or type <red>cancel</red> to abort):"));
    }

    /** Cancel a pending chat input for a player. */
    public void cancelInput(Player player) {
        pendingInputs.remove(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Consumer<String> callback = pendingInputs.remove(event.getPlayer().getUniqueId());
        if (callback == null) return;

        event.setCancelled(true);
        String message = event.getMessage();

        // Fire on main thread
        Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () -> callback.accept(message));
    }

    // ── Broadcast ─────────────────────────────────────────────────────────────

    public void broadcast(String miniMessage) {
        Bukkit.broadcast(MM.deserialize(miniMessage));
    }

    public void broadcastToPermission(String miniMessage, String permission) {
        var msg = MM.deserialize(miniMessage);
        Bukkit.getOnlinePlayers().stream()
                .filter(p -> p.hasPermission(permission))
                .forEach(p -> p.sendMessage(msg));
        Bukkit.getConsoleSender().sendMessage(net.kyori.adventure.text.serializer.plain
                .PlainTextComponentSerializer.plainText().serialize(msg));
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    private void send(CommandSender sender, String miniMessage) {
        try {
            sender.sendMessage(MM.deserialize(miniMessage));
        } catch (Exception e) {
            // Fallback to plain text if MiniMessage parsing fails
            sender.sendMessage(miniMessage.replaceAll("<[^>]+>", ""));
        }
    }
}