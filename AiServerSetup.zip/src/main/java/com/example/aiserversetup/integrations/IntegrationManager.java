package com.example.aiserversetup.integrations;

import com.example.aiserversetup.core.PluginCore;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.permission.Permission;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.Optional;

/**
 * Soft-dependency integration manager.
 * Loads Vault, LuckPerms, PlaceholderAPI if present — never crashes if absent.
 */
public class IntegrationManager implements PluginCore.PluginModule {

    private Economy    economy;
    private Permission vaultPermission;
    private boolean    luckPermsPresent;
    private boolean    placeholderAPIPresent;
    private boolean    worldEditPresent;
    private boolean    essentialsPresent;

    @Override
    public String name() { return "IntegrationManager"; }

    @Override
    public void onEnable(PluginCore core) {
        loadVault(core);
        loadLuckPerms(core);
        loadPlaceholderAPI(core);
        loadWorldEdit(core);
        loadEssentials(core);

        core.getPlugin().getLogger().info("[Integrations] Vault=" + (economy != null) +
                " LuckPerms=" + luckPermsPresent +
                " PAPI=" + placeholderAPIPresent +
                " WorldEdit=" + worldEditPresent +
                " Essentials=" + essentialsPresent);
    }

    // ── Vault ─────────────────────────────────────────────────────────────────

    private void loadVault(PluginCore core) {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return;
        try {
            RegisteredServiceProvider<Economy> rsp =
                    Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null) {
                economy = rsp.getProvider();
                core.getPlugin().getLogger().info("[Integrations] Vault economy: " + economy.getName());
            }
            RegisteredServiceProvider<Permission> rspPerm =
                    Bukkit.getServicesManager().getRegistration(Permission.class);
            if (rspPerm != null) {
                vaultPermission = rspPerm.getProvider();
            }
        } catch (Exception e) {
            core.getPlugin().getLogger().warning("[Integrations] Vault load failed: " + e.getMessage());
        }
    }

    private void loadLuckPerms(PluginCore core) {
        luckPermsPresent = Bukkit.getPluginManager().isPluginEnabled("LuckPerms");
    }

    private void loadPlaceholderAPI(PluginCore core) {
        placeholderAPIPresent = Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI");
    }

    private void loadWorldEdit(PluginCore core) {
        worldEditPresent = Bukkit.getPluginManager().isPluginEnabled("WorldEdit") ||
                Bukkit.getPluginManager().isPluginEnabled("FastAsyncWorldEdit");
    }

    private void loadEssentials(PluginCore core) {
        essentialsPresent = Bukkit.getPluginManager().isPluginEnabled("Essentials") ||
                Bukkit.getPluginManager().isPluginEnabled("EssentialsX");
    }

    // ── Accessors ─────────────────────────────────────────────────────────────

    /** Returns Vault Economy, or null if unavailable. */
    public Economy getEconomy() { return economy; }

    /** Returns Vault Permission, or null if unavailable. */
    public Permission getVaultPermission() { return vaultPermission; }

    /** Returns true if Vault + economy provider is loaded. */
    public boolean hasEconomy() { return economy != null; }

    public boolean hasLuckPerms()       { return luckPermsPresent; }
    public boolean hasPlaceholderAPI()  { return placeholderAPIPresent; }
    public boolean hasWorldEdit()       { return worldEditPresent; }
    public boolean hasEssentials()      { return essentialsPresent; }

    /**
     * Deposit money to a player, if economy is available.
     * @return true if successful, false if economy not loaded
     */
    public boolean deposit(org.bukkit.entity.Player player, double amount) {
        if (economy == null) return false;
        return economy.depositPlayer(player, amount).transactionSuccess();
    }

    /**
     * Withdraw money from a player.
     * @return true if successful and player had enough
     */
    public boolean withdraw(org.bukkit.entity.Player player, double amount) {
        if (economy == null) return false;
        if (!economy.has(player, amount)) return false;
        return economy.withdrawPlayer(player, amount).transactionSuccess();
    }

    public boolean has(org.bukkit.entity.Player player, double amount) {
        if (economy == null) return false;
        return economy.has(player, amount);
    }

    public double getBalance(org.bukkit.entity.Player player) {
        if (economy == null) return 0;
        return economy.getBalance(player);
    }

    /** Format a monetary amount using the economy formatter (e.g. "$1,000"). */
    public String formatMoney(double amount) {
        if (economy == null) return "$" + String.format("%.2f", amount);
        return economy.format(amount);
    }

    /** Replace PlaceholderAPI placeholders in a string. */
    public String parsePlaceholders(org.bukkit.entity.Player player, String text) {
        if (!placeholderAPIPresent) return text;
        try {
            return me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(player, text);
        } catch (Exception e) {
            return text;
        }
    }
}