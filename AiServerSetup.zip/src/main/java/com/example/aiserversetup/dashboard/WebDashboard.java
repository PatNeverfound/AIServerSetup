package com.example.aiserversetup.dashboard;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.command.ApplyProcessor;
import com.google.gson.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/**
 * Built-in HTTP web dashboard — lets you chat with the AI and manage
 * the server from any browser on the local network.
 */
public class WebDashboard {

    private final AIServerSetupPlugin plugin;
    private ServerSocket server;
    private ExecutorService pool;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public WebDashboard(AIServerSetupPlugin plugin) { this.plugin = plugin; }

    public void start() {
        if (running.get()) return;
        int port     = plugin.getConfig().getInt("dashboard.port", 8080);
        String bind  = plugin.getConfig().getString("dashboard.bind", "0.0.0.0");
        int maxSess  = plugin.getConfig().getInt("dashboard.max-sessions", 5);

        try {
            server = new ServerSocket(port, 10, InetAddress.getByName(bind));
            pool   = Executors.newFixedThreadPool(maxSess);
            running.set(true);

            Thread accept = new Thread(() -> {
                while (running.get()) {
                    try {
                        Socket client = server.accept();
                        pool.submit(() -> handleClient(client));
                    } catch (IOException e) {
                        if (running.get()) plugin.getLogger().warning("Dashboard error: " + e.getMessage());
                    }
                }
            }, "AISetup-Dashboard");
            accept.setDaemon(true);
            accept.start();

            plugin.getLogger().info("Web dashboard started on " + bind + ":" + port);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to start dashboard: " + e.getMessage());
        }
    }

    public void stop() {
        running.set(false);
        try { if (server != null) server.close(); } catch (IOException ignored) {}
        if (pool != null) pool.shutdownNow();
        plugin.getLogger().info("Web dashboard stopped.");
    }

    public boolean isRunning() { return running.get(); }

    private void handleClient(Socket socket) {
        try (socket;
             BufferedReader in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             OutputStream   out = socket.getOutputStream()) {

            String line = in.readLine();
            if (line == null) return;

            String[] parts = line.split(" ");
            if (parts.length < 2) return;
            String method = parts[0];
            String path   = parts[1];

            // Read headers
            Map<String, String> headers = new HashMap<>();
            String h;
            while ((h = in.readLine()) != null && !h.isBlank()) {
                int colon = h.indexOf(':');
                if (colon > 0) headers.put(h.substring(0, colon).trim().toLowerCase(), h.substring(colon + 1).trim());
            }

            // Auth
            String auth = plugin.getConfig().getString("dashboard.password", "changeme");
            String token = headers.getOrDefault("x-auth-token", "");
            if (!token.equals(auth) && !path.equals("/login")) {
                respond(out, 401, "application/json", "{\"error\":\"Unauthorized\"}");
                return;
            }

            if ("GET".equals(method) && "/".equals(path)) {
                respond(out, 200, "text/html; charset=utf-8", getDashboardHTML());
            } else if ("POST".equals(method) && "/api/chat".equals(path)) {
                int len = Integer.parseInt(headers.getOrDefault("content-length", "0"));
                char[] buf = new char[len];
                in.read(buf, 0, len);
                String body = new String(buf);

                JsonObject req = JsonParser.parseString(body).getAsJsonObject();
                String msg = req.get("message").getAsString();

                plugin.getConversations().addUserMessage("WEB_DASHBOARD", msg);
                var messages = plugin.getConversations().buildMessages("WEB_DASHBOARD");

                CompletableFuture<String> future = new CompletableFuture<>();
                plugin.getAiClient().chat(messages).thenAccept(response -> {
                    plugin.getConversations().addAssistantMessage("WEB_DASHBOARD", response.content());
                    plugin.getServer().getScheduler().runTask(plugin, () ->
                            ApplyProcessor.process(plugin.getServer().getConsoleSender(), response.content(), plugin));
                    future.complete(ApplyProcessor.stripBlocks(response.content()));
                });

                String aiReply = future.get(30, TimeUnit.SECONDS);
                respond(out, 200, "application/json",
                        gson.toJson(Map.of("response", aiReply)));

            } else if ("GET".equals(method) && "/api/stats".equals(path)) {
                respond(out, 200, "application/json", getStatsJson());
            } else if ("GET".equals(method) && "/api/config".equals(path)) {
                respond(out, 200, "application/json",
                        gson.toJson(plugin.getFileEditor().getAllServerProperties()));
            } else {
                respond(out, 404, "application/json", "{\"error\":\"Not found\"}");
            }

        } catch (Exception e) {
            plugin.getLogger().fine("Dashboard client error: " + e.getMessage());
        }
    }

    private void respond(OutputStream out, int code, String contentType, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        String header = "HTTP/1.1 " + code + " OK\r\n"
                + "Content-Type: " + contentType + "\r\n"
                + "Content-Length: " + bytes.length + "\r\n"
                + "Access-Control-Allow-Origin: *\r\n"
                + "Connection: close\r\n\r\n";
        out.write(header.getBytes(StandardCharsets.UTF_8));
        out.write(bytes);
    }

    private String getStatsJson() {
        double[] tps = org.bukkit.Bukkit.getTPS();
        Runtime rt   = Runtime.getRuntime();
        return gson.toJson(Map.of(
                "tps",      Map.of("1m", tps[0], "5m", tps[1], "15m", tps[2]),
                "memory",   Map.of("used", (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024,
                                   "max",  rt.maxMemory() / 1024 / 1024),
                "players",  Map.of("online", org.bukkit.Bukkit.getOnlinePlayers().size(),
                                   "max",    org.bukkit.Bukkit.getMaxPlayers()),
                "version",  org.bukkit.Bukkit.getVersion(),
                "aiTokens", plugin.getTokenTracker().getTotalTokens()
        ));
    }

    /** Returns the full single-page dashboard HTML. */
    private String getDashboardHTML() {
        return """
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8"/>
          <meta name="viewport" content="width=device-width, initial-scale=1"/>
          <title>AIServerSetup Dashboard</title>
          <style>
            *{box-sizing:border-box;margin:0;padding:0}
            body{font-family:'Segoe UI',sans-serif;background:#0d1117;color:#e6edf3;min-height:100vh}
            header{background:linear-gradient(90deg,#00c6ff,#0072ff);padding:16px 24px;font-size:20px;font-weight:bold}
            .container{display:grid;grid-template-columns:1fr 350px;gap:16px;padding:16px;max-width:1400px;margin:0 auto}
            .card{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:16px}
            .chat-messages{height:450px;overflow-y:auto;margin-bottom:12px;display:flex;flex-direction:column;gap:8px}
            .msg{padding:10px 14px;border-radius:8px;max-width:85%;line-height:1.5}
            .msg.user{background:#1f6feb;align-self:flex-end}
            .msg.ai{background:#21262d;align-self:flex-start;border:1px solid #30363d}
            .chat-input{display:flex;gap:8px}
            input,button{background:#21262d;border:1px solid #30363d;color:#e6edf3;padding:10px 14px;border-radius:6px;font-size:14px}
            input{flex:1}
            button{background:#1f6feb;border:none;cursor:pointer;font-weight:bold}
            button:hover{background:#388bfd}
            .stat{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #21262d}
            .stat:last-child{border:none}
            .stat-val{font-weight:bold;color:#58a6ff}
            .green{color:#3fb950}.yellow{color:#d29922}.red{color:#f85149}
            #auth-screen{position:fixed;inset:0;background:#0d1117;display:flex;align-items:center;justify-content:center;z-index:100}
            .auth-box{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:32px;width:320px;text-align:center}
            .auth-box h2{margin-bottom:16px;color:#58a6ff}
            .auth-box input{width:100%;margin-bottom:12px}
            h3{margin-bottom:12px;color:#58a6ff;font-size:15px}
          </style>
        </head>
        <body>
          <div id="auth-screen">
            <div class="auth-box">
              <h2>🤖 AIServerSetup</h2>
              <p style="margin-bottom:16px;color:#8b949e">Enter your dashboard password</p>
              <input type="password" id="password" placeholder="Password" onkeydown="if(event.key==='Enter')login()"/>
              <button onclick="login()" style="width:100%">Login</button>
            </div>
          </div>

          <header>🤖 AIServerSetup v3.0 — Web Dashboard</header>
          <div class="container">
            <div class="card">
              <h3>💬 AI Chat</h3>
              <div class="chat-messages" id="messages"></div>
              <div class="chat-input">
                <input type="text" id="chatInput" placeholder="Ask AI to configure your server..." onkeydown="if(event.key==='Enter')sendMsg()"/>
                <button onclick="sendMsg()">Send</button>
              </div>
            </div>
            <div>
              <div class="card" style="margin-bottom:16px">
                <h3>📊 Live Stats</h3>
                <div id="stats"><div class="stat"><span>Loading...</span></div></div>
                <button onclick="refreshStats()" style="margin-top:12px;width:100%">Refresh</button>
              </div>
              <div class="card">
                <h3>⚙ Server Properties</h3>
                <div id="config" style="max-height:250px;overflow-y:auto;font-size:13px"></div>
                <button onclick="refreshConfig()" style="margin-top:12px;width:100%">Refresh</button>
              </div>
            </div>
          </div>

          <script>
            let token = '';

            function login() {
              token = document.getElementById('password').value;
              document.getElementById('auth-screen').style.display = 'none';
              refreshStats(); refreshConfig();
              setInterval(refreshStats, 5000);
            }

            function addMsg(role, text) {
              const div = document.createElement('div');
              div.className = 'msg ' + role;
              div.textContent = text;
              const msgs = document.getElementById('messages');
              msgs.appendChild(div);
              msgs.scrollTop = msgs.scrollHeight;
            }

            async function sendMsg() {
              const input = document.getElementById('chatInput');
              const msg = input.value.trim();
              if (!msg) return;
              input.value = '';
              addMsg('user', msg);
              addMsg('ai', '⟳ Thinking...');
              try {
                const res = await fetch('/api/chat', {
                  method: 'POST',
                  headers: {'Content-Type':'application/json','X-Auth-Token':token},
                  body: JSON.stringify({message: msg})
                });
                const data = await res.json();
                document.querySelectorAll('.msg.ai').forEach((el,i,arr) => { if(i===arr.length-1) el.textContent = data.response || data.error; });
              } catch(e) { addMsg('ai', 'Error: ' + e.message); }
            }

            async function refreshStats() {
              try {
                const res = await fetch('/api/stats', {headers:{'X-Auth-Token':token}});
                const d = await res.json();
                const tpsCol = t => t >= 19 ? 'green' : t >= 15 ? 'yellow' : 'red';
                const memPct = (d.memory.used / d.memory.max * 100).toFixed(1);
                const memCol = memPct > 85 ? 'red' : memPct > 65 ? 'yellow' : 'green';
                document.getElementById('stats').innerHTML = `
                  <div class="stat"><span>TPS (1m)</span><span class="stat-val ${tpsCol(d.tps['1m'])}">${d.tps['1m'].toFixed(2)}</span></div>
                  <div class="stat"><span>TPS (5m)</span><span class="stat-val ${tpsCol(d.tps['5m'])}">${d.tps['5m'].toFixed(2)}</span></div>
                  <div class="stat"><span>Memory</span><span class="stat-val ${memCol}">${d.memory.used}MB / ${d.memory.max}MB</span></div>
                  <div class="stat"><span>Players</span><span class="stat-val">${d.players.online}/${d.players.max}</span></div>
                  <div class="stat"><span>AI Tokens</span><span class="stat-val">${d.aiTokens.toLocaleString()}</span></div>
                  <div class="stat"><span>Version</span><span class="stat-val" style="font-size:11px">${d.version}</span></div>
                `;
              } catch(e) {}
            }

            async function refreshConfig() {
              try {
                const res = await fetch('/api/config', {headers:{'X-Auth-Token':token}});
                const d = await res.json();
                document.getElementById('config').innerHTML = Object.entries(d)
                  .map(([k,v]) => `<div class="stat"><span style="color:#8b949e">${k}</span><span style="color:#e6edf3">${v}</span></div>`)
                  .join('');
              } catch(e) {}
            }
          </script>
        </body>
        </html>
        """;
    }
}