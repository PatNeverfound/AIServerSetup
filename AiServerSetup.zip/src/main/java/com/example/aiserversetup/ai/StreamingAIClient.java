package com.example.aiserversetup.ai;

import com.google.gson.*;

import java.io.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

/** Streams AI responses token-by-token via SSE. */
public class StreamingAIClient extends AIClient {

    public StreamingAIClient(String apiKey, String model, int maxTokens, double temperature) {
        super(apiKey, model, model, maxTokens, temperature, 3, 1500);
    }

    public CompletableFuture<Void> streamChat(
            List<Map<String, String>> messages,
            Consumer<String> onToken,
            Consumer<AIResponse> onDone) {

        return CompletableFuture.runAsync(() -> {
            StringBuilder full = new StringBuilder();
            try {
                JsonObject body = buildBody(messages, model.get(), true, null);
                HttpRequest req = buildRequest(gson.toJson(body));
                HttpClient client = HttpClient.newHttpClient();
                HttpResponse<InputStream> resp = client.send(req, HttpResponse.BodyHandlers.ofInputStream());

                if (resp.statusCode() != 200) {
                    String err = "§c[AI Stream Error] HTTP " + resp.statusCode();
                    onToken.accept(err);
                    onDone.accept(new AIResponse(err, 0, 0, model.get()));
                    return;
                }

                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(resp.body(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (!line.startsWith("data: ")) continue;
                        String data = line.substring(6).trim();
                        if (data.equals("[DONE]")) break;
                        try {
                            JsonObject chunk = JsonParser.parseString(data).getAsJsonObject();
                            JsonObject delta = chunk.getAsJsonArray("choices").get(0)
                                    .getAsJsonObject().getAsJsonObject("delta");
                            if (delta.has("content")) {
                                String token = delta.get("content").getAsString();
                                full.append(token);
                                onToken.accept(token);
                            }
                        } catch (JsonSyntaxException ignored) {}
                    }
                }
                onDone.accept(new AIResponse(full.toString().trim(), 0, 0, model.get()));

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                onDone.accept(new AIResponse(full.toString().trim(), 0, 0, model.get()));
            } catch (Exception e) {
                onDone.accept(new AIResponse("§c[AI Error] " + e.getMessage(), 0, 0, model.get()));
            }
        });
    }
}