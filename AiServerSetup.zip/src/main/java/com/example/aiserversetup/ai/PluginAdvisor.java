package com.example.aiserversetup.ai;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.marketplace.PluginCatalog;
import com.example.aiserversetup.marketplace.PluginCatalog.PluginEntry;
import com.example.aiserversetup.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Uses AI to recommend plugins based on server type, currently installed plugins,
 * and server performance characteristics.
 */
public class PluginAdvisor {

    private final AIServerSetupPlugin plugin;
    private final ChatUtil chat;

    public PluginAdvisor(AIServerSetupPlugin plugin, ChatUtil chat) {
        this.plugin = plugin;
        this.chat   = chat;
    }

    /**
     * Ask AI for plugin recommendations for a given server type.
     */
    public void recommend(String serverType, CommandSender sender) {
        chat.header(sender, "AI Plugin Recommendations");
        chat.sendRaw(sender, "<gray>Analyzing your server for: <white>" + serverType + "</white>...</gray>");

        // Build context
        String installedPlugins = Arrays.stream(Bukkit.getPluginManager().getPlugins())
                .map(Plugin::getName).collect(Collectors.joining(", "));

        String catalogSummary = PluginCatalog.getAll().stream()
                .map(p -> p.id() + ": " + p.name() + " [" + p.category().name() + "] - " + p.description())
                .collect(Collectors.joining("\n"));

        String prompt = """
                I am running a Minecraft Paper 1.21.1 server of type: """ + serverType + """
                
                Currently installed plugins: """ + installedPlugins + """
                
                Here is a catalog of available plugins (id: name [category] - description):
                """ + catalogSummary + """
                
                Please recommend exactly 10 plugins from this catalog that are most essential
                for this server type. For each recommendation:
                1. Explain why it's needed for this server type
                2. Check if any are already installed
                3. Note any dependencies
                4. Emit an APPLY block for each one you recommend:
                ===APPLY=== {"type":"plugin-recommendation","name":"<name>","url":"","reason":"<reason>"} ===END===
                
                Then provide the install order from most to least critical.
                """;

        plugin.getConversations().addUserMessage("AI_ADVISOR", prompt);
        plugin.getAiClient().chat(plugin.getConversations().buildMessages("AI_ADVISOR")).thenAccept(response ->
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    plugin.getConversations().addAssistantMessage("AI_ADVISOR", response.content());
                    chat.sendMultiline(sender, com.example.aiserversetup.command.ApplyProcessor.stripBlocks(response.content()));

                    // Parse recommendations and offer quick install
                    List<PluginEntry> recommended = parseRecommendations(response.content());
                    if (!recommended.isEmpty()) {
                        chat.sendRaw(sender, "");
                        chat.sendRaw(sender, "<yellow>Quick install all " + recommended.size() + " recommended plugins:</yellow>");
                        chat.sendRaw(sender, "<green><click:run_command:'/aimarket install-batch "
                                + recommended.stream().map(PluginEntry::id).collect(Collectors.joining(","))
                                + "'>▶ Install All Recommendations</click></green>");
                    }
                })
        );
    }

    /**
     * Analyze conflicts and redundant plugins.
     */
    public void analyzeConflicts(CommandSender sender) {
        chat.header(sender, "Plugin Conflict Analysis");

        Plugin[] loaded = Bukkit.getPluginManager().getPlugins();
        String pluginList = Arrays.stream(loaded)
                .map(p -> p.getName() + " v" + p.getDescription().getVersion() + " (deps: "
                        + String.join(",", p.getDescription().getDepend()) + ")")
                .collect(Collectors.joining("\n"));

        String prompt = "Analyze these installed Minecraft plugins for:\n"
                + "1. Conflicting plugins that do the same thing\n"
                + "2. Redundant plugins that overlap significantly\n"
                + "3. Missing dependencies\n"
                + "4. Performance concerns from too many plugins\n"
                + "5. Recommended removals\n\n"
                + "Installed plugins:\n" + pluginList;

        plugin.getConversations().addUserMessage("AI_ADVISOR_CONFLICT", prompt);
        plugin.getAiClient().chat(plugin.getConversations().buildMessages("AI_ADVISOR_CONFLICT"))
                .thenAccept(response -> plugin.getServer().getScheduler().runTask(plugin, () -> {
                    chat.sendMultiline(sender, com.example.aiserversetup.command.ApplyProcessor.stripBlocks(response.content()));
                }));
    }

    /**
     * Generate a config file template for a freshly installed plugin.
     */
    public void generateConfig(String pluginName, CommandSender sender) {
        chat.header(sender, "AI Config Generator: " + pluginName);

        String prompt = "Generate a complete, optimized, well-commented configuration file for the "
                + "Minecraft plugin '" + pluginName + "' for a Paper 1.21.1 server. "
                + "Include all important options with explanations. "
                + "Format it as valid YAML.";

        plugin.getAiClient().chat(List.of(Map.of("role", "user", "content", prompt)))
                .thenAccept(response -> plugin.getServer().getScheduler().runTask(plugin, () -> {
                    String config = com.example.aiserversetup.command.ApplyProcessor.stripBlocks(response.content());
                    chat.sendMultiline(sender, config);

                    // Offer to save it
                    java.io.File configDir = new java.io.File("plugins/" + pluginName);
                    if (configDir.exists()) {
                        try {
                            java.io.File configFile = new java.io.File(configDir, "config.yml.ai-generated");
                            java.nio.file.Files.writeString(configFile.toPath(), config);
                            chat.success(sender, "Config saved to: plugins/" + pluginName + "/config.yml.ai-generated");
                            chat.warn(sender, "Review and rename to config.yml after checking.");
                        } catch (Exception e) {
                            chat.error(sender, "Could not save config: " + e.getMessage());
                        }
                    }
                }));
    }

    private List<PluginEntry> parseRecommendations(String response) {
        List<PluginEntry> found = new ArrayList<>();
        for (PluginEntry p : PluginCatalog.getAll()) {
            if (response.contains(p.name())) found.add(p);
            if (found.size() >= 10) break;
        }
        return found;
    }
}