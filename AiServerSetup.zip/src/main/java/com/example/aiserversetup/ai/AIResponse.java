package com.example.aiserversetup.ai;

/** Wraps an AI response with metadata. */
public record AIResponse(String content, long promptTokens, long completionTokens, String modelUsed) {
    public long totalTokens() { return promptTokens + completionTokens; }
    public boolean isError()  { return content.startsWith("§c[AI Error]"); }
    /** Estimated cost in USD (GPT-4o pricing, approximate) */
    public double estimatedCostUSD() {
        double inputRate  = modelUsed.contains("4o")      ? 0.000005 :
                            modelUsed.contains("4-turbo") ? 0.00001  : 0.0000005;
        double outputRate = modelUsed.contains("4o")      ? 0.000015 :
                            modelUsed.contains("4-turbo") ? 0.00003  : 0.0000015;
        return (promptTokens * inputRate) + (completionTokens * outputRate);
    }
}