package com.example.aiserversetup.ai;

import com.example.aiserversetup.core.PluginCore;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stores per-context AI conversation history with automatic trimming.
 * Context IDs are typically player UUIDs or channel names.
 */
public class ConversationStore implements PluginCore.PluginModule {

    private final Map<String, List<Map<String, String>>> conversations = new ConcurrentHashMap<>();
    private final int maxHistoryPerContext;

    public ConversationStore() {
        this.maxHistoryPerContext = 20;
    }

    @Override
    public String name() { return "ConversationStore"; }

    @Override
    public void onEnable(PluginCore core) {
        core.getPlugin().getLogger().info("[ConversationStore] Initialised. Max history: " + maxHistoryPerContext);
    }

    @Override
    public void onDisable(PluginCore core) {
        conversations.clear();
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Returns a mutable copy of the conversation history for the given context.
     */
    public List<Map<String, String>> getMessages(String contextId) {
        return new ArrayList<>(conversations.computeIfAbsent(contextId, k -> new ArrayList<>()));
    }

    /**
     * Appends a message to the history for this context.
     * Automatically trims to {@code maxHistoryPerContext} entries.
     */
    public void addMessage(String contextId, String role, String content) {
        List<Map<String, String>> hist = conversations.computeIfAbsent(contextId, k -> new ArrayList<>());
        synchronized (hist) {
            hist.add(Map.of("role", role, "content", content));
            while (hist.size() > maxHistoryPerContext) {
                hist.remove(0);
            }
        }
    }

    /** Prepend a system message at position 0 if not already present. */
    public void setSystemPrompt(String contextId, String systemPrompt) {
        List<Map<String, String>> hist = conversations.computeIfAbsent(contextId, k -> new ArrayList<>());
        synchronized (hist) {
            // Remove any existing system message at index 0
            if (!hist.isEmpty() && "system".equals(hist.get(0).get("role"))) {
                hist.remove(0);
            }
            hist.add(0, Map.of("role", "system", "content", systemPrompt));
        }
    }

    public void clear(String contextId) {
        conversations.remove(contextId);
    }

    public void clearAll() {
        conversations.clear();
    }

    public boolean hasContext(String contextId) {
        return conversations.containsKey(contextId);
    }

    public int contextCount() {
        return conversations.size();
    }

    public int messageCount(String contextId) {
        List<Map<String, String>> hist = conversations.get(contextId);
        return hist == null ? 0 : hist.size();
    }
}