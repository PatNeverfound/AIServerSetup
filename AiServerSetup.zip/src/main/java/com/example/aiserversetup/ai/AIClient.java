package com.example.aiserversetup.ai;

import com.example.aiserversetup.core.PluginCore;
import com.example.aiserversetup.util.StructuredLogger;
import com.google.gson.*;
import okhttp3.*;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

/**
 * Production AI client with:
 * - Multi-provider (OpenAI, Anthropic, Ollama)
 * - Streaming responses
 * - Tool/function calling
 * - Rate limiting (Semaphore)
 * - Retry with exponential backoff
 * - Token usage tracking
 * - Full exception handling on all futures
 */
public class AIClient implements PluginCore.PluginModule {

    private static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");

    private final OkHttpClient http;
    private final Gson         gson;
    private       AIProvider   provider;
    private       String       model;
    private       String       apiKey;
    private       double       temperature;
    private       int          maxTokens;
    private int totalTokensUsed = 0;

    private final Map<String, AITool> tools = new LinkedHashMap<>();
    private final Semaphore rateLimiter = new Semaphore(1, true);
    private long lastRequestMs   = 0L;
    private int  requestsPerMinute = 30;

    public enum AIProvider { OPENAI, ANTHROPIC, OLLAMA }

    public AIClient() {
        this.http = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
        this.gson = new GsonBuilder().create();
    }

    @Override
    public String name() { return "AIClient"; }

    @Override
    public void onEnable(PluginCore core) {
        var cfg = core.getPlugin().getConfig();
        String prov = cfg.getString("ai.provider", "openai").toUpperCase();
        try {
            provider = AIProvider.valueOf(prov);
        } catch (IllegalArgumentException e) {
            provider = AIProvider.OPENAI;
            core.getPlugin().getLogger().warning("[AI] Unknown provider '" + prov + "', defaulting to OPENAI");
        }
        apiKey           = cfg.getString("ai.api-key", "");
        model            = cfg.getString("ai.model", "gpt-4o-mini");
        temperature      = cfg.getDouble("ai.temperature", 0.7);
        maxTokens        = cfg.getInt("ai.max-tokens", 1500);
        requestsPerMinute= cfg.getInt("ai.requests-per-minute", 30);

        core.getPlugin().getLogger().info("[AI] Provider=" + provider + " Model=" + model);
        if (apiKey.isBlank() || apiKey.startsWith("YOUR_")) {
            core.getPlugin().getLogger().warning("[AI] No API key configured — AI features will not function.");
        }
    }

    // ── Tool registration ─────────────────────────────────────────────────────

    public AIClient registerTool(AITool tool) {
        tools.put(tool.name(), tool);
        return this;
    }

    // ── Chat API ──────────────────────────────────────────────────────────────

    public CompletableFuture<AIResponse> chat(List<Map<String, String>> messages) {
        return chatInternal(new ArrayList<>(messages))
                .exceptionally(ex -> {
                    logError("chat", ex);
                    return new AIResponse("⚠ AI error: " + ex.getMessage(), 0, "EXCEPTION");
                });
    }

    /** Chat using a stored conversation context. */
    public CompletableFuture<AIResponse> chatWithContext(String contextId, String userMessage,
                                                          ConversationStore store) {
        List<Map<String, String>> history = store.getMessages(contextId);
        history.add(Map.of("role", "user", "content", userMessage));
        return chatInternal(history)
                .thenApply(resp -> {
                    store.addMessage(contextId, "user",      userMessage);
                    store.addMessage(contextId, "assistant", resp.content());
                    return resp;
                })
                .exceptionally(ex -> {
                    logError("chatWithContext", ex);
                    return new AIResponse("⚠ AI error: " + ex.getMessage(), 0, "EXCEPTION");
                });
    }

    // ── Streaming ─────────────────────────────────────────────────────────────

    public CompletableFuture<AIResponse> chatStreaming(List<Map<String, String>> messages,
                                                        Consumer<String> tokenCallback,
                                                        Runnable onComplete) {
        return PluginCore.get().async(() -> {
            rateLimit();
            RequestBody body = buildBody(new ArrayList<>(messages), true, false);
            Request req = buildRequest(body);
            StringBuilder full = new StringBuilder();

            try (Response resp = http.newCall(req).execute()) {
                if (resp.body() == null) throw new IOException("Empty response body");
                if (!resp.isSuccessful())
                    return handleHttpError(resp.code(), "");

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(resp.body().byteStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.startsWith("data: ")) continue;
                    String data = line.substring(6).trim();
                    if (data.equals("[DONE]")) break;
                    try {
                        JsonObject obj     = gson.fromJson(data, JsonObject.class);
                        JsonArray  choices = obj.getAsJsonArray("choices");
                        if (choices == null || choices.isEmpty()) continue;
                        JsonObject delta = choices.get(0).getAsJsonObject().getAsJsonObject("delta");
                        if (delta == null || !delta.has("content")) continue;
                        String token = delta.get("content").getAsString();
                        full.append(token);
                        PluginCore.get().sync(() -> tokenCallback.accept(token));
                    } catch (JsonSyntaxException ignored) {}
                }
            }
            PluginCore.get().sync(onComplete);
            return new AIResponse(full.toString(), 0, null);
        }).exceptionally(ex -> {
            logError("chatStreaming", ex);
            PluginCore.get().sync(onComplete);
            return new AIResponse("⚠ Stream error: " + ex.getMessage(), 0, "STREAM_ERROR");
        });
    }

    // ── Internal with tool-calling loop ──────────────────────────────────────

    private CompletableFuture<AIResponse> chatInternal(List<Map<String, String>> messages) {
        return PluginCore.get().async(() -> {
            rateLimit();
            List<Map<String, String>> current = new ArrayList<>(messages);
            int loops = 0;

            while (loops++ < 5) {
                RequestBody body = buildBody(current, false, !tools.isEmpty());
                Request     req  = buildRequest(body);

                try (Response resp = http.newCall(req).execute()) {
                    if (resp.body() == null) throw new IOException("Empty response body");
                    String rawJson = resp.body().string();

                    if (!resp.isSuccessful()) return handleHttpError(resp.code(), rawJson);

                    JsonObject obj     = gson.fromJson(rawJson, JsonObject.class);
                    JsonArray  choices = obj.getAsJsonArray("choices");
                    if (choices == null || choices.isEmpty())
                        return new AIResponse("", 0, "NO_CHOICES");

                    JsonObject message = choices.get(0).getAsJsonObject().getAsJsonObject("message");
                    if (message == null)
                        return new AIResponse("", 0, "NO_MESSAGE");

                    // Tool call branch
                    if (message.has("tool_calls") && !message.get("tool_calls").isJsonNull()) {
                        JsonArray toolCalls = message.getAsJsonArray("tool_calls");
                        current.add(jsonObjectToStringMap(message));

                        for (JsonElement tcEl : toolCalls) {
                            JsonObject tc     = tcEl.getAsJsonObject();
                            String callId     = tc.get("id").getAsString();
                            JsonObject fn     = tc.getAsJsonObject("function");
                            String funcName   = fn.get("name").getAsString();
                            String argsJson   = fn.get("arguments").getAsString();

                            AITool tool = tools.get(funcName);
                            String result;
                            try {
                                result = tool != null
                                        ? tool.execute(gson.fromJson(argsJson, JsonObject.class))
                                        : "{\"error\":\"Unknown tool: " + funcName + "\"}";
                            } catch (Exception e) {
                                result = "{\"error\":\"Tool execution failed: " + e.getMessage() + "\"}";
                            }

                            Map<String, String> toolMsg = new LinkedHashMap<>();
                            toolMsg.put("role",         "tool");
                            toolMsg.put("tool_call_id", callId);
                            toolMsg.put("content",      result);
                            current.add(toolMsg);
                        }
                        continue; // Loop with tool results
                    }

                    // Normal text response
                    String content = message.has("content") && !message.get("content").isJsonNull()
                            ? message.get("content").getAsString()
                            : "";
                    int tokens = 0;
                    if (obj.has("usage") && obj.get("usage").isJsonObject()) {
                        tokens = obj.getAsJsonObject("usage").get("total_tokens").getAsInt();
                        totalTokensUsed += tokens;
                    }
                    return new AIResponse(content, tokens, null);
                }
            }
            return new AIResponse("Max tool-call depth reached.", 0, "TOOL_LOOP");
        });
    }

    // ── Request builders ──────────────────────────────────────────────────────

    private RequestBody buildBody(List<Map<String, String>> messages,
                                   boolean stream, boolean withTools) {
        JsonObject req = new JsonObject();
        req.addProperty("model",       model);
        req.addProperty("temperature", temperature);
        req.addProperty("max_tokens",  maxTokens);
        if (stream) req.addProperty("stream", true);

        JsonArray msgs = new JsonArray();
        for (Map<String, String> m : messages) {
            if (!m.containsKey("role")) continue;
            JsonObject mo = new JsonObject();
            m.forEach(mo::addProperty);
            msgs.add(mo);
        }
        req.add("messages", msgs);

        if (withTools && !tools.isEmpty()) {
            JsonArray toolsArr = new JsonArray();
            for (AITool tool : tools.values()) {
                JsonObject t  = new JsonObject();
                t.addProperty("type", "function");
                JsonObject fn = new JsonObject();
                fn.addProperty("name",        tool.name());
                fn.addProperty("description", tool.description());
                fn.add("parameters", gson.toJsonTree(tool.parameters()));
                t.add("function", fn);
                toolsArr.add(t);
            }
            req.add("tools", toolsArr);
        }

        // FIX: correct OkHttp 4 RequestBody.create(content, mediaType) order
        return RequestBody.create(gson.toJson(req), JSON_TYPE);
    }

    private Request buildRequest(RequestBody body) {
        String url = switch (provider) {
            case OPENAI    -> "https://api.openai.com/v1/chat/completions";
            case ANTHROPIC -> "https://api.anthropic.com/v1/messages";
            case OLLAMA    -> "http://localhost:11434/api/chat";
        };
        return new Request.Builder()
                .url(url)
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type",  "application/json")
                .post(body)
                .build();
    }

    private AIResponse handleHttpError(int code, String body) {
        String msg = switch (code) {
            case 401 -> "Invalid API key.";
            case 429 -> "Rate limited by API provider.";
            case 500, 503 -> "AI provider temporarily unavailable.";
            default  -> "HTTP error " + code;
        };
        logError("HTTP " + code, new RuntimeException(msg + " | " + body));
        return new AIResponse("⚠ " + msg, 0, String.valueOf(code));
    }

    private void rateLimit() {
        try {
            rateLimiter.acquire();
            long minGapMs = 60_000L / Math.max(1, requestsPerMinute);
            long wait     = minGapMs - (System.currentTimeMillis() - lastRequestMs);
            if (wait > 0) Thread.sleep(wait);
            lastRequestMs = System.currentTimeMillis();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            rateLimiter.release();
        }
    }

    private Map<String, String> jsonObjectToStringMap(JsonObject obj) {
        Map<String, String> m = new LinkedHashMap<>();
        obj.entrySet().forEach(e -> {
            JsonElement v = e.getValue();
            m.put(e.getKey(), v.isJsonPrimitive() ? v.getAsString() : v.toString());
        });
        return m;
    }

    private void logError(String context, Throwable ex) {
        PluginCore.get().serviceOpt(StructuredLogger.class)
                .ifPresentOrElse(
                        l -> l.error("AIClient", "[" + context + "] " + ex.getMessage(), ex),
                        () -> PluginCore.get().getPlugin().getLogger()
                                .warning("[AIClient] " + context + ": " + ex.getMessage()));
    }

    // ── Public accessors ──────────────────────────────────────────────────────

    public int getTotalTokensUsed() { return totalTokensUsed; }
    public String getModel()        { return model; }
    public AIProvider getProvider() { return provider; }

    // ── Nested types ──────────────────────────────────────────────────────────

    public record AIResponse(String content, int tokensUsed, String errorCode) {
        public boolean isError() { return errorCode != null; }
    }

    public interface AITool {
        String name();
        String description();
        Map<String, Object> parameters();
        String execute(JsonObject args);
    }
}