package com.example.aiserversetup.ai;

import com.google.gson.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * Uses the OpenAI Tools/Function Calling API to have the AI directly invoke
 * server actions as structured JSON tool calls instead of embedding APPLY blocks.
 */
public class FunctionCallingClient extends AIClient {

    private final JsonArray tools;

    public FunctionCallingClient(String apiKey, String model, int maxTokens, double temperature) {
        super(apiKey, model, model, maxTokens, temperature, 3, 1500);
        this.tools = buildToolsSchema();
    }

    public CompletableFuture<FunctionCallResult> chatWithTools(List<Map<String, String>> messages) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                JsonObject body = buildBody(messages, model.get(), false, tools);
                body.addProperty("tool_choice", "auto");
                var req  = buildRequest(gson.toJson(body));
                var resp = http.send(req, java.net.http.HttpResponse.BodyHandlers.ofString());

                if (resp.statusCode() != 200)
                    return FunctionCallResult.text("§c[Error] " + extractError(resp.body()));

                JsonObject json     = JsonParser.parseString(resp.body()).getAsJsonObject();
                JsonObject choice   = json.getAsJsonArray("choices").get(0).getAsJsonObject();
                JsonObject message  = choice.getAsJsonObject("message");
                String    finishReason = choice.get("finish_reason").getAsString();

                if ("tool_calls".equals(finishReason) && message.has("tool_calls")) {
                    JsonArray toolCalls = message.getAsJsonArray("tool_calls");
                    return FunctionCallResult.toolCalls(toolCalls);
                }

                String content = message.has("content") && !message.get("content").isJsonNull()
                        ? message.get("content").getAsString() : "";
                return FunctionCallResult.text(content);

            } catch (Exception e) {
                return FunctionCallResult.text("§c[FN Error] " + e.getMessage());
            }
        });
    }

    private JsonArray buildToolsSchema() {
        JsonArray arr = new JsonArray();
        arr.add(makeTool("set_server_property", "Set a server.properties key/value pair",
                param("key", "string", "The property key"),
                param("value", "string", "The new value")));
        arr.add(makeTool("set_yaml_value", "Set a value in bukkit.yml, spigot.yml, or paper config",
                param("file", "string", "One of: bukkit.yml, spigot.yml, paper-global.yml"),
                param("path", "string", "Dot-separated config path"),
                param("value", "string", "The new value")));
        arr.add(makeTool("recommend_plugin", "Recommend a plugin to the server owner",
                param("name", "string", "Plugin name"),
                param("url", "string", "Download URL"),
                param("reason", "string", "Why this plugin is recommended")));
        arr.add(makeTool("run_console_command", "Suggest a server console command",
                param("command", "string", "The command to run"),
                param("reason", "string", "Why this command is needed"),
                param("dangerous", "boolean", "Whether this command is potentially dangerous")));
        arr.add(makeTool("manage_whitelist", "Add or remove a player from the whitelist",
                param("action", "string", "add or remove"),
                param("player", "string", "Player name")));
        arr.add(makeTool("manage_ops", "Op or deop a player",
                param("action", "string", "op or deop"),
                param("player", "string", "Player name")));
        return arr;
    }

    private JsonObject makeTool(String name, String description, JsonObject... params) {
        JsonObject fn = new JsonObject();
        fn.addProperty("name", name);
        fn.addProperty("description", description);
        JsonObject parameters = new JsonObject();
        parameters.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonArray required = new JsonArray();
        for (JsonObject p : params) {
            props.add(p.get("_name").getAsString(), p);
            p.remove("_name");
            required.add(p.has("required") ? p.get("required").getAsString() : "");
        }
        parameters.add("properties", props);
        fn.add("parameters", parameters);

        JsonObject tool = new JsonObject();
        tool.addProperty("type", "function");
        tool.add("function", fn);
        return tool;
    }

    private JsonObject param(String name, String type, String description) {
        JsonObject p = new JsonObject();
        p.addProperty("_name", name);
        p.addProperty("type", type);
        p.addProperty("description", description);
        return p;
    }
}