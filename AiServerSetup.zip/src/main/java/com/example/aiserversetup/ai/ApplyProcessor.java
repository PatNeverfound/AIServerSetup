package com.example.aiserversetup.ai;

import com.example.aiserversetup.core.PluginCore;
import com.google.gson.*;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.logging.Level;
import java.util.regex.*;

/**
 * Processes ===APPLY=== {...} ===END=== blocks returned by the AI.
 * Parses the JSON payload and executes the appropriate server action.
 */
public class ApplyProcessor implements PluginCore.PluginModule {

    private static final Pattern APPLY_PATTERN =
            Pattern.compile("===APPLY===\\s*(\\{[^}]+})\\s*===END===", Pattern.DOTALL);
    private static final MiniMessage MM   = MiniMessage.miniMessage();
    private static final Gson        GSON = new Gson();

    @Override
    public String name() { return "ApplyProcessor"; }

    @Override
    public void onEnable(PluginCore core) {
        core.getPlugin().getLogger().info("[ApplyProcessor] Ready.");
    }

    /**
     * Scan the AI response text for APPLY blocks and execute them all.
     *
     * @param response  Full AI response text
     * @param sender    The command sender to notify of results (may be null for console)
     * @return          The response text with APPLY blocks stripped out
     */
    public String processAndStrip(String response, org.bukkit.command.CommandSender sender) {
        Matcher m = APPLY_PATTERN.matcher(response);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String jsonStr = m.group(1).trim();
            try {
                JsonObject json = GSON.fromJson(jsonStr, JsonObject.class);
                execute(json, sender);
            } catch (JsonSyntaxException e) {
                log("Malformed APPLY JSON: " + jsonStr);
            }
            m.appendReplacement(sb, "");
        }
        m.appendTail(sb);
        return sb.toString().trim();
    }

    private void execute(JsonObject json, org.bukkit.command.CommandSender sender) {
        String type = getString(json, "type", "");
        log("Executing APPLY action: " + type);

        switch (type) {
            // ── Item actions ─────────────────────────────────────────────────
            case "ci-create-ai" -> {
                String desc   = getString(json, "description", "");
                String player = getString(json, "player", "");
                if (!desc.isBlank()) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.customitems.CustomItemManager.class)
                            .ifPresent(mgr -> {
                                Player p = Bukkit.getPlayerExact(player);
                                mgr.createItemWithAI(desc, p != null ? p : sender);
                            });
                }
            }
            case "ci-give" -> {
                String player = getString(json, "player", "");
                String itemId = getString(json, "itemId", "");
                int    amount = getInt(json,  "amount", 1);
                Player p = Bukkit.getPlayerExact(player);
                if (p != null) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.customitems.CustomItemManager.class)
                            .ifPresent(mgr -> mgr.giveItem(p, itemId, amount));
                }
            }
            case "ci-delete" -> {
                String itemId = getString(json, "itemId", "");
                PluginCore.get().serviceOpt(
                        com.example.aiserversetup.customitems.CustomItemRegistry.class)
                        .ifPresent(reg -> reg.delete(itemId));
            }
            case "ci-pack" -> {
                PluginCore.get().serviceOpt(
                        com.example.aiserversetup.customitems.CustomItemManager.class)
                        .ifPresent(mgr -> mgr.regeneratePack(sender));
            }
            case "ci-reload" -> {
                PluginCore.get().serviceOpt(
                        com.example.aiserversetup.customitems.CustomItemManager.class)
                        .ifPresent(com.example.aiserversetup.customitems.CustomItemManager::reloadItems);
            }
            case "ci-upgrade" -> {
                String player = getString(json, "player", "");
                Player p = Bukkit.getPlayerExact(player);
                if (p != null) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.customitems.upgrades.UpgradeSystem.class)
                            .ifPresent(us -> us.upgrade(p, p.getInventory().getItemInMainHand()));
                }
            }

            // ── Gamemode actions ──────────────────────────────────────────────
            case "gm-join" -> {
                String player = getString(json, "player", "");
                String mode   = getString(json, "mode",   "survival");
                Player p = Bukkit.getPlayerExact(player);
                if (p != null) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.gamemodes.GamemodeManager.class)
                            .ifPresent(gm -> gm.setPlayerMode(p, mode));
                }
            }
            case "gm-set-hearts" -> {
                String player = getString(json, "player", "");
                int hearts    = getInt(json, "hearts", 10);
                Player p = Bukkit.getPlayerExact(player);
                if (p != null) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.gamemodes.GamemodeManager.class)
                            .flatMap(gm -> Optional.ofNullable(gm.getMode(
                                    com.example.aiserversetup.gamemodes.impl.LifestealGamemode.class)))
                            .ifPresent(ls -> {
                                ls.setHearts(p, hearts);
                                ls.applyGameRules(p);
                            });
                }
            }
            case "gm-hc-revive" -> {
                String player = getString(json, "player", "");
                PluginCore.get().serviceOpt(
                        com.example.aiserversetup.gamemodes.GamemodeManager.class)
                        .flatMap(gm -> Optional.ofNullable(gm.getMode(
                                com.example.aiserversetup.gamemodes.impl.HardcoreGamemode.class)))
                        .ifPresent(hc -> hc.revivePlayer(player));
            }
            case "gm-uhc-start" -> {
                PluginCore.get().serviceOpt(
                        com.example.aiserversetup.gamemodes.GamemodeManager.class)
                        .flatMap(gm -> Optional.ofNullable(gm.getMode(
                                com.example.aiserversetup.gamemodes.impl.UHCGamemode.class)))
                        .ifPresent(com.example.aiserversetup.gamemodes.impl.UHCGamemode::startGame);
            }
            case "gm-rankup" -> {
                String player = getString(json, "player", "");
                Player p = Bukkit.getPlayerExact(player);
                if (p != null) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.gamemodes.GamemodeManager.class)
                            .flatMap(gm -> Optional.ofNullable(gm.getMode(
                                    com.example.aiserversetup.gamemodes.impl.PrisonGamemode.class)))
                            .ifPresent(pr -> pr.rankup(p));
                }
            }
            case "gm-rpg-class" -> {
                String player    = getString(json, "player", "");
                String className = getString(json, "class",  "WARRIOR");
                Player p = Bukkit.getPlayerExact(player);
                if (p != null) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.gamemodes.GamemodeManager.class)
                            .flatMap(gm -> Optional.ofNullable(gm.getMode(
                                    com.example.aiserversetup.gamemodes.impl.RPGGamemode.class)))
                            .ifPresent(rpg -> rpg.selectClass(p, className));
                }
            }
            case "gm-tycoon-buy" -> {
                String player   = getString(json, "player",   "");
                String business = getString(json, "business", "");
                Player p = Bukkit.getPlayerExact(player);
                if (p != null) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.gamemodes.GamemodeManager.class)
                            .flatMap(gm -> Optional.ofNullable(gm.getMode(
                                    com.example.aiserversetup.gamemodes.impl.TycoonGamemode.class)))
                            .ifPresent(ty -> ty.buyBusiness(p, business));
                }
            }
            case "gm-faction-create" -> {
                String player = getString(json, "player", "");
                String name   = getString(json, "name",   "");
                Player p = Bukkit.getPlayerExact(player);
                if (p != null && !name.isBlank()) {
                    PluginCore.get().serviceOpt(
                            com.example.aiserversetup.gamemodes.GamemodeManager.class)
                            .flatMap(gm -> Optional.ofNullable(gm.getMode(
                                    com.example.aiserversetup.gamemodes.impl.FactionsGamemode.class)))
                            .ifPresent(f -> f.createFaction(p, name));
                }
            }

            // ── Server actions ────────────────────────────────────────────────
            case "run-command" -> {
                String cmd = getString(json, "command", "");
                if (!cmd.isBlank()) {
                    Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () ->
                            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd));
                }
            }
            case "broadcast" -> {
                String msg = getString(json, "message", "");
                if (!msg.isBlank()) {
                    Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () ->
                            Bukkit.broadcast(MM.deserialize(msg)));
                }
            }
            case "kick" -> {
                String player = getString(json, "player", "");
                String reason = getString(json, "reason", "Kicked by server AI");
                Player p = Bukkit.getPlayerExact(player);
                if (p != null) {
                    Bukkit.getScheduler().runTask(PluginCore.get().getPlugin(), () ->
                            p.kick(MM.deserialize(reason)));
                }
            }

            default -> log("Unknown APPLY type: " + type);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private String getString(JsonObject obj, String key, String def) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return def;
        return obj.get(key).getAsString();
    }

    private int getInt(JsonObject obj, String key, int def) {
        if (!obj.has(key) || obj.get(key).isJsonNull()) return def;
        try { return obj.get(key).getAsInt(); } catch (Exception e) { return def; }
    }

    private void log(String msg) {
        PluginCore.get().serviceOpt(com.example.aiserversetup.util.StructuredLogger.class)
                .ifPresentOrElse(
                        l -> l.info("ApplyProcessor", msg),
                        () -> PluginCore.get().getPlugin().getLogger().info("[ApplyProcessor] " + msg));
    }
}