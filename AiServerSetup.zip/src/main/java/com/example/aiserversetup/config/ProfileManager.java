package com.example.aiserversetup.config;

import com.google.gson.*;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.*;
import java.util.*;

/**
 * Saves and loads named server configuration profiles as JSON files.
 */
public class ProfileManager {

    private final File profileDir;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public ProfileManager(File dataFolder) {
        this.profileDir = new File(dataFolder, "profiles");
        profileDir.mkdirs();
    }

    public void saveProfile(String name, Map<String, String> properties) throws IOException {
        File f = new File(profileDir, sanitize(name) + ".json");
        try (Writer w = new FileWriter(f)) {
            gson.toJson(properties, w);
        }
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> loadProfile(String name) throws IOException {
        File f = new File(profileDir, sanitize(name) + ".json");
        if (!f.exists()) throw new FileNotFoundException("Profile '" + name + "' not found.");
        try (Reader r = new FileReader(f)) {
            return gson.fromJson(r, Map.class);
        }
    }

    public boolean deleteProfile(String name) {
        return new File(profileDir, sanitize(name) + ".json").delete();
    }

    public List<String> listProfiles() {
        String[] files = profileDir.list((d, n) -> n.endsWith(".json"));
        if (files == null) return List.of();
        List<String> names = new ArrayList<>();
        for (String f : files) names.add(f.replace(".json", ""));
        return Collections.unmodifiableList(names);
    }

    /** Capture the current server.properties into a profile. */
    public Map<String, String> captureCurrentProperties() throws IOException {
        File f = new File("server.properties");
        if (!f.exists()) return Map.of();
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(f)) { p.load(in); }
        Map<String, String> map = new LinkedHashMap<>();
        p.forEach((k, v) -> map.put(k.toString(), v.toString()));
        return map;
    }

    private String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9_\\-]", "_").toLowerCase();
    }
}