package com.example.aiserversetup.config;

import com.example.aiserversetup.util.ActionHistory;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.*;
import java.util.*;

/** Safe read/write access to all Minecraft server config files with undo support. */
public class FileEditor {

    private final JavaPlugin   plugin;
    private final ActionHistory history;

    private static final List<String> YAML_FILES = List.of(
            "bukkit.yml", "spigot.yml",
            "config/paper-global.yml", "config/paper-world-defaults.yml"
    );

    public FileEditor(JavaPlugin plugin, ActionHistory history) {
        this.plugin  = plugin;
        this.history = history;
    }

    // ── server.properties ────────────────────────────────────────────────────

    public boolean setServerProperty(String key, String value) {
        File f = new File("server.properties");
        if (!f.exists()) return false;
        try {
            Properties props = loadProps(f);
            String old = props.getProperty(key, "(not set)");
            props.setProperty(key, value);
            try (OutputStream out = new FileOutputStream(f)) {
                props.store(out, "Modified by AIServerSetup v3");
            }
            history.record(ActionHistory.ActionType.SERVER_PROPERTY, key, old, value);
            return true;
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to write server.properties: " + e.getMessage());
            return false;
        }
    }

    public boolean undoServerProperty(String key, String oldValue) {
        return setServerProperty(key, oldValue);
    }

    public String getServerProperty(String key) {
        File f = new File("server.properties");
        if (!f.exists()) return null;
        try { return loadProps(f).getProperty(key); }
        catch (IOException e) { return null; }
    }

    public Map<String, String> getAllServerProperties() {
        File f = new File("server.properties");
        Map<String, String> map = new LinkedHashMap<>();
        if (!f.exists()) return map;
        try {
            Properties p = loadProps(f);
            p.forEach((k, v) -> map.put(k.toString(), v.toString()));
        } catch (IOException ignored) {}
        return map;
    }

    public String dumpServerProperties() {
        StringBuilder sb = new StringBuilder();
        getAllServerProperties().forEach((k, v) -> sb.append(k).append("=").append(v).append("\n"));
        return sb.toString();
    }

    // ── YAML files ────────────────────────────────────────────────────────────

    public boolean setYamlValue(String filename, String path, String value) {
        File f = resolveFile(filename);
        if (f == null || !f.exists()) return false;
        try {
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
            String old = cfg.get(path) != null ? cfg.get(path).toString() : "(not set)";
            cfg.set(path, coerce(value));
            cfg.save(f);
            history.record(ActionHistory.ActionType.YAML, filename + ":" + path, old, value);
            return true;
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to write " + filename + ": " + e.getMessage());
            return false;
        }
    }

    public String getYamlValue(String filename, String path) {
        File f = resolveFile(filename);
        if (f == null || !f.exists()) return null;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        Object val = cfg.get(path);
        return val != null ? val.toString() : null;
    }

    public String dumpYaml(String filename) {
        File f = resolveFile(filename);
        if (f == null || !f.exists()) return "(" + filename + " not found)";
        return YamlConfiguration.loadConfiguration(f).saveToString();
    }

    // ── ops.json / whitelist.json ─────────────────────────────────────────────

    public boolean addToWhitelist(String playerName) {
        return modifyJson("whitelist.json", playerName, true);
    }

    public boolean removeFromWhitelist(String playerName) {
        return modifyJson("whitelist.json", playerName, false);
    }

    public List<String> getWhitelist() { return readJsonNames("whitelist.json"); }

    public boolean opPlayer(String playerName) {
        return modifyJson("ops.json", playerName, true);
    }

    public boolean deopPlayer(String playerName) {
        return modifyJson("ops.json", playerName, false);
    }

    public List<String> getOps() { return readJsonNames("ops.json"); }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private File resolveFile(String name) {
        // Support both root-relative and config/subdir
        File f = new File(name);
        if (f.exists()) return f;
        f = new File(plugin.getDataFolder().getParentFile().getParentFile(), name);
        return f;
    }

    private Properties loadProps(File f) throws IOException {
        Properties p = new Properties();
        try (InputStream in = new FileInputStream(f)) { p.load(in); }
        return p;
    }

    private Object coerce(String value) {
        if ("true".equalsIgnoreCase(value))  return true;
        if ("false".equalsIgnoreCase(value)) return false;
        try { return Integer.parseInt(value); } catch (NumberFormatException ignored) {}
        try { return Double.parseDouble(value); } catch (NumberFormatException ignored) {}
        return value;
    }

    private boolean modifyJson(String filename, String name, boolean add) {
        File f = new File(filename);
        com.google.gson.Gson gson = new com.google.gson.GsonBuilder().setPrettyPrinting().create();
        com.google.gson.JsonArray arr;
        try {
            if (f.exists()) {
                try (Reader r = new FileReader(f)) {
                    arr = com.google.gson.JsonParser.parseReader(r).getAsJsonArray();
                }
            } else { arr = new com.google.gson.JsonArray(); }

            if (add) {
                com.google.gson.JsonObject entry = new com.google.gson.JsonObject();
                entry.addProperty("uuid", "00000000-0000-0000-0000-000000000000");
                entry.addProperty("name", name);
                arr.add(entry);
            } else {
                arr = arr.deepCopy();
                for (int i = 0; i < arr.size(); i++) {
                    if (name.equalsIgnoreCase(arr.get(i).getAsJsonObject().get("name").getAsString())) {
                        arr.remove(i); break;
                    }
                }
            }

            try (Writer w = new FileWriter(f)) { gson.toJson(arr, w); }
            return true;
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to modify " + filename + ": " + e.getMessage());
            return false;
        }
    }

    private List<String> readJsonNames(String filename) {
        File f = new File(filename);
        if (!f.exists()) return List.of();
        try (Reader r = new FileReader(f)) {
            com.google.gson.JsonArray arr = com.google.gson.JsonParser.parseReader(r).getAsJsonArray();
            List<String> names = new ArrayList<>();
            arr.forEach(e -> names.add(e.getAsJsonObject().get("name").getAsString()));
            return names;
        } catch (Exception e) { return List.of(); }
    }

    public List<String> getYamlFiles() { return YAML_FILES; }
}