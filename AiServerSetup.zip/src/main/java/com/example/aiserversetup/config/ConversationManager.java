package com.example.aiserversetup.config;

import java.util.*;

/**
 * Manages per-sender conversation history, including automatic context injection.
 */
public class ConversationManager {

    private final String baseSystemPrompt;
    private final int maxHistory;
    private final Map<String, List<Map<String, String>>> histories = new HashMap<>();
    private final Map<String, String> modelOverrides = new HashMap<>();

    public ConversationManager(String systemPrompt, int maxHistory) {
        this.baseSystemPrompt = systemPrompt;
        this.maxHistory       = maxHistory;
    }

    /** Build full message list with system prompt + optional context injection + history. */
    public List<Map<String, String>> buildMessages(String sender, String contextBlock) {
        List<Map<String, String>> messages = new ArrayList<>();
        String systemContent = baseSystemPrompt;
        if (contextBlock != null && !contextBlock.isBlank()) {
            systemContent += "\n\n--- CURRENT SERVER CONTEXT ---\n" + contextBlock;
        }
        messages.add(Map.of("role", "system", "content", systemContent));
        messages.addAll(getHistory(sender));
        return messages;
    }

    public List<Map<String, String>> buildMessages(String sender) {
        return buildMessages(sender, null);
    }

    public void addUserMessage(String sender, String content) {
        List<Map<String, String>> h = getHistory(sender);
        h.add(new HashMap<>(Map.of("role", "user", "content", content)));
        trim(h);
    }

    public void addAssistantMessage(String sender, String content) {
        List<Map<String, String>> h = getHistory(sender);
        h.add(new HashMap<>(Map.of("role", "assistant", "content", content)));
        trim(h);
    }

    public void clearHistory(String sender) { histories.remove(sender); }

    public List<Map<String, String>> getHistory(String sender) {
        return histories.computeIfAbsent(sender, k -> new ArrayList<>());
    }

    public int historySize(String sender) {
        return getHistory(sender).size();
    }

    public void setModelOverride(String sender, String model) { modelOverrides.put(sender, model); }
    public Optional<String> getModelOverride(String sender) { return Optional.ofNullable(modelOverrides.get(sender)); }

    private void trim(List<Map<String, String>> h) {
        while (h.size() > maxHistory * 2) h.remove(0);
    }
}