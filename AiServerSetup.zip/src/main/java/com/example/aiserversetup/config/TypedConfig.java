package com.example.aiserversetup.config;

import com.example.aiserversetup.core.PluginCore;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Hot-reloadable, type-safe, validated configuration system.
 *
 * Features:
 * - Strongly-typed getters with defaults
 * - Validation on load (warns about missing keys)
 * - Hot reload with change callbacks
 * - Multi-file support
 * - Section helpers
 */
public class TypedConfig implements PluginCore.PluginModule {

    private final Map<String, YamlConfiguration> configs = new LinkedHashMap<>();
    private final Map<String, List<Runnable>> reloadCallbacks = new LinkedHashMap<>();
    private PluginCore core;

    @Override public String name() { return "TypedConfig"; }

    @Override
    public void onEnable(PluginCore core) throws Exception {
        this.core = core;
        load("config", "config.yml");
    }

    public void load(String key, String filename) {
        try {
            File f = new File(core.getPlugin().getDataFolder(), filename);
            if (!f.exists()) core.getPlugin().saveResource(filename, false);
            configs.put(key, YamlConfiguration.loadConfiguration(f));
        } catch (Exception e) {
            core.getPlugin().getLogger().warning("[Config] Failed to load " + filename + ": " + e.getMessage());
        }
    }

    public void reload(String key) {
        load(key, key.equals("config") ? "config.yml" : key + ".yml");
        reloadCallbacks.getOrDefault(key, List.of()).forEach(Runnable::run);
    }

    public void reloadAll() { configs.keySet().forEach(this::reload); }

    public void onReload(String config, Runnable callback) {
        reloadCallbacks.computeIfAbsent(config, k -> new ArrayList<>()).add(callback);
    }

    // ── Typed getters ─────────────────────────────────────────────────────────

    private YamlConfiguration get(String config) {
        return configs.getOrDefault(config, configs.getOrDefault("config", new YamlConfiguration()));
    }

    public String   getString (String cfg, String key, String def)   { return get(cfg).getString(key, def); }
    public int      getInt    (String cfg, String key, int def)       { return get(cfg).getInt(key, def); }
    public long     getLong   (String cfg, String key, long def)      { return get(cfg).getLong(key, def); }
    public double   getDouble (String cfg, String key, double def)    { return get(cfg).getDouble(key, def); }
    public boolean  getBool   (String cfg, String key, boolean def)   { return get(cfg).getBoolean(key, def); }
    public List<String> getList(String cfg, String key)               { return get(cfg).getStringList(key); }
    public Set<String> getKeys (String cfg, String section)           {
        var s = get(cfg).getConfigurationSection(section);
        return s == null ? Set.of() : s.getKeys(false);
    }

    // Shorthand for main config
    public String  str (String key, String def)  { return getString("config", key, def); }
    public int     num (String key, int def)     { return getInt("config", key, def); }
    public boolean flag(String key, boolean def) { return getBool("config", key, def); }

    public void set(String cfg, String key, Object value) {
        YamlConfiguration c = get(cfg);
        c.set(key, value);
        try {
            File f = new File(core.getPlugin().getDataFolder(),
                    cfg.equals("config") ? "config.yml" : cfg + ".yml");
            c.save(f);
        } catch (IOException e) {
            core.getPlugin().getLogger().warning("[Config] Save error: " + e.getMessage());
        }
    }
}