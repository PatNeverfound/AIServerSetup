package com.example.aiserversetup.config;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.ai.AIClient;
import com.example.aiserversetup.command.ApplyProcessor;
import com.example.aiserversetup.util.ChatUtil;
import org.bukkit.command.CommandSender;
import org.bukkit.scheduler.BukkitTask;

import java.time.*;
import java.util.*;
import java.util.concurrent.*;

/** Manages and executes scheduled AI tasks (daily/hourly prompts). */
public class ScheduledTaskManager {

    public record ScheduledTask(String id, String cron, String prompt, boolean enabled) {}

    private final AIServerSetupPlugin plugin;
    private final AIClient ai;
    private final ConversationManager conv;
    private final FileEditor fe;
    private final ChatUtil chat;

    private final List<ScheduledTask> tasks = new CopyOnWriteArrayList<>();
    private final Map<String, BukkitTask> runningTasks = new ConcurrentHashMap<>();

    public ScheduledTaskManager(AIServerSetupPlugin p, AIClient ai, ConversationManager conv,
                                 FileEditor fe, ChatUtil chat) {
        this.plugin = p; this.ai = ai; this.conv = conv; this.fe = fe; this.chat = chat;
    }

    public void loadFromConfig() {
        var list = plugin.getConfig().getMapList("scheduled-tasks");
        for (var map : list) {
            String id      = (String) map.get("id");
            String cron    = (String) map.get("cron");
            String prompt  = (String) map.get("prompt");
            boolean enabled= map.containsKey("enabled") ? (Boolean) map.get("enabled") : true;
            if (id != null && cron != null && prompt != null)
                tasks.add(new ScheduledTask(id, cron, prompt, enabled));
        }
    }

    public void startAll() {
        for (ScheduledTask t : tasks) if (t.enabled()) scheduleTask(t);
    }

    public void stopAll() {
        runningTasks.values().forEach(BukkitTask::cancel);
        runningTasks.clear();
    }

    public List<ScheduledTask> getTasks() { return Collections.unmodifiableList(tasks); }

    public void addTask(String id, String timeHHMM, String prompt) {
        ScheduledTask t = new ScheduledTask(id, timeHHMM, prompt, true);
        tasks.add(t);
        scheduleTask(t);
    }

    public boolean removeTask(String id) {
        boolean removed = tasks.removeIf(t -> t.id().equals(id));
        BukkitTask bt = runningTasks.remove(id);
        if (bt != null) bt.cancel();
        return removed;
    }

    public boolean runNow(String id, CommandSender sender) {
        return tasks.stream().filter(t -> t.id().equals(id)).findFirst().map(t -> {
            chat.info(sender, "Running scheduled task: <yellow>" + id + "</yellow>");
            executeTask(t, plugin.getServer().getConsoleSender());
            return true;
        }).orElse(false);
    }

    private void scheduleTask(ScheduledTask task) {
        // Parse HH:MM cron format — run daily at the given time
        String[] parts = task.cron().split(":");
        if (parts.length != 2) return;
        try {
            int hour = Integer.parseInt(parts[0]);
            int min  = Integer.parseInt(parts[1]);
            long nowSecs = LocalTime.now().toSecondOfDay();
            long targetSecs = hour * 3600L + min * 60L;
            long delaySecs = targetSecs > nowSecs ? targetSecs - nowSecs : (86400 - nowSecs + targetSecs);
            long delayTicks = delaySecs * 20L;
            long periodTicks = 24 * 60 * 60 * 20L; // daily

            BukkitTask bt = plugin.getServer().getScheduler()
                    .runTaskTimerAsynchronously(plugin,
                            () -> executeTask(task, plugin.getServer().getConsoleSender()),
                            delayTicks, periodTicks);
            runningTasks.put(task.id(), bt);
        } catch (NumberFormatException e) {
            plugin.getLogger().warning("Invalid cron for task '" + task.id() + "': " + task.cron());
        }
    }

    private void executeTask(ScheduledTask task, CommandSender sender) {
        String senderName = "SCHEDULED:" + task.id();
        conv.addUserMessage(senderName, task.prompt());
        ai.chat(conv.buildMessages(senderName)).thenAccept(response ->
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    conv.addAssistantMessage(senderName, response.content());
                    plugin.getSessionLogger().log(senderName, "assistant", response.content());
                    ApplyProcessor.process(sender, response.content(), plugin);
                    plugin.getLogger().info("[Scheduled:" + task.id() + "] AI executed: "
                            + ApplyProcessor.stripBlocks(response.content()).substring(0, Math.min(100, response.content().length())));
                    plugin.getDiscordWebhook().sendIfEnabled(
                            "**[Scheduled Task: " + task.id() + "]** " + ApplyProcessor.stripBlocks(response.content()));
                })
        );
    }
}