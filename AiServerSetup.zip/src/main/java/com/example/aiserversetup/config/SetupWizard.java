package com.example.aiserversetup.config;

import com.example.aiserversetup.AIServerSetupPlugin;
import com.example.aiserversetup.ai.AIClient;
import com.example.aiserversetup.command.ApplyProcessor;
import com.example.aiserversetup.util.ChatUtil;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Step-by-step guided setup wizard.
 * Each step asks the player a question; their chat reply is fed to the AI.
 */
public class SetupWizard implements Listener {

    private final AIServerSetupPlugin plugin;
    private final AIClient ai;
    private final ConversationManager conv;
    private final FileEditor fe;
    private final ChatUtil chat;
    private final MiniMessage mm = MiniMessage.miniMessage();

    // player name → current step index
    private final Map<String, Integer> wizardState = new ConcurrentHashMap<>();

    public SetupWizard(AIServerSetupPlugin p, AIClient ai, ConversationManager conv,
                       FileEditor fe, ChatUtil chat) {
        this.plugin = p; this.ai = ai; this.conv = conv; this.fe = fe; this.chat = chat;
        p.getServer().getPluginManager().registerEvents(this, p);
    }

    public void start(Player player) {
        wizardState.put(player.getName(), 0);
        conv.clearHistory(player.getName());
        chat.header(player, "AI Setup Wizard");
        chat.sendRaw(player, "<gray>Answer each question in chat. Type <red>cancel</red> to exit.</gray>");
        askStep(player, 0);
    }

    private void askStep(Player player, int step) {
        List<String> steps = plugin.getConfig().getStringList("wizard-steps");
        if (step >= steps.size()) {
            wizardState.remove(player.getName());
            chat.header(player, "Wizard Complete!");
            chat.success(player, "All settings have been collected and applied. Restart your server.");
            return;
        }
        chat.sendRaw(player, "<gradient:#00c6ff:#0072ff>Step " + (step + 1) + "/" + steps.size() + ":</gradient>");
        chat.sendRaw(player, "<white>" + steps.get(step) + "</white>");
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!wizardState.containsKey(player.getName())) return;

        event.setCancelled(true);
        String answer = event.getMessage();

        if (answer.equalsIgnoreCase("cancel")) {
            wizardState.remove(player.getName());
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    chat.warn(player, "Wizard cancelled."));
            return;
        }

        int step = wizardState.get(player.getName());
        List<String> steps = plugin.getConfig().getStringList("wizard-steps");
        String question = steps.get(step);

        conv.addUserMessage(player.getName(), "Wizard step " + (step + 1) + ": " + question + "\nMy answer: " + answer);

        plugin.getServer().getScheduler().runTask(plugin, () ->
                chat.sendRaw(player, "<gray>⟳ Processing...</gray>"));

        ai.chat(conv.buildMessages(player.getName())).thenAccept(response ->
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    conv.addAssistantMessage(player.getName(), response.content());
                    ApplyProcessor.process(player, response.content(), plugin);
                    String display = ApplyProcessor.stripBlocks(response.content());
                    if (!display.isBlank()) chat.sendMultiline(player, display);

                    int next = step + 1;
                    wizardState.put(player.getName(), next);
                    plugin.getServer().getScheduler().runTaskLater(plugin, () -> askStep(player, next), 10L);
                })
        );
    }
}