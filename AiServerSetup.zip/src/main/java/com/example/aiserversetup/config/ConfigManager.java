package com.example.aiserversetup.config;

import com.example.aiserversetup.AIServerSetupPlugin;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * AI-driven config manager. Can read/write any installed plugin's config.yml,
 * create backups before changes, reload plugins after edits.
 */
public class ConfigManager {

    private final AIServerSetupPlugin plugin;

    public ConfigManager(AIServerSetupPlugin plugin) { this.plugin = plugin; }

    /** Read any key from any plugin's config.yml */
    public String readConfig(String pluginName, String key) {
        File cfg = getConfigFile(pluginName);
        if (cfg == null) return "Config not found for: " + pluginName;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(cfg);
        Object val = yaml.get(key);
        return val == null ? "(key not found)" : val.toString();
    }

    /** Write a key to a plugin's config.yml */
    public boolean writeConfig(String pluginName, String key, Object value) {
        File cfg = getConfigFile(pluginName);
        if (cfg == null) return false;
        try {
            backupConfig(pluginName);
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(cfg);
            yaml.set(key, value);
            yaml.save(cfg);
            return true;
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to write config for " + pluginName + ": " + e.getMessage());
            return false;
        }
    }

    /** Get the full text of a plugin's config.yml */
    public String getConfigText(String pluginName) {
        File cfg = getConfigFile(pluginName);
        if (cfg == null) return "Config not found.";
        try { return Files.readString(cfg.toPath()); }
        catch (Exception e) { return "Error reading config: " + e.getMessage(); }
    }

    /** Replace the entire config text (with backup) */
    public boolean setConfigText(String pluginName, String content) {
        File cfg = getConfigFile(pluginName);
        if (cfg == null) return false;
        try {
            backupConfig(pluginName);
            Files.writeString(cfg.toPath(), content);
            return true;
        } catch (Exception e) { return false; }
    }

    /** Reload a plugin after config changes */
    public boolean reloadPlugin(String pluginName) {
        try {
            Plugin p = Bukkit.getPluginManager().getPlugin(pluginName);
            if (p == null) return false;
            // Use built-in reload if available
            return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), pluginName.toLowerCase() + " reload");
        } catch (Exception e) { return false; }
    }

    /** List all top-level keys of a plugin's config */
    public List<String> getConfigKeys(String pluginName) {
        File cfg = getConfigFile(pluginName);
        if (cfg == null) return List.of();
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(cfg);
        return yaml.getKeys(false).stream().sorted().collect(Collectors.toList());
    }

    /** List all configs available (all plugin folders with config.yml) */
    public List<String> listPluginConfigs() {
        File plugins = new File("plugins");
        List<String> found = new ArrayList<>();
        File[] dirs = plugins.listFiles(File::isDirectory);
        if (dirs != null) for (File d : dirs) {
            if (new File(d, "config.yml").exists()) found.add(d.getName());
        }
        return found;
    }

    private File getConfigFile(String pluginName) {
        File f = new File("plugins/" + pluginName + "/config.yml");
        return f.exists() ? f : null;
    }

    private void backupConfig(String pluginName) throws IOException {
        File cfg = getConfigFile(pluginName);
        if (cfg == null) return;
        String timestamp = java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        File backup = new File(plugin.getDataFolder(), "config_backups/" + pluginName + "_" + timestamp + ".yml");
        backup.getParentFile().mkdirs();
        Files.copy(cfg.toPath(), backup.toPath());
    }
}