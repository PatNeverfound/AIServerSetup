// Fields:
private CustomItemRegistry      customItemRegistry;
private CustomItemManager       customItemManager;
private ResourcePackGenerator   resourcePackGenerator;
private ItemCreatorGUI          itemCreatorGUI;
private AbilityExecutor         abilityExecutor;
private UpgradeSystem           upgradeSystem;

// In onEnable():
customItemRegistry    = new CustomItemRegistry(this);
resourcePackGenerator = new ResourcePackGenerator(this);
customItemManager     = new CustomItemManager(this);
upgradeSystem         = new UpgradeSystem(this);
itemCreatorGUI        = new ItemCreatorGUI(this);
abilityExecutor       = new AbilityExecutor(this);
abilityExecutor.startPassiveTick();

// Register command:
getCommand("customitems").setExecutor(new CustomItemCommand(this));
getCommand("customitems").setTabCompleter(new CustomItemCommand(this));

// Getters:
public CustomItemRegistry     getCustomItemRegistry()    { return customItemRegistry; }
public CustomItemManager      getCustomItemManager()     { return customItemManager; }
public ResourcePackGenerator  getResourcePackGenerator() { return resourcePackGenerator; }
public ItemCreatorGUI         getItemCreatorGUI()        { return itemCreatorGUI; }
public UpgradeSystem          getUpgradeSystem()         { return upgradeSystem; }
public AbilityExecutor        getAbilityExecutor()       { return abilityExecutor; }